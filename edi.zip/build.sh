echo "*************** npm install  ***************"
npm install

echo "*************** npm build package  ***************"
npm run-script build

echo "*************** Getting version from package.json  ***************"
VERSION=$(node -p "require('./package.json').version")
echo "VERSION = $VERSION"

echo "*************** building docker image  ***************"
docker build -t registry.edixchange.com/edixchange/ui:$VERSION .
docker images registry.edixchange.com/edixchange/ui

#docker push registry.edixchange.com/edixchange/ui:$VERSION
