const local = {
  auth: "/edixchange/apigateway/api/webedi/APIGateway",
  admin: "/edixchange/apigateway/api/webedi/APIGateway"
};

const prod = {
  auth: "/edixchange/apigateway/api/webedi/APIGateway",
  admin: "/edixchange/apigateway/api/webedi/APIGateway"
};

const config = process.env.ENVIRONMENT === "prod" ? prod : local;

export default {
  ...config
};
