import React from "react";
import ReactDOM from "react-dom";
import { createBrowserHistory, createHashHistory } from "history";
import { Router, Route, Switch, Redirect } from "react-router-dom";

import AuthLayout from "layouts/Auth.jsx";
import AdminLayout from "layouts/Admin.jsx";
import { Provider } from "react-redux";
import store from "./store";
import "assets/scss/material-dashboard-pro-react.scss?v=1.5.0";
import { PrivateRoute } from "./routes/PrivateRoute";

const hist = createBrowserHistory();

const hashHist = createHashHistory();

ReactDOM.render(
  <Provider store={store}>
    <Router history={hashHist}>
      <Switch>
        <Route path="/auth" component={AuthLayout} />
        <PrivateRoute path="/admin" component={AdminLayout} />
        <Redirect from="/" to="/admin/dashboard" />
      </Switch>
    </Router>
  </Provider>,
  document.getElementById("root")
);
