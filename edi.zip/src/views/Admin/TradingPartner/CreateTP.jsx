import React from "react";

import connect from "react-redux/es/connect/connect";
import {
  fetchTradingPartner,
  storeTradingPartner
} from "../../../_actions/admin.action";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
import FormLabel from "@material-ui/core/FormLabel";
import InputAdornment from "@material-ui/core/InputAdornment";
// material ui icons
import MailOutline from "@material-ui/icons/MailOutline";
import Close from "@material-ui/icons/Close";
// core components
import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import CustomInput from "components/CustomInput/CustomInput.jsx";
import Button from "components/CustomButtons/Button.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardFooter from "components/Card/CardFooter.jsx";

import { adminService } from "../../../_services/admin.service";
// style for this view
import validationFormsStyle from "assets/jss/material-dashboard-pro-react/views/validationFormsStyle.jsx";
import Select from "react-select";

let defaultTradingPartner = {
  userFriendlyPartnerId: "",
  ediId: "",
  corporationName: "",
  orgUnitName: "",
  isEDISystem: false,
  routing: "",
  isActive: false,
  accountid: ""
};
class CreateTP extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedId: new URLSearchParams(this.props.location.search).get("id")
        ? new URLSearchParams(this.props.location.search).get("id")
        : 0,
      selectedTradingPartner: {},
      errorMap: {},
      accounts: [],
      account: {}
    };
    this.registerClick = this.registerClick.bind(this);
    this.loginClick = this.loginClick.bind(this);
    this.typeClick = this.typeClick.bind(this);
    this.rangeClick = this.rangeClick.bind(this);
    this.submit = this.submit.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    adminService.listOfAccounts().then(accounts => {
      accounts.map(c => {
        c.label = c.corpname;
        c.value = c.id;
        c.id = c.id;
      });
      if (this.state.selectedId != undefined || this.state.selectedId != 0) {
        adminService.getTpById(this.state.selectedId).then(tradingPartner => {
          console.log("Got tradingPartnert by id... {}", tradingPartner);
          if (tradingPartner == undefined || tradingPartner.id == undefined) {
            this.setState({
              accounts: accounts,
              selectedTradingPartner: defaultTradingPartner,
              errorMap: {},
              account: {}
            });
          } else {
            let account = {};
            if (tradingPartner.accountid != undefined) {
              account = accounts.find(
                account => account.id == tradingPartner.accountid
              );
            }
            this.setState({
              accounts: accounts,
              selectedTradingPartner: tradingPartner,
              errorMap: {},
              account: account
            });
          }
        });
      } else {
        this.setState({
          accounts: accounts,
          selectedTradingPartner: defaultTradingPartner,
          errorMap: {},
          account: {}
        });
      }
    });
  }

  handleChange(name, value) {
    let account = this.state.accounts.find(account => account.id == value.id);
    this.setState({ account: account });
  }

  // function that returns true if value is email, false otherwise
  verifyEmail(value) {
    var emailRex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (emailRex.test(value)) {
      return true;
    }
    return false;
  }
  // function that verifies if a string has a given length or not
  verifyLength(value, length) {
    if (value.length >= length) {
      return true;
    }
    return false;
  }
  // function that verifies if two strings are equal
  compare(string1, string2) {
    if (string1 === string2) {
      return true;
    }
    return false;
  }
  // function that verifies if value contains only numbers
  verifyNumber(value) {
    var numberRex = new RegExp("^[0-9]+$");
    if (numberRex.test(value)) {
      return true;
    }
    return false;
  }
  // verifies if value is a valid URL
  verifyUrl(value) {
    try {
      new URL(value);
      return true;
    } catch (_) {
      return false;
    }
  }
  change(event, stateName, type, stateNameEqualTo, maxValue) {
    let errorMap = this.state.errorMap;
    switch (type) {
      case "email":
        if (this.verifyEmail(event.target.value)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "password":
        if (this.verifyLength(event.target.value, 1)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "equalTo":
        if (this.compare(event.target.value, this.state[stateNameEqualTo])) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "checkbox":
        if (event.target.checked) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "number":
        if (this.verifyNumber(event.target.value)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "length":
        if (this.verifyLength(event.target.value, stateNameEqualTo)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "max-length":
        if (!this.verifyLength(event.target.value, stateNameEqualTo + 1)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "url":
        if (this.verifyUrl(event.target.value)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "min-value":
        if (
          this.verifyNumber(event.target.value) &&
          event.target.value >= stateNameEqualTo
        ) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "max-value":
        if (
          this.verifyNumber(event.target.value) &&
          event.target.value <= stateNameEqualTo
        ) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "range":
        if (
          this.verifyNumber(event.target.value) &&
          event.target.value >= stateNameEqualTo &&
          event.target.value <= maxValue
        ) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        break;
      default:
        break;
    }
    let selectedTradingPartner = this.state.selectedTradingPartner;
    switch (type) {
      case "checkbox":
        selectedTradingPartner[stateName] = event.target.checked;
        break;
      default:
        selectedTradingPartner[stateName] = event.target.value;
        break;
    }
    this.setState({
      selectedTradingPartner: selectedTradingPartner,
      errorMap: errorMap
    });
  }
  registerClick() {
    if (this.state.registerEmailState === "") {
      this.setState({ registerEmailState: "error" });
    }
    if (this.state.registerPasswordState === "") {
      this.setState({ registerPasswordState: "error" });
    }
    if (this.state.registerConfirmPasswordState === "") {
      this.setState({ registerConfirmPasswordState: "error" });
    }
    if (this.state.registerCheckboxState === "") {
      this.setState({ registerCheckboxState: "error" });
    }
  }
  loginClick() {
    if (this.state.loginEmailState === "") {
      this.setState({ loginEmailState: "error" });
    }
    if (this.state.loginPasswordState === "") {
      this.setState({ loginPasswordState: "error" });
    }
  }
  submit() {
    // alert(JSON.stringify(this.state.account))
    // alert(JSON.stringify(this.state.selectedUser));
    let selectedTradingPartner = this.state.selectedTradingPartner;
    selectedTradingPartner.accountid = this.state.account.id;
    adminService.saveTp(selectedTradingPartner).then(res => {
      this.props.history.push("/admin/list-tps?tp-saved=true");
    });
  }
  typeClick() {
    if (this.state.requiredState === "") {
      this.setState({ requiredState: "error" });
    }
    if (this.state.typeEmailState === "") {
      this.setState({ typeEmailState: "error" });
    }
    if (this.state.numberState === "") {
      this.setState({ numberState: "error" });
    }
    if (this.state.urlState === "") {
      this.setState({ urlState: "error" });
    }
    if (this.state.equalToState === "") {
      this.setState({ equalToState: "error" });
    }
  }
  rangeClick() {
    if (this.state.minLengthState === "") {
      this.setState({ minLengthState: "error" });
    }
    if (this.state.maxLengthState === "") {
      this.setState({ maxLengthState: "error" });
    }
    if (this.state.rangeState === "") {
      this.setState({ rangeState: "error" });
    }
    if (this.state.minValueState === "") {
      this.setState({ minValueState: "error" });
    }
    if (this.state.maxValueState === "") {
      this.setState({ maxValueState: "error" });
    }
  }

  render() {
    const { classes } = this.props;
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="success" icon>
              <CardIcon color="success">
                <MailOutline />
              </CardIcon>
              <h4 className={classes.cardIconTitle}>
                {this.state.selectedTradingPartner != null &&
                this.state.selectedTradingPartner.id != 0
                  ? "Edit Trading Partner"
                  : "Create New"}
              </h4>
            </CardHeader>
            <CardBody>
              <form>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Corporation Name
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={
                        this.state.errorMap.corporationName === "success"
                      }
                      error={this.state.errorMap.corporationName === "error"}
                      id="corporationName"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "corporationName", "length", 3),
                        type: "text",
                        value: this.state.selectedTradingPartner.corporationName,
                        endAdornment:
                          this.state.errorMap.corporationName === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Edi Id
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.ediId === "success"}
                      error={this.state.errorMap.ediId === "error"}
                      id="ediId"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "ediId", "length", 3),
                        type: "text",
                        value: this.state.selectedTradingPartner.ediId,
                        endAdornment:
                          this.state.errorMap.ediId === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Org Unit Name
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.orgUnitName === "success"}
                      error={this.state.errorMap.orgUnitName === "error"}
                      id="orgUnitName"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "orgUnitName", "length", 3),
                        type: "text",
                        value: this.state.selectedTradingPartner.orgUnitName,
                        endAdornment:
                          this.state.errorMap.orgUnitName === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Routing
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.routing === "success"}
                      error={this.state.errorMap.routing === "error"}
                      id="routing"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "routing", "length", 3),
                        type: "text",
                        value: this.state.selectedTradingPartner.routing,
                        endAdornment:
                          this.state.errorMap.routing === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      User Friendly Partner Id
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={
                        this.state.errorMap.userFriendlyPartnerId === "success"
                      }
                      error={
                        this.state.errorMap.userFriendlyPartnerId === "error"
                      }
                      id="userFriendlyPartnerId"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(
                            event,
                            "userFriendlyPartnerId",
                            "length",
                            3
                          ),
                        type: "text",
                        value: this.state.selectedTradingPartner.userFriendlyPartnerId,
                        endAdornment:
                          this.state.errorMap.userFriendlyPartnerId ===
                          "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Account Id
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <Select
                      className="primary react-select"
                      classNamePrefix="react-select"
                      placeholder="Select"
                      name="account"
                      onChange={option => this.handleChange("account", option)}
                      options={this.state.accounts}
                      value={this.state.account.label ? this.state.account : ""}
                      style={{ marginTop: "4%" }}
                    />
                  </GridItem>
                </GridContainer>
              </form>
            </CardBody>
            <CardFooter className={classes.justifyContentCenter}>
              <Button color="success" onClick={this.submit}>
                Submit
              </Button>
            </CardFooter>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}
const mapStateToProps = state => ({
  tradingPartner: state.admin.tradingPartner
});
export default connect(
  mapStateToProps,
  { fetchTradingPartner, storeTradingPartner },
  null,
  { withRef: false }
)(withStyles(validationFormsStyle)(CreateTP));
