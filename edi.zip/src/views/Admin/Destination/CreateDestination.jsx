import React from "react";

import connect from "react-redux/es/connect/connect";
import {
  fetchDestination,
  storeDestination
} from "../../../_actions/admin.action";

// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Checkbox from "@material-ui/core/Checkbox";
import InputAdornment from "@material-ui/core/InputAdornment";
// material ui icons
import MailOutline from "@material-ui/icons/MailOutline";
import Contacts from "@material-ui/icons/Contacts";
import Check from "@material-ui/icons/Check";
import Close from "@material-ui/icons/Close";
// core components
import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import CustomInput from "components/CustomInput/CustomInput.jsx";
import Button from "components/CustomButtons/Button.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardText from "components/Card/CardText.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardFooter from "components/Card/CardFooter.jsx";

import { adminService } from "../../../_services/admin.service";

// style for this view
import validationFormsStyle from "assets/jss/material-dashboard-pro-react/views/validationFormsStyle.jsx";
import Select from "react-select";

let defaultDestination = {
  protocol: "",
  host: "",
  primaryaddress: "",
  port: "",
  userName: "",
  password: "",
  partnerId: 0,
  location: ""
};

class CreateDestination extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedId: new URLSearchParams(this.props.location.search).get("id")
        ? new URLSearchParams(this.props.location.search).get("id")
        : 0,
      selectedDestination: {},
      errorMap: {},
      tradingPartners: [],
      tradingPartner: {}
    };
    this.registerClick = this.registerClick.bind(this);
    this.loginClick = this.loginClick.bind(this);
    this.typeClick = this.typeClick.bind(this);
    this.rangeClick = this.rangeClick.bind(this);
    this.submit = this.submit.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    adminService.listOfTps().then(tradingPartners => {
      tradingPartners.map(c => {
        c.label = c.corporationName;
        c.value = c.id;
        c.id = c.id;
      });
      if (this.state.selectedId != undefined || this.state.selectedId != 0) {
        adminService
          .getDestinationById(this.state.selectedId)
          .then(destination => {
            console.log("Got destination by id... {}", destination);
            if (destination == undefined || destination.id == undefined) {
              this.setState({
                tradingPartners: tradingPartners,
                selectedDestination: defaultDestination,
                errorMap: {},
                tradingPartner: {}
              });
            } else {
              let tradingPartner = {};
              if (destination.partnerId != undefined) {
                tradingPartner = tradingPartners.find(
                  tradingPartner => tradingPartner.id === destination.partnerId
                );
              }
              this.setState({
                tradingPartners: tradingPartners,
                selectedDestination: destination,
                errorMap: {},
                tradingPartner: tradingPartner
              });
            }
          });
      } else {
        this.setState({
          tradingPartners: tradingPartners,
          selectedTradingPartner: defaultDestination,
          errorMap: {},
          tradingPartner: {}
        });
      }
    });
  }

  handleChange(name, value) {
    let tradingPartner = this.state.tradingPartners.find(
      tradingPartner => tradingPartner.id == value.id
    );
    this.setState({ tradingPartner: tradingPartner });
  }
  // function that returns true if value is email, false otherwise
  verifyEmail(value) {
    var emailRex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (emailRex.test(value)) {
      return true;
    }
    return false;
  }
  // function that verifies if a string has a given length or not
  verifyLength(value, length) {
    if (value.length >= length) {
      return true;
    }
    return false;
  }
  // function that verifies if two strings are equal
  compare(string1, string2) {
    if (string1 === string2) {
      return true;
    }
    return false;
  }
  // function that verifies if value contains only numbers
  verifyNumber(value) {
    var numberRex = new RegExp("^[0-9]+$");
    if (numberRex.test(value)) {
      return true;
    }
    return false;
  }
  // verifies if value is a valid URL
  verifyUrl(value) {
    try {
      new URL(value);
      return true;
    } catch (_) {
      return false;
    }
  }
  change(event, stateName, type, stateNameEqualTo, maxValue) {
    let errorMap = this.state.errorMap;
    switch (type) {
      case "email":
        if (this.verifyEmail(event.target.value)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "password":
        if (this.verifyLength(event.target.value, 1)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "equalTo":
        if (this.compare(event.target.value, this.state[stateNameEqualTo])) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "checkbox":
        if (event.target.checked) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "number":
        if (this.verifyNumber(event.target.value)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "length":
        if (this.verifyLength(event.target.value, stateNameEqualTo)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "max-length":
        if (!this.verifyLength(event.target.value, stateNameEqualTo + 1)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "url":
        if (this.verifyUrl(event.target.value)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "min-value":
        if (
          this.verifyNumber(event.target.value) &&
          event.target.value >= stateNameEqualTo
        ) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "max-value":
        if (
          this.verifyNumber(event.target.value) &&
          event.target.value <= stateNameEqualTo
        ) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "range":
        if (
          this.verifyNumber(event.target.value) &&
          event.target.value >= stateNameEqualTo &&
          event.target.value <= maxValue
        ) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        break;
      default:
        break;
    }
    let selectedDestination = this.state.selectedDestination;
    switch (type) {
      case "checkbox":
        selectedDestination[stateName] = event.target.checked;
        break;
      default:
        selectedDestination[stateName] = event.target.value;
        break;
    }
    this.setState({
      selectedDestination: selectedDestination,
      errorMap: errorMap
    });
  }
  registerClick() {
    if (this.state.registerEmailState === "") {
      this.setState({ registerEmailState: "error" });
    }
    if (this.state.registerPasswordState === "") {
      this.setState({ registerPasswordState: "error" });
    }
    if (this.state.registerConfirmPasswordState === "") {
      this.setState({ registerConfirmPasswordState: "error" });
    }
    if (this.state.registerCheckboxState === "") {
      this.setState({ registerCheckboxState: "error" });
    }
  }
  loginClick() {
    if (this.state.loginEmailState === "") {
      this.setState({ loginEmailState: "error" });
    }
    if (this.state.loginPasswordState === "") {
      this.setState({ loginPasswordState: "error" });
    }
  }
  submit() {
    let selectedDestination = this.state.selectedDestination;
    selectedDestination.partnerId = this.state.tradingPartner.id;
    adminService.saveDestination(selectedDestination).then(res => {
      this.props.history.push("/admin/list-dest?dest-saved=true");
    });
  }
  typeClick() {
    if (this.state.requiredState === "") {
      this.setState({ requiredState: "error" });
    }
    if (this.state.typeEmailState === "") {
      this.setState({ typeEmailState: "error" });
    }
    if (this.state.numberState === "") {
      this.setState({ numberState: "error" });
    }
    if (this.state.urlState === "") {
      this.setState({ urlState: "error" });
    }
    if (this.state.equalToState === "") {
      this.setState({ equalToState: "error" });
    }
  }
  rangeClick() {
    if (this.state.minLengthState === "") {
      this.setState({ minLengthState: "error" });
    }
    if (this.state.maxLengthState === "") {
      this.setState({ maxLengthState: "error" });
    }
    if (this.state.rangeState === "") {
      this.setState({ rangeState: "error" });
    }
    if (this.state.minValueState === "") {
      this.setState({ minValueState: "error" });
    }
    if (this.state.maxValueState === "") {
      this.setState({ maxValueState: "error" });
    }
  }

  render() {
    const { classes } = this.props;
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="success" icon>
              <CardIcon color="success">
                <MailOutline />
              </CardIcon>
              <h4 className={classes.cardIconTitle}>
                {this.state.selectedDestination != null &&
                this.state.selectedDestination.id != 0
                  ? "Edit Destination"
                  : "Create New Destination"}
              </h4>
            </CardHeader>
            <CardBody>
              <form>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Host
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.host === "success"}
                      error={this.state.errorMap.host === "error"}
                      id="host"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "host", "length", 3),
                        type: "text",
                        value: this.state.selectedDestination.host,
                        endAdornment:
                          this.state.errorMap.host === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Location
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.location === "success"}
                      error={this.state.errorMap.location === "error"}
                      id="location"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "location", "length", 3),
                        type: "text",
                        value: this.state.selectedDestination.location,
                        endAdornment:
                          this.state.errorMap.location === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Port
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.port === "success"}
                      error={this.state.errorMap.port === "error"}
                      id="port"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "port", "length", 3),
                        type: "text",
                        value: this.state.selectedDestination.port,
                        endAdornment:
                          this.state.errorMap.port === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Primary Address
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.primaryaddress === "success"}
                      error={this.state.errorMap.primaryaddress === "error"}
                      id="primaryaddress"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "primaryaddress", "length", 3),
                        type: "text",
                        value: this.state.selectedDestination.primaryaddress,
                        endAdornment:
                          this.state.errorMap.primaryaddress === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Protocol
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.protocol === "success"}
                      error={this.state.errorMap.protocol === "error"}
                      id="protocol"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "protocol", "length", 3),
                        type: "text",
                        value: this.state.selectedDestination.protocol,
                        endAdornment:
                          this.state.errorMap.protocol === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Related Partner
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <Select
                      className="primary react-select"
                      classNamePrefix="react-select"
                      placeholder="Select"
                      name="partner"
                      onChange={option => this.handleChange("partner", option)}
                      options={this.state.tradingPartners}
                      value={
                        this.state.tradingPartner.label
                          ? this.state.tradingPartner
                          : ""
                      }
                      style={{ marginTop: "4%" }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Username
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.username === "success"}
                      error={this.state.errorMap.username === "error"}
                      id="username"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "username", "length", 3),
                        type: "text",
                        value: this.state.selectedDestination.username,
                        endAdornment:
                          this.state.errorMap.username === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Password
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.password === "success"}
                      error={this.state.errorMap.password === "error"}
                      id="password"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "password", "length", 3),
                        type: "password",
                        value: this.state.selectedDestination.password,
                        endAdornment:
                          this.state.errorMap.password === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
              </form>
            </CardBody>
            <CardFooter className={classes.justifyContentCenter}>
              <Button color="success" onClick={this.submit}>
                Submit
              </Button>
            </CardFooter>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}
const mapStateToProps = state => ({
  destination: state.admin.destination
});
export default connect(
  mapStateToProps,
  { storeDestination, fetchDestination },
  null,
  { withRef: false }
)(withStyles(validationFormsStyle)(CreateDestination));
