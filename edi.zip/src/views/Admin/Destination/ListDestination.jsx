import React from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";
import PropTypes from "prop-types";
import green from "@material-ui/core/colors/green";
import amber from "@material-ui/core/colors/amber";
import classNames from "classnames";

// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
// @material-ui/icons
import Assignment from "@material-ui/icons/Assignment";
import Dvr from "@material-ui/icons/Dvr";
import Favorite from "@material-ui/icons/Favorite";
import Close from "@material-ui/icons/Close";
import Edit from "@material-ui/icons/Edit";
// core components
import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import Button from "components/CustomButtons/Button.jsx";
import Card from "components/Card/Card.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import CardHeader from "components/Card/CardHeader.jsx";

import { cardTitle } from "assets/jss/material-dashboard-pro-react.jsx";
import { adminService } from "../../../_services/admin.service";
import Snackbar from "@material-ui/core/Snackbar";
import SnackbarContent from "@material-ui/core/SnackbarContent";
import IconButton from "@material-ui/core/IconButton";

const styles = {
  cardIconTitle: {
    ...cardTitle,
    marginTop: "15px",
    marginBottom: "0px"
  },
  icon: {
    verticalAlign: "middle",
    width: "10px",
    height: "10px",
    top: "-1px",
    position: "relative"
  },
  actionButtonRound: {
    margin: "0 0 0 5px",
    padding: "5px",
    "& svg,& .fab,& .fas,& .far,& .fal,& .material-icons": {
      marginRight: "0px"
    },
    width: "auto",
    height: "auto",
    minWidth: "auto"
  }
};

const messageStyles = theme => ({
  success: {
    backgroundColor: green[600]
  },
  error: {
    backgroundColor: theme.palette.error.dark
  },
  info: {
    backgroundColor: theme.palette.primary.light
  },
  warning: {
    backgroundColor: amber[700]
  },
  icon: {
    fontSize: 20
  },
  iconVariant: {
    opacity: 0.9,
    marginRight: theme.spacing.unit
  },
  message: {
    display: "flex",
    alignItems: "center"
  }
});

function MessageContent(props) {
  const { classes, className, message, onClose, variant, ...other } = props;
  // const Icon = variantIcon[variant];

  return (
    <SnackbarContent
      className={classNames(classes[variant], className)}
      aria-describedby="client-snackbar"
      message={
        <span id="client-snackbar" className={classes.message}>
          {/*<Icon className={classNames(classes.icon, classes.iconVariant)}/>*/}
          {message}
        </span>
      }
      action={[
        <IconButton
          key="close"
          aria-label="Close"
          color="inherit"
          className={classes.close}
          onClick={onClose}
        >
          {/*// <CloseIcon className={classes.icon}/>*/}
        </IconButton>
      ]}
      {...other}
    />
  );
}

MessageContent.propTypes = {
  classes: PropTypes.object.isRequired,
  className: PropTypes.string,
  message: PropTypes.node,
  onClose: PropTypes.func,
  variant: PropTypes.oneOf(["success", "warning", "error", "info"]).isRequired
};

const MySnackbarContentWrapper = withStyles(messageStyles)(MessageContent);

class ListDestination extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showDestSavedMessage: new URLSearchParams(this.props.location.search).get(
        "dest-saved"
      )
        ? true
        : false
    };
  }

  handleMessageClose = event => {
    this.setState({ showDestSavedMessage: false });
  };

  componentDidMount() {
    adminService.listOfDestinations().then(destinations => {
      console.log("Got list of destinations...");
      this.setState({
        data: destinations.map(destination => {
          return {
            id: destination.id,
            username: destination.username,
            host: destination.host,
            location: destination.location,
            relatedPartner: destination.partnerId,
            actions: (
              // we've added some custom button actions
              <div className="actions-right">
                <Button
                  round
                  onClick={() => {
                    let obj = this.state.data.find(
                      o => o.id === destination.id
                    );
                    alert(
                      "You've clicked EDIT button on \n{ \nUsername: " +
                        obj.username +
                        ", \nHost: " +
                        obj.host +
                        ", \nLocation: " +
                        obj.location +
                        ", \nPartner: " +
                        obj.relatedPartner +
                        "\n}."
                    );
                    this.props.history.push(
                      "/admin/create-dest?id=" + destination.id
                    );
                  }}
                  color="warning"
                  className={styles.actionButtonRound}
                >
                  <Edit className={styles.icon} />
                </Button>{" "}
                {/* use this button to remove the data row */}
                <Button
                  round
                  onClick={() => {
                    var data = this.state.data;
                    data.find((o, i) => {
                      if (o.id === destination.id) {
                        // here you should add some custom code so you can delete the data
                        // from this component and from your server as well
                        data.splice(i, 1);
                        return true;
                      }
                      return false;
                    });
                    this.setState({ data: data });
                  }}
                  color="danger"
                  className={styles.actionButtonRound}
                >
                  <Close className={styles.icon} />
                </Button>{" "}
              </div>
            )
          };
        })
      });
    });
  }
  render() {
    const { classes } = this.props;
    return (
      <GridContainer>
        <GridItem xs={12}>
          <Card>
            <CardHeader color="info" icon>
              <CardIcon color="info">
                <Assignment />
              </CardIcon>
              <h4 className={classes.cardIconTitle}>List of Destinations</h4>
            </CardHeader>
            <CardBody>
              <ReactTable
                data={this.state.data}
                filterable
                columns={[
                  {
                    Header: "Username",
                    accessor: "username"
                  },
                  {
                    Header: "Host",
                    accessor: "host"
                  },
                  {
                    Header: "Location",
                    accessor: "location"
                  },
                  {
                    Header: "Related Partner",
                    accessor: "relatedPartner"
                  },
                  {
                    Header: "Actions",
                    accessor: "actions",
                    sortable: false,
                    filterable: false
                  }
                ]}
                defaultPageSize={10}
                showPaginationTop
                showPaginationBottom={false}
                className="-striped -highlight"
              />
            </CardBody>
          </Card>
        </GridItem>
        <Snackbar
          anchorOrigin={{
            vertical: "top",
            horizontal: "center"
          }}
          open={this.state.showDestSavedMessage}
          autoHideDuration={5000}
          onClose={this.handleMessageClose}
        >
          <MySnackbarContentWrapper
            onClose={this.handleMessageClose}
            variant="success"
            message="Account saved successfully"
          />
        </Snackbar>
      </GridContainer>
    );
  }
}
ListDestination.propTypes = {
  classes: PropTypes.object.isRequired,
  onClose: PropTypes.func,
  variant: PropTypes.oneOf(["success", "warning", "error", "info"]).isRequired
};
export default withStyles(styles)(ListDestination);
