import React from "react";

import connect from "react-redux/es/connect/connect";
import { fetchAccount, storeAccount } from "../../../_actions/admin.action";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
import FormLabel from "@material-ui/core/FormLabel";
import InputAdornment from "@material-ui/core/InputAdornment";
// material ui icons
import MailOutline from "@material-ui/icons/MailOutline";
import Close from "@material-ui/icons/Close";
// core components
import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import CustomInput from "components/CustomInput/CustomInput.jsx";
import Button from "components/CustomButtons/Button.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardFooter from "components/Card/CardFooter.jsx";

import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";

import { adminService } from "../../../_services/admin.service";
// style for this view
import validationFormsStyle from "assets/jss/material-dashboard-pro-react/views/validationFormsStyle.jsx";

let defaultAccount = {
  corpname: "",
  orgunit: "",
  ediflag: false,
  activeflag: false,
  type: "",
  apptype: "",
  fname: "",
  lname: "",
  add1: "",
  add2: "",
  add3: "",
  city: "",
  state: "",
  zipcode: "",
  email: "",
  phone: "",
  fax: "",
  id: 0
};
class CreateAccount extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedId: new URLSearchParams(this.props.location.search).get("id")
        ? new URLSearchParams(this.props.location.search).get("id")
        : 0,
      selectedAccount: {},
      errorMap: {}
    };
    this.registerClick = this.registerClick.bind(this);
    this.loginClick = this.loginClick.bind(this);
    this.typeClick = this.typeClick.bind(this);
    this.rangeClick = this.rangeClick.bind(this);
    this.submit = this.submit.bind(this);
  }

  componentDidMount() {
    // if (this.props.account != null || this.props.account != undefined) {
    //   let selectedAccount = this.props.account;
    //   this.setState({
    //     selectedAccount: selectedAccount,
    //     errorMap: {}
    //   });
    // }

    if (this.state.selectedId != undefined || this.state.selectedId != 0) {
      adminService.getAccountById(this.state.selectedId).then(account => {
        console.log("Got account by id... {}", account);
        if (account == undefined || account.id == undefined) {
          this.setState({ selectedAccount: defaultAccount, errorMap: {} });
        } else {
          this.setState({ selectedAccount: account, errorMap: {} });
        }
      });
    } else {
      this.setState({ selectedAccount: defaultAccount, errorMap: {} });
    }
  }
  componentWillReceiveProps(newProps) {
    // let selectedAccount = newProps.account;
    // this.setState({
    //   selectedAccount: selectedAccount,
    //   errorMap: {}
    // });
  }

  // function that returns true if value is email, false otherwise
  verifyEmail(value) {
    var emailRex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (emailRex.test(value)) {
      return true;
    }
    return false;
  }
  // function that verifies if a string has a given length or not
  verifyLength(value, length) {
    if (value.length >= length) {
      return true;
    }
    return false;
  }
  // function that verifies if two strings are equal
  compare(string1, string2) {
    if (string1 === string2) {
      return true;
    }
    return false;
  }
  // function that verifies if value contains only numbers
  verifyNumber(value) {
    var numberRex = new RegExp("^[0-9]+$");
    if (numberRex.test(value)) {
      return true;
    }
    return false;
  }
  // verifies if value is a valid URL
  verifyUrl(value) {
    try {
      new URL(value);
      return true;
    } catch (_) {
      return false;
    }
  }
  change(event, stateName, type, stateNameEqualTo, maxValue) {
    let errorMap = this.state.errorMap;
    switch (type) {
      case "email":
        if (this.verifyEmail(event.target.value)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "password":
        if (this.verifyLength(event.target.value, 1)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "equalTo":
        if (this.compare(event.target.value, this.state[stateNameEqualTo])) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "checkbox":
        if (event.target.checked) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "number":
        if (this.verifyNumber(event.target.value)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "length":
        if (this.verifyLength(event.target.value, stateNameEqualTo)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "max-length":
        if (!this.verifyLength(event.target.value, stateNameEqualTo + 1)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "url":
        if (this.verifyUrl(event.target.value)) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "min-value":
        if (
          this.verifyNumber(event.target.value) &&
          event.target.value >= stateNameEqualTo
        ) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "max-value":
        if (
          this.verifyNumber(event.target.value) &&
          event.target.value <= stateNameEqualTo
        ) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        this.setState({ errorMap: errorMap });
        break;
      case "range":
        if (
          this.verifyNumber(event.target.value) &&
          event.target.value >= stateNameEqualTo &&
          event.target.value <= maxValue
        ) {
          errorMap[stateName] = "success";
        } else {
          errorMap[stateName] = "error";
        }
        break;
      default:
        break;
    }
    let selectedAccount = this.state.selectedAccount;
    switch (type) {
      case "checkbox":
        selectedAccount[stateName] = event.target.checked;
        break;
      default:
        selectedAccount[stateName] = event.target.value;
        break;
    }
    this.setState({ selectedAccount: selectedAccount, errorMap: errorMap });
  }
  registerClick() {
    if (this.state.registerEmailState === "") {
      this.setState({ registerEmailState: "error" });
    }
    if (this.state.registerPasswordState === "") {
      this.setState({ registerPasswordState: "error" });
    }
    if (this.state.registerConfirmPasswordState === "") {
      this.setState({ registerConfirmPasswordState: "error" });
    }
    if (this.state.registerCheckboxState === "") {
      this.setState({ registerCheckboxState: "error" });
    }
  }
  loginClick() {
    if (this.state.loginEmailState === "") {
      this.setState({ loginEmailState: "error" });
    }
    if (this.state.loginPasswordState === "") {
      this.setState({ loginPasswordState: "error" });
    }
  }
  submit() {
    adminService.saveAccount(this.state.selectedAccount).then(res => {
      this.props.history.push("/admin/list-accounts?account-saved=true");
    });
  }
  typeClick() {
    if (this.state.requiredState === "") {
      this.setState({ requiredState: "error" });
    }
    if (this.state.typeEmailState === "") {
      this.setState({ typeEmailState: "error" });
    }
    if (this.state.numberState === "") {
      this.setState({ numberState: "error" });
    }
    if (this.state.urlState === "") {
      this.setState({ urlState: "error" });
    }
    if (this.state.equalToState === "") {
      this.setState({ equalToState: "error" });
    }
  }
  rangeClick() {
    if (this.state.minLengthState === "") {
      this.setState({ minLengthState: "error" });
    }
    if (this.state.maxLengthState === "") {
      this.setState({ maxLengthState: "error" });
    }
    if (this.state.rangeState === "") {
      this.setState({ rangeState: "error" });
    }
    if (this.state.minValueState === "") {
      this.setState({ minValueState: "error" });
    }
    if (this.state.maxValueState === "") {
      this.setState({ maxValueState: "error" });
    }
  }

  render() {
    const { classes } = this.props;
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="success" icon>
              <CardIcon color="success">
                <MailOutline />
              </CardIcon>
              <h4 className={classes.cardIconTitle}>
                {this.state.selectedAccount != null &&
                this.state.selectedAccount.id != 0
                  ? "Edit Account"
                  : "Create New"}
              </h4>
            </CardHeader>
            <CardBody>
              <form>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Corp Name
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.corpname === "success"}
                      error={this.state.errorMap.corpname === "error"}
                      id="corpname"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "corpname", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.corpname,
                        endAdornment:
                          this.state.errorMap.corpname === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Org Unit
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.orgunit === "success"}
                      error={this.state.errorMap.orgunit === "error"}
                      id="orgunit"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "orgunit", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.orgunit,
                        endAdornment:
                          this.state.errorMap.orgunit === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      is EDI?
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    {/*<CustomInput*/}
                    {/*id="ediflag"*/}
                    {/*formControlProps={{*/}
                    {/*fullWidth: true*/}
                    {/*}}*/}
                    {/*inputProps={{*/}
                    {/*onChange: event =>*/}
                    {/*this.change(event, "ediflag", "length", 3),*/}
                    {/*type: "checkbox",*/}
                    {/*checked: this.state.selectedAccount.ediflag*/}
                    {/*}}*/}
                    {/*/>*/}
                    <FormControlLabel
                      value="top"
                      control={
                        <Checkbox
                          color="primary"
                          checked={this.state.selectedAccount.ediflag}
                          onChange={event =>
                            this.change(event, "ediflag", "checkbox")
                          }
                        />
                      }
                      label=""
                      labelPlacement="top"
                      style={{ marginTop: "40px" }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Type
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.type === "success"}
                      error={this.state.errorMap.type === "error"}
                      id="type"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "type", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.type,
                        endAdornment:
                          this.state.errorMap.type === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      is Active?
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    {/*<CustomInput*/}
                    {/*success={this.state.errorMap.activeflag === "success"}*/}
                    {/*id="activeflag"*/}
                    {/*formControlProps={{*/}
                    {/*fullWidth: true*/}
                    {/*}}*/}
                    {/*inputProps={{*/}
                    {/*onChange: event =>*/}
                    {/*this.change(event, "activeflag", "length", 3),*/}
                    {/*type: "checkbox",*/}
                    {/*value: this.state.selectedAccount.activeflag*/}
                    {/*}}*/}
                    {/*/>*/}
                    <FormControlLabel
                      value="top"
                      control={
                        <Checkbox
                          color="primary"
                          checked={this.state.selectedAccount.activeflag}
                          onChange={event =>
                            this.change(event, "activeflag", "checkbox")
                          }
                        />
                      }
                      label=""
                      labelPlacement="top"
                      style={{ marginTop: "4%" }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      App Type
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.apptype === "success"}
                      error={this.state.errorMap.apptype === "error"}
                      id="apptype"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "apptype", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.apptype,
                        endAdornment:
                          this.state.errorMap.apptype === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Contact First Name
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.fname === "success"}
                      error={this.state.errorMap.fname === "error"}
                      id="fname"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "fname", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.fname,
                        endAdornment:
                          this.state.errorMap.fname === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Contact Last Name
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.lname === "success"}
                      error={this.state.errorMap.lname === "error"}
                      id="lname"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "lname", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.lname,
                        endAdornment:
                          this.state.errorMap.lname === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Address 1
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.add1 === "success"}
                      error={this.state.errorMap.add1 === "error"}
                      id="add1"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "add1", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.add1,
                        endAdornment:
                          this.state.errorMap.add1 === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Address 2
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.add2 === "success"}
                      error={this.state.errorMap.add2 === "error"}
                      id="add2"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "add2", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.add2,
                        endAdornment:
                          this.state.errorMap.add2 === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Address 3
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.add3 === "success"}
                      error={this.state.errorMap.add3 === "error"}
                      id="add3"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "add3", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.add3,
                        endAdornment:
                          this.state.errorMap.add3 === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      City
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.city === "success"}
                      error={this.state.errorMap.city === "error"}
                      id="city"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "city", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.city,
                        endAdornment:
                          this.state.errorMap.city === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      State
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.state === "success"}
                      error={this.state.errorMap.state === "error"}
                      id="state"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "state", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.state,
                        endAdornment:
                          this.state.errorMap.state === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Zipcode
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.zipcode === "success"}
                      error={this.state.errorMap.zipcode === "error"}
                      id="zipcode"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "zipcode", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.zipcode,
                        endAdornment:
                          this.state.errorMap.zipcode === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Email
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.email === "success"}
                      error={this.state.errorMap.email === "error"}
                      id="email"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "email", "length", 3),
                        type: "email",
                        value: this.state.selectedAccount.email,
                        endAdornment:
                          this.state.errorMap.email === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Phone
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.phone === "success"}
                      error={this.state.errorMap.phone === "error"}
                      id="phone"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "phone", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.phone,
                        endAdornment:
                          this.state.errorMap.phone === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={2}>
                    <FormLabel className={classes.labelHorizontal}>
                      Fax
                    </FormLabel>
                  </GridItem>
                  <GridItem xs={12} sm={7}>
                    <CustomInput
                      success={this.state.errorMap.fax === "success"}
                      error={this.state.errorMap.fax === "error"}
                      id="fax"
                      formControlProps={{
                        fullWidth: true
                      }}
                      inputProps={{
                        onChange: event =>
                          this.change(event, "fax", "length", 3),
                        type: "text",
                        value: this.state.selectedAccount.fax,
                        endAdornment:
                          this.state.errorMap.fax === "error" ? (
                            <InputAdornment position="end">
                              <Close className={classes.danger} />
                            </InputAdornment>
                          ) : (
                            undefined
                          )
                      }}
                    />
                  </GridItem>
                </GridContainer>
              </form>
            </CardBody>
            <CardFooter className={classes.justifyContentCenter}>
              <Button color="success" onClick={this.submit}>
                Submit
              </Button>
            </CardFooter>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}
const mapStateToProps = state => ({
  account: state.admin.account
});
export default connect(
  mapStateToProps,
  { storeAccount, fetchAccount },
  null,
  { withRef: false }
)(withStyles(validationFormsStyle)(CreateAccount));
