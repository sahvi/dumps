import config from "../_config/config";
import { data } from "./DemoData/data";
import axios from "axios";

export const adminService = {
  listOfAccounts,
  saveAccount,
  getAccountById,
  listOfDestinations,
  saveDestination,
  getDestinationById,
  listOfTps,
  saveTp,
  getTpById,
  listOfUsers,
  saveUser,
  getUserById,
  saveLogin,
  getLoginByUserId
};

const baseURL = config.admin;

function listOfAccounts() {
  return axios
    .get(`${baseURL}/getAllAccounts`)
    .then(res => {
      console.log("Accounts Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      console.log(error);
    });
  // return Promise.resolve(data);
}

function saveAccount(account) {
  axios.defaults.headers.post["Content-Type"] = "application/json";
  axios({
    method: "post",
    url: `${baseURL}/createAccount`,
    data: JSON.stringify(account),
    config: {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    }
  });
  return Promise.resolve('{"status": "success"}');
}

function getAccountById(id) {
  return axios
    .get(`${baseURL}/getAccountbyId?id=${id}`)
    .then(res => {
      console.log("Account Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      console.log(error);
    });
  // return Promise.resolve(data);
}

function listOfDestinations() {
  return axios
    .get(`${baseURL}/getAllDestinations`)
    .then(res => {
      console.log("Destinations Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      console.log(error);
    });
  // return Promise.resolve(data);
}

function saveDestination(destination) {
  axios.defaults.headers.post["Content-Type"] = "application/json";
  axios({
    method: "post",
    url: `${baseURL}/createDestination`,
    data: JSON.stringify(destination),
    config: {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    }
  });
  return Promise.resolve('{"status": "success"}');
}

function getDestinationById(id) {
  return axios
    .get(`${baseURL}/getDestinationbyID?id=${id}`)
    .then(res => {
      console.log("Destination Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      console.log(error);
    });
  // return Promise.resolve(data);
}

function listOfTps() {
  return axios
    .get(`${baseURL}/getAllTradingPartners`)
    .then(res => {
      console.log("Trading Partners Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      console.log(error);
    });
  // return Promise.resolve(data);
}

function saveTp(tradingPartner) {
  axios.defaults.headers.post["Content-Type"] = "application/json";
  axios({
    method: "post",
    url: `${baseURL}/createTradingPartner`,
    data: JSON.stringify(tradingPartner),
    config: {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    }
  });
  return Promise.resolve('{"status": "success"}');
}

function getTpById(id) {
  return axios
    .get(`${baseURL}/getTradingPartnerbyId?id=${id}`)
    .then(res => {
      console.log("Trading Partner Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      console.log(error);
    });
  // return Promise.resolve(data);
}

function listOfUsers() {
  return axios
    .get(`${baseURL}/getAllUsers`)
    .then(res => {
      console.log("Users Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      console.log(error);
    });
}

function saveUser(user) {
  axios.defaults.headers.post["Content-Type"] = "application/json";
  axios({
    method: "post",
    url: `${baseURL}/createUser`,
    data: JSON.stringify(user),
    config: {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    }
  }).then(res => {
    console.log('RESPONSE: '+ JSON.stringify(res))
    let login = {
      username: user.username,
      password: user.password,
      relateduserid: res.data.id
    };
    saveLogin(login);
  });
  return Promise.resolve('{"status": "success"}');
}

function saveLogin(login) {
  axios.defaults.headers.post["Content-Type"] = "application/json";
  axios({
    method: "post",
    url: `${baseURL}/createLogin`,
    data: JSON.stringify(login),
    config: {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    }
  });
  return Promise.resolve('{"status": "success"}');
}

function getLoginByUserId(usedid) {
  return axios
    .get(`${baseURL}/getLoginByUserId?userId=${usedid}`)
    .then(res => {
      console.log("User Login Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      console.log(error);
    });
  // return Promise.resolve(data);
}

function getUserById(id) {
  return axios
    .get(`${baseURL}/getUserbyId?id=${id}`)
    .then(res => {
      console.log("User Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      console.log(error);
    });
  // return Promise.resolve(data);
}
