import config from "../_config/config";
import axios from "axios";

export const authService = {
  login,
  logout
};

const baseURL = config.auth;

function login(username, password) {
  const data = {
    username: username,
    password: password
  };

  return axios
    .get(`${baseURL}/authenticateLogin?user=${username}&password=${password}`)
    .then(res => {
      console.log("User Data %o", res.data);
      return {
        authentication: true,
        username: res.data.username,
        fullName: res.data.username
      };
    })
    .catch(function(error) {
      console.log(error);
      return {
        authentication: false
      };
    });
}

function logout() {
  // remove user from local storage to log user out
  localStorage.removeItem("user");
  return "{}";
}

function handleResponse(response) {
  return response.text().then(text => {
    const data = text && JSON.parse(text);
    if (!response.ok) {
      if (response.status === 401) {
        // auto logout if 401 response returned from api
        logout();
        // location.reload(true);
      }

      const error = (data && data.message) || response.statusText;
      return Promise.reject(error);
    }

    return data;
  });
}
