import Dashboard from "layouts/Dashboard/Dashboard.jsx";
import React from "react";
import EditDesign from "../views/Design/EditDesign";

var indexRoutes = [
  { path: "/", name: "Home", component: Dashboard }
];

export default indexRoutes;
