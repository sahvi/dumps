import LoginPage from "../views/Login/LoginPage.jsx";
// @material-ui/icons

var authRoutes = [
  {
    path: "/login",
    name: "Login Page",
    mini: "L",
    component: LoginPage,
    layout: "/auth"
  }
];
export default authRoutes;
