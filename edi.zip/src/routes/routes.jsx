// import Calendar from "/src/views/Calendar/Calendar.jsx";
import Dashboard from "../views/Dashboard/Dashboard.jsx";
import ListPO from "../views/PO/ListPO.jsx";
import ValidationForms from "../views/Forms/ValidationForms.jsx";
import Widgets from "../views/Widgets/Widgets.jsx";
// @material-ui/icons
import DashboardIcon from "@material-ui/icons/Dashboard";
import Shipment from "@material-ui/icons/Flight";
import Invoice from "@material-ui/icons/EventNote";
import Save from "@material-ui/icons/Save";
import Settings from "@material-ui/icons/Settings";
import CreatePO from "../views/PO/CreatePO";
import Upload from "../views/Upload/Upload";
import StatusPO from "../views/PO/StatusPO";
import CreateAccount from "../views/Admin/Account/CreateAccount";
import ListAccounts from "../views/Admin/Account/ListAccounts";
import ListUsers from "../views/Admin/Users/ListUsers";
import CreateUser from "../views/Admin/Users/CreateUser";
import ListTP from "../views/Admin/TradingPartner/ListTP";
import CreateTP from "../views/Admin/TradingPartner/CreateTP";
import ListDestination from "../views/Admin/Destination/ListDestination";
import CreateDestination from "../views/Admin/Destination/CreateDestination";

var routes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: DashboardIcon,
    component: Dashboard,
    layout: "/admin"
  },
  {
    collapse: true,
    name: "Purchase Order",
    icon: "content_paste",
    state: "formsCollapse",
    views: [
      {
        path: "/create-new",
        name: "New POs",
        mini: "NP",
        component: CreatePO,
        layout: "/admin"
      },
      {
        path: "/extended-forms",
        name: "PO Acknowledgement",
        mini: "AC",
        component: ValidationForms,
        layout: "/admin"
      },
      {
        path: "/po-status",
        name: "PO Status",
        mini: "ST",
        component: StatusPO,
        layout: "/admin"
      },
      {
        path: "/po-listing",
        name: "PO Listing",
        mini: "LS",
        component: ListPO,
        layout: "/admin"
      }
    ]
  },
  {
    path: "/shipment",
    name: "Shipments",
    icon: Shipment,
    component: Widgets,
    layout: "/admin"
  },
  {
    path: "/invoice",
    name: "Invoice",
    icon: Invoice,
    component: Widgets,
    layout: "/admin"
  },
  {
    path: "/upload",
    name: "Upload",
    icon: Save,
    component: Upload,
    layout: "/admin"
  },
  {
    collapse: true,
    name: "Admin",
    icon: Settings,
    state: "adminCollapse",
    views: [
      {
        path: "/list-accounts",
        name: "List Accounts",
        mini: "LA",
        component: ListAccounts,
        layout: "/admin"
      },
      {
        path: "/create-account",
        name: "Create Account",
        mini: "CA",
        component: CreateAccount,
        layout: "/admin"
      },
      {
        path: "/list-users",
        name: "List Users",
        mini: "LU",
        component: ListUsers,
        layout: "/admin"
      },
      {
        path: "/create-user",
        name: "Create User",
        mini: "CU",
        component: CreateUser,
        layout: "/admin"
      },
      {
        path: "/list-tps",
        name: "List Trading Partners",
        mini: "LT",
        component: ListTP,
        layout: "/admin"
      },
      {
        path: "/create-tp",
        name: "Create Trading Partner",
        mini: "CT",
        component: CreateTP,
        layout: "/admin"
      },
      {
        path: "/list-dest",
        name: "List Destinations",
        mini: "LD",
        component: ListDestination,
        layout: "/admin"
      },
      {
        path: "/create-dest",
        name: "Create Destination",
        mini: "CD",
        component: CreateDestination,
        layout: "/admin"
      }
    ]
  }
  // {
  //   collapse: true,
  //   name: "Pages",
  //   icon: Image,
  //   state: "pageCollapse",
  //   views: [
  //     {
  //       path: "/pricing-page",
  //       name: "Pricing Page",
  //       mini: "PP",
  //       component: PricingPage,
  //       layout: "/auth"
  //     },
  //     {
  //       path: "/rtl-support-page",
  //       name: "RTL Support",
  //       mini: "RS",
  //       component: RTLSupport,
  //       layout: "/rtl"
  //     },
  //     {
  //       path: "/timeline-page",
  //       name: "Timeline Page",
  //       rtlName: "تيالجدول الزمني",
  //       mini: "T",
  //       rtlMini: "تي",
  //       component: TimelinePage,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/login-page",
  //       name: "Login Page",
  //       rtlName: "هعذاتسجيل الدخول",
  //       mini: "L",
  //       rtlMini: "هعذا",
  //       component: LoginPage,
  //       layout: "/auth"
  //     },
  //     {
  //       path: "/register-page",
  //       name: "Register Page",
  //       rtlName: "تسجيل",
  //       mini: "R",
  //       rtlMini: "صع",
  //       component: RegisterPage,
  //       layout: "/auth"
  //     },
  //     {
  //       path: "/lock-screen-page",
  //       name: "Lock Screen Page",
  //       rtlName: "اقفل الشاشة",
  //       mini: "LS",
  //       rtlMini: "هذاع",
  //       component: LockScreenPage,
  //       layout: "/auth"
  //     },
  //     {
  //       path: "/user-page",
  //       name: "User Profile",
  //       rtlName: "ملف تعريفي للمستخدم",
  //       mini: "UP",
  //       rtlMini: "شع",
  //       component: UserProfile,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/error-page",
  //       name: "Error Page",
  //       rtlName: "صفحة الخطأ",
  //       mini: "E",
  //       rtlMini: "البريد",
  //       component: ErrorPage,
  //       layout: "/auth"
  //     }
  //   ]
  // },
  // {
  //   collapse: true,
  //   name: "Components",
  //   rtlName: "المكونات",
  //   icon: Apps,
  //   state: "componentsCollapse",
  //   views: [
  //     {
  //       collapse: true,
  //       name: "Multi Level Collapse",
  //       rtlName: "انهيار متعدد المستويات",
  //       mini: "MC",
  //       rtlMini: "ر",
  //       state: "multiCollapse",
  //       views: [
  //         {
  //           path: "/buttons",
  //           name: "Buttons",
  //           rtlName: "وصفت",
  //           mini: "B",
  //           rtlMini: "ب",
  //           component: Buttons,
  //           layout: "/admin"
  //         }
  //       ]
  //     },
  //     {
  //       path: "/buttons",
  //       name: "Buttons",
  //       rtlName: "وصفت",
  //       mini: "B",
  //       rtlMini: "ب",
  //       component: Buttons,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/grid-system",
  //       name: "Grid System",
  //       rtlName: "نظام الشبكة",
  //       mini: "GS",
  //       rtlMini: "زو",
  //       component: GridSystem,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/panels",
  //       name: "Panels",
  //       rtlName: "لوحات",
  //       mini: "P",
  //       rtlMini: "ع",
  //       component: Panels,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/sweet-alert",
  //       name: "Sweet Alert",
  //       rtlName: "الحلو تنبيه",
  //       mini: "SA",
  //       rtlMini: "ومن",
  //       component: SweetAlert,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/notifications",
  //       name: "Notifications",
  //       rtlName: "إخطارات",
  //       mini: "N",
  //       rtlMini: "ن",
  //       component: Notifications,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/icons",
  //       name: "Icons",
  //       rtlName: "الرموز",
  //       mini: "I",
  //       rtlMini: "و",
  //       component: Icons,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/typography",
  //       name: "Typography",
  //       rtlName: "طباعة",
  //       mini: "T",
  //       rtlMini: "ر",
  //       component: Typography,
  //       layout: "/admin"
  //     }
  //   ]
  // },
  // {
  //   collapse: true,
  //   name: "Forms",
  //   rtlName: "إستمارات",
  //   icon: "content_paste",
  //   state: "formsCollapse",
  //   views: [
  //     {
  //       path: "/regular-forms",
  //       name: "Regular Forms",
  //       rtlName: "أشكال عادية",
  //       mini: "RF",
  //       rtlMini: "صو",
  //       component: RegularForms,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/extended-forms",
  //       name: "Extended Forms",
  //       rtlName: "نماذج موسعة",
  //       mini: "EF",
  //       rtlMini: "هوو",
  //       component: ExtendedForms,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/validation-forms",
  //       name: "Validation Forms",
  //       rtlName: "نماذج التحقق من الصحة",
  //       mini: "VF",
  //       rtlMini: "تو",
  //       component: ValidationForms,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/wizard",
  //       name: "Wizard",
  //       rtlName: "ساحر",
  //       mini: "W",
  //       rtlMini: "ث",
  //       component: Wizard,
  //       layout: "/admin"
  //     }
  //   ]
  // },
  // {
  //   collapse: true,
  //   name: "Tables",
  //   rtlName: "الجداول",
  //   icon: GridOn,
  //   state: "tablesCollapse",
  //   views: [
  //     {
  //       path: "/regular-tables",
  //       name: "Regular Tables",
  //       rtlName: "طاولات عادية",
  //       mini: "RT",
  //       rtlMini: "صر",
  //       component: RegularTables,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/extended-tables",
  //       name: "Extended Tables",
  //       rtlName: "جداول ممتدة",
  //       mini: "ET",
  //       rtlMini: "هور",
  //       component: ExtendedTables,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/react-tables",
  //       name: "React Tables",
  //       rtlName: "رد فعل الطاولة",
  //       mini: "RT",
  //       rtlMini: "در",
  //       component: ReactTables,
  //       layout: "/admin"
  //     }
  //   ]
  // },
  // {
  //   collapse: true,
  //   name: "Maps",
  //   rtlName: "خرائط",
  //   icon: Place,
  //   state: "mapsCollapse",
  //   views: [
  //     {
  //       path: "/google-maps",
  //       name: "Google Maps",
  //       rtlName: "خرائط جوجل",
  //       mini: "GM",
  //       rtlMini: "زم",
  //       component: GoogleMaps,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/full-screen-maps",
  //       name: "Full Screen Map",
  //       rtlName: "خريطة كاملة الشاشة",
  //       mini: "FSM",
  //       rtlMini: "ووم",
  //       component: FullScreenMap,
  //       layout: "/admin"
  //     },
  //     {
  //       path: "/vector-maps",
  //       name: "Vector Map",
  //       rtlName: "خريطة المتجه",
  //       mini: "VM",
  //       rtlMini: "تم",
  //       component: VectorMap,
  //       layout: "/admin"
  //     }
  //   ]
  // },
  // {
  //   path: "/widgets",
  //   name: "Widgets",
  //   rtlName: "الحاجيات",
  //   icon: WidgetsIcon,
  //   component: Widgets,
  //   layout: "/admin"
  // },
  // {
  //   path: "/charts",
  //   name: "Charts",
  //   rtlName: "الرسوم البيانية",
  //   icon: Timeline,
  //   component: Charts,
  //   layout: "/admin"
  // },
  // {
  //   path: "/calendar",
  //   name: "Calendar",
  //   rtlName: "التقويم",
  //   icon: DateRange,
  //   component: Calendar,
  //   layout: "/admin"
  // }
  // ,
  // {
  //   path: "/login",
  //   name: "Login Page",
  //   mini: "L",
  //   component: LoginPage,
  //   layout: "/auth"
  // }
];
export default routes;
