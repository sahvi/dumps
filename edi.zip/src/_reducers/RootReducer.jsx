import { combineReducers } from "redux";

import adminReducer from "./AdminReducer";

/*
This could also be in index.js and just get imported via call to import rootReducer from ./reducers
 */
const rootReducer = combineReducers({
  admin: adminReducer
});

export default rootReducer;
