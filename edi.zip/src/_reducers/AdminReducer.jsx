import { adminConstants } from "../_constants/admin.constants";

const initialState = {
  account: {
    corpname: "",
    orgunit: "",
    ediflag: false,
    activeflag: false,
    type: "",
    apptype: "",
    fname: "",
    lname: "",
    add1: "",
    add2: "",
    add3: "",
    city: "",
    state: "",
    zipcode: "",
    email: "",
    phone: "",
    fax: "",
    id: 0
  },
  destination: {},
  tradingPartner: {},
  user: {}
};
export default function(state = initialState, action) {
  switch (action.type) {
    case adminConstants.FETCH_ALL:
      return state;
    case adminConstants.FETCH_ACCOUNT:
      return {
        ...state
      };
    case adminConstants.STORE_ACCOUNT:
      return {
        ...state,
        account: action.account
      };
    case adminConstants.FETCH_USER:
      return {
        ...state.user
      };
    case adminConstants.STORE_USER:
      return {
        ...state,
        user: action.user
      };
    case adminConstants.FETCH_DESTINATION:
      return {
        ...state.destination
      };
    case adminConstants.STORE_DESTINATION:
      return {
        ...state,
        destination: action.destination
      };
    case adminConstants.FETCH_TRADING_PARTNER:
      return {
        ...state.tradingPartner
      };
    case adminConstants.STORE_TRADING_PARTNER:
      return {
        ...state,
        tradingPartner: action.tradingPartner
      };
    default:
      return state;
  }
}
