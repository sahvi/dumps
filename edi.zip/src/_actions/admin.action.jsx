import { adminConstants } from "../_constants/admin.constants";

// this is basically the same as a nested dispatch function within a storeCampaign function
export const storeAccount = account => dispatch => {
  dispatch({
    type: adminConstants.STORE_ACCOUNT,
    account: account
  });
};

export const fetchAccount = () => dispatch => {
  dispatch({ type: adminConstants.FETCH_ACCOUNT });
};

export const storeUser = user => dispatch => {
  dispatch({
    type: adminConstants.STORE_USER,
    user: user
  });
};

export const fetchUser = () => dispatch => {
  dispatch({ type: adminConstants.FETCH_USER });
};

export const storeDestination = destination => dispatch => {
  dispatch({
    type: adminConstants.STORE_DESTINATION,
    destination: destination
  });
};

export const fetchDestination = () => dispatch => {
  dispatch({ type: adminConstants.FETCH_DESTINATION });
};

export const storeTradingPartner = tradingPartner => dispatch => {
  dispatch({
    type: adminConstants.STORE_TRADING_PARTNER,
    tradingPartner: tradingPartner
  });
};

export const fetchTradingPartner = () => dispatch => {
  dispatch({ type: adminConstants.FETCH_TRADING_PARTNER });
};
