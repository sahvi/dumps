import { systemConfigConstants } from "../_constants/sysconfig.constants";

const initialState = {
  instrumentTypes: []
};

export default function(state = initialState, action) {
  switch (action.type) {
    case systemConfigConstants.FETCH_INSTRUMENT_TYPES: {
      return {
        ...state,
        instrumentTypes: action.payload
      };
    }
    default: {
      return state;
    }
  }
}
