import { combineReducers } from "redux";

import campaignReducer from "./CampaignReducer";
import designReducer from "./DesignReducer";
import sysconfigReducer from "./sysconfigReducer";
import userReducer from "./UserReducer";
import dashboardReducer from "./dashboardReducer";

/*
This could also be in index.js and just get imported via call to import rootReducer from ./reducers
 */
const rootReducer = combineReducers({
    campaignWizard: campaignReducer,
    design: designReducer,
    sysConfig: sysconfigReducer,
    userInfo: userReducer,
    dashboard: dashboardReducer
});

export default rootReducer;
