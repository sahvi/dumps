import { dashboardConstants } from "../_constants/dashboard.constants";
import moment from "moment";

const initialState = {
    alertState: {}
};

export default function(state = initialState, action) {
    switch (action.type) {
        case dashboardConstants.STORE_ALERT_STATE: {
            return {
                ...state,
                alertState: action.payload
            };
        }
        case dashboardConstants.FETCH_ALERT_STATE: {
            return {
                ...state
            };
        }
        default: {
            return state;
        }
    }
}
