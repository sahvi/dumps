import { userConstants } from "../_constants/user.constants";
import moment from "moment";

const initialState = {
    user: {authentication: true,
      email: "leejwright@outlook.com",
      fullName: "Lee Wright",
      jwt: "some random key",
      username: "lee"}
};

export default function(state = initialState, action) {
    switch (action.type) {
        case userConstants.FETCH_USER: {
            return {
                ...state
            };
        }
        case userConstants.STORE_USER: {
            return {
                ...state,
                user: action.payload
            };
        }
        default: {
            return state;
        }
    }
}
