import { designConstants } from "../_constants/design.constants";

const initialState = {
  design: {
    name: "",
    modalOpen: false,
    width: 8.5,
    height: 11,
    marginT: 0.3,
    marginL: 0.1,
    marginB: 0.3,
    marginR: 0.1,
    grid: 0.1,
    rows: 10,
    columns: 8,
    background: "",
    theme: "",
    instrumentType: "",
    unitOfMeasure: "INCH"
  }
};
export default function(state = initialState, action) {
  switch (action.type) {
    case designConstants.CHANGE_INSTRUMENT:
      console.log("CHANGE_INSTRUMENT %o %o", state, action);
      return {
        ...state,
        instrumentType: action.design
      };
    case designConstants.STORE_DESIGN:
      return {
        ...state,
        design: action.design
      };
    default:
      return {
        design: action.design ? action.design : initialState.design
      };
  }
}
