import { campaignConstants } from "../_constants/campaign.constants";
import moment from "moment";
import Moment from "../views/Calendar/CalendarCreator";

const initialState = {
  campaign: {
    name: "",
    description: "",
    calendar: {
      colour: ""
    },
    active: false,
    recurring: null,
    startDate: moment(),
    endDate: moment().add(15, "days"),
    sourceTemplate: null,
    template: false,
    instruments: [],
    deadlines: [],
    deadline: {
      name: "",
      desc: "",
      dates: []
    },
    instrument: {
      name: "",
      pages: [],
      pageOptions: [],
      targets:[]
    },

    campaignType: null,
    useTemplate: false
  }
};
export default function(state = initialState, action) {
  switch (action.type) {
    case campaignConstants.FETCH:
      return {
        ...state
      };
    case campaignConstants.STORE:
      return {
        ...state,
        campaign: action.campaign
      };
    default:
      return state;
  }
}
