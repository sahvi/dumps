export const dashboardConstants = {
    STORE_ALERT_STATE: "STORE_ALERT_STATE",
    FETCH_ALERT_STATE: "FETCH_ALERT_STATE"
};
