export const userConstants = {
  FETCH_USER: "FETCH_USER",
  STORE_USER: "STORE_USER"
};
