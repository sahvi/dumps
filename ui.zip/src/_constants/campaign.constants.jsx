export const campaignConstants = {
  DEFAULT: "DEFAULT",
  FETCH: "FETCH",
  STORE: "STORE"
};
