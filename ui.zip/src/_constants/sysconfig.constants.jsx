export const systemConfigConstants = {
    FETCH_INSTRUMENT_TYPES: 'FETCH_INSTRUMENT_TYPES'
}
