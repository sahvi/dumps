import React, { Component } from "react";
import { Translate, withLocalize } from "react-localize-redux";
import { Button, ButtonGroup, Col, Row } from "reactstrap";
import Switch from "react-bootstrap-switch";
import { connect } from "react-redux";
import { fetchAlertState, storeAlertState } from "../../_actions/dashboard.action";

class CampaignAlerts extends Component {


    constructor(props) {
        super(props);
        this.state = {
            warnCount: 0,
            dangerCount: 0,
            infoCount: 0,
            warnActive: true,
            infoActive: true,
            dangerActive: true,
            alertStates: null,
            cSelected: [1,2,3]
        };

        this.onCheckboxBtnClick = this.onCheckboxBtnClick.bind(this);
    }

    onCheckboxBtnClick(selected) {
        const index = this.state.cSelected.indexOf(selected);
        if (index < 0) {
            this.state.cSelected.push(selected);
        } else {
            this.state.cSelected.splice(index, 1);
        }
        this.setState({ cSelected: [...this.state.cSelected] });
        console.log("Selected %o", this.state.cSelected);
        this.props.storeAlertState(this.state.cSelected);
    }

    isDisabled(btn) {
        return this.state.cSelected.includes(btn) ? 'a1-enabled-btn' : 'a1-disabled-btn';
    }

    calSwitch = (checked, proto, id) => {
        console.log("Changing %o %o", proto, id);

    };

    componentDidMount() {


    }

    render() {
        const subtitle = <h6 className="stats-title">Showing nn</h6>;

        return (
            <div className={"statistics info"}>

                <ButtonGroup>
                    <Row>
                        <Col sm={12}>

                            <Button block size="lg" color="danger" className={this.isDisabled(1) } onClick={() => this.onCheckboxBtnClick(1)}
                                    active={this.state.cSelected.includes(1)}><Translate id="danger"/>&nbsp;{this.state.dangerCount}</Button>
                            <Button block size="lg" color="warning" className={this.isDisabled(2) } onClick={() => this.onCheckboxBtnClick(2)}
                                    active={this.state.cSelected.includes(2)}><Translate id="warn"/>&nbsp;{this.state.warnCount}</Button>
                            <Button block size="lg" color="info" className={this.isDisabled(3) }  onClick={() => this.onCheckboxBtnClick(3)}
                                    active={this.state.cSelected.includes(3)}><Translate id="info"/>&nbsp;{this.state.infoCount}</Button>

                        </Col>
                    </Row>
                </ButtonGroup>
                <Row>
                    <Col sm={12}>
                        {subtitle}
                    </Col>
                </Row>
            </div>
        );
    }
}



const mapStateToProps = state => ({
    alertStates: state.payload
});



export default connect(
    mapStateToProps,
    { storeAlertState, fetchAlertState  }, null, {withRef: true}
)(withLocalize(CampaignAlerts));
