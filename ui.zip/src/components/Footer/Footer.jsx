import React from "react";
import { Container } from "reactstrap";
// used for making the prop types of this component
import PropTypes from "prop-types";

class Footer extends React.Component {
  render() {
    return (
      <footer
        className={"footer" + (this.props.default ? " footer-default" : "")}
      >
        <Container fluid={this.props.fluid ? true : false}>
          <nav>
            <ul>
              <li>
                <a href="http://www.avanue1.org">Avenue 1</a>
              </li>
              <li>
                <a href="http://www.avenue1.org/about">About Us</a>
          </li>
              <li>
                <a href="http://www.avenue1.org/blog">Blog</a>
              </li>
            </ul>
          </nav>
          <div className="copyright">
              Copyright (c) by Avenue One. All Rights Reserved.
          </div>
        </Container>
      </footer>
    );
  }
}

Footer.propTypes = {
  default: PropTypes.bool,
  fluid: PropTypes.bool
};

export default Footer;
