import React, { Component } from "react";
import { connect } from "react-redux";
import { withLocalize } from "react-localize-redux";
import ReactTable from "react-table";
import { toast, ToastContainer } from "react-toastify";

const onRowClick = (state, rowInfo, column, instance) => {
    return {
        onClick: e => {
            toast.info('Clicked ' + rowInfo.row.name);
            console.log('A Td Element was clicked!');
            console.log('it produced this event:', e);
            console.log('It was in this column:', column);
            console.log('It was in this row:', rowInfo);
            console.log('It was in this table instance:', instance)
        }
    }
};


class DeadlineTable extends Component {

    constructor(props) {
        super(props);
        this.state = {
            alertStates: [1, 2, 3],
            data: [
                { "name": "Campaign setup", "count": 2 },
                { "name": "Space alloc.", "count": 3 },
                { "name": "Offer alloc.", "count": 2 },
                { "name": "Page layout", "count": 4 },
                { "name": "Proof", "count": 1 },
            ]
        };
    }


    render() {
        return (
            <div>
                <ToastContainer/>
                <ReactTable
                    getTrProps={onRowClick}
                    data={this.state.data}
                    columns={[
                        {
                            Header: "Name",
                            accessor: "name"
                        },
                        {
                            Header: "Count",
                            accessor: "count"
                        }
                    ]}
                    defaultPageSize={5}
                    showPaginationTop={false}
                    showPaginationBottom={false}
                    className="-striped -highlight"
                />
            </div>
        );
    }

    componentWillReceiveProps(nextProps, nextContext) {
        console.log("Deadline table prop change");
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log("Got new props...%o", this.props);
        if (this.props.alertState !== prevProps.alertState) {
            this.setState({
                alertState: this.props.alertState
            });
        }
    }
}


/**
 * Remember this is the state from the rootReducer..so dashboard...
 * @param state
 * @returns {{alertState: (initialState.alertState|{})}}
 */

const mapStateToProps = state => ({
    alertState: state.dashboard.alertState
});


export default connect(
    mapStateToProps
)(withLocalize(DeadlineTable));
