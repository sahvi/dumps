import React from "react";

import CardCategory from "../../components/CardElements/CardCategory";
import { Translate, withLocalize } from "react-localize-redux";
import Stats from "../../components/Stats/Stats";

import {
    Card,
    CardBody,
    CardFooter,
    CardHeader,
    CardTitle,
    DropdownItem,
    DropdownMenu,
    DropdownToggle,
    UncontrolledDropdown
} from "reactstrap";

import { connect } from "react-redux";
import { fetchAlertState } from "../../_actions/dashboard.action";
import DeadlineTable from "./DeadlineTable";


function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

class DeadlineCard extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            random: 10
        };
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log("Alert card got new props...%o", this.props);
        if (this.props.alertState !== prevProps.alertState) {
            this.setState({
                alertState: this.props.alertState,
                random: getRandomInt(1, 100)
            });
        }
    }


    render() {
        const { classes } = this.props;


        return (
            <div>

                <Card className="card-chart">
                    <CardHeader>
                        <CardCategory><Translate id="deadlines"/></CardCategory>
                        <CardTitle tag="h2">{this.state.random}</CardTitle>
                        <UncontrolledDropdown>
                            <DropdownToggle
                                className="btn-round btn-simple btn-icon"
                                color="default"
                            >
                                <i className="now-ui-icons loader_gear"/>
                            </DropdownToggle>
                            <DropdownMenu right>
                                <DropdownItem>Filter</DropdownItem>
                                <DropdownItem>Another Action</DropdownItem>
                                <DropdownItem>Something else here</DropdownItem>

                            </DropdownMenu>
                        </UncontrolledDropdown>
                    </CardHeader>
                    <CardBody>
                        <DeadlineTable/>

                    </CardBody>
                    <CardFooter>
                        <Stats>
                            {[
                                {
                                    i: "now-ui-icons arrows-1_refresh-69",
                                    t: "Just Updated"
                                }
                            ]}
                        </Stats>
                    </CardFooter>
                </Card>
            </div>);
    }

}


const mapStateToProps = state => ({
    alertState: state.dashboard.alertState
});

export default connect(
    mapStateToProps,
    { fetchAlertState }, null, { withRef: true }
)(withLocalize(DeadlineCard));
