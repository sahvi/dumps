import React, { Component } from "react";
import PropTypes from "prop-types";
import { attributeService } from "../../_services/attribute_service";
import Select from "react-select";
import { Label } from "reactstrap";

class AttributeSelector extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeTag: null
    };
  }

  componentWillReceiveProps(nextProps, nextContext) {
    console.log("new props %o", nextProps);
  }

  componentDidMount() {
    console.log("Getting possible attributes for %s", this.props.entityType);
    attributeService.getAttributesByEntity(this.props.entityType).then(res => {
      console.log("Got attributes...%o", res);
      let attrs = res.data.map(attr => {
        console.log("Handling attr %o", attr);

        return (
          <div key={attr.id}>
            <Label>{attr.name}</Label>
            {attr.hasValidValues ? (
              <Select
                name={attr.name}
                onChange={this.props.changeHandler}
                options={attr.attributeValues}
                getOptionLabel={option => option.value}
                getOptionValue={option => option.id}
              />
            ) : (
              "no valid"
            )}
          </div>
        );
      });
      console.log("Attrs %o", attrs);
      this.setState({
        attributeTag: attrs
      });
    });
  }

  render() {
    return (
      <div className="a1-attributes">
        <div>All available attributes here for {this.props.entityType}</div>
        <div>{this.state.attributeTag}</div>
      </div>
    );
  }
}

export default AttributeSelector;

// the attribute types need to be aligned with the attribute types in EntityTypeEnum on the server side
AttributeSelector.propTypes = {
  changeHandler: PropTypes.func.required,
  entityType: PropTypes.oneOf([
    "campaign",
    "user",
    "design",
    "container",
    "offer",
    "page",
    "calendar",
    "influence",
    "deadline"
  ]).isRequired
};
