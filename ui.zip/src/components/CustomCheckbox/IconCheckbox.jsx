import React from "react";
// used for making the prop types of this component
import PropTypes from "prop-types";

class IconCheckbox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      checked: props.checked
    };
    this.checkboxClick = this.checkboxClick.bind(this);
  }
  checkboxClick() {
    let status = this.state.checked;
    if (this.state.checked !== "") {
      status = "";
      this.setState({
        checked: ""
      });
    } else {
      status = "active";
      this.setState({
        checked: " active"
      });
    }
    // this.refs.checkbox.click();
    this.props.onClick({name: this.props.name, status: status});
  }
  componentWillReceiveProps(newProps) {
    if(newProps.checked) {
      this.setState({checked: newProps.checked});
    }
  }
  render() {
    return (
      <div
        className={"choice" + this.state.checked}
        onClick={() => this.checkboxClick()}
      >
        <input
          type="checkbox"
          name={this.props.name}
          value={this.props.value}
          ref="checkbox"
        />
        <div className="icon">
          <i className={this.props.icon} />
        </div>
        {this.props.title !== undefined ? <h6>{this.props.title}</h6> : null}
      </div>
    );
  }
}

IconCheckbox.propTypes = {
  name: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  icon: PropTypes.string.isRequired
};

export default IconCheckbox;
