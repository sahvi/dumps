import React from "react";
import { Card, CardBody, CardHeader } from "reactstrap";
import { Translate } from "react-localize-redux";
import { connect } from "react-redux";
import CardCategory from "../CardElements/CardCategory";

function mapStateToProps(state) {
    return {};
}

class HistoryCard extends React.Component {
    render() {
        return (
            <div>


                <Card className="card-collapse">
                    <CardHeader>
                        <CardCategory><Translate id="history"/></CardCategory>
                    </CardHeader>
                    <CardBody>
                        History of recent selections goes here

                    </CardBody>
                </Card>
            </div>
        );
    }

}

export default connect(
    mapStateToProps
)(HistoryCard);
