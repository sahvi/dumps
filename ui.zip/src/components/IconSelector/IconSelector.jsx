import React from "react";
// used for making the prop types of this component
import Select from "react-select";
import faIcons from "../../variables/faIcons";

class IconSelector extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            selected: '',
            colour: '#000'
        };

        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(item) {
        this.setState({
            selected: item.name
        });
        console.log("Changed %o %o", item, this.state);
    }

    componentWillReceiveProps(nextProps, nextContext) {
        console.log("New icon selector props %o", nextProps);
        if ( nextProps['colour']) {
            this.setState({colour: nextProps.colour});
        }
    }

    componentDidMount() {
        // select first item
        let first = faIcons[0];
        console.log("First %s of %o", first, faIcons);

        this.setState({ selected: first });
    }


    render() {
        let selectOptions = [];
        faIcons.map(name => {
            let tag = name.replace("fa-","");
            selectOptions.push({ "name": name, "label": tag });
        });

        return (


            <div className="picture-container">
                <div className="icon-circle">

                    <span style={{color:this.props.colour}}>
                    <i className={"fas " + this.state.selected}></i>
                    </span>
                </div>
                <div>
                    <Select
                        classNamePrefix="fas"
                        className="primary"
                        placeholder="Icon"
                        multi={false}
                        options={selectOptions}
                         onChange={this.handleChange}

                    />
                </div>

            </div>

        );
    }
}

export default IconSelector;
