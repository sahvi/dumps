import React from "react";
import { withLocalize } from "react-localize-redux";
import {
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem
} from "reactstrap";

class DropDownButton extends React.Component {

  constructor(props) {
    super(props);
    this.onSelect = this.onSelect.bind(this);
  }

  onSelect(e) {
    if (this.props.onClick) {
      this.props.onClick(e);
    }
  }

  render () {
    let DropDownItems = () => {
      let ddItems = [];
      if(this.props.options) {
        for (let i = 0; i < this.props.options.length; i++) {
          ddItems.push(
            <div>
              <DropdownItem onClick={()=> {this.onSelect(this.props.options[i])}}>{this.props.options[i].label}</DropdownItem>
              <DropdownItem divider />
            </div>
          );
        }
      }
      return (
        <DropdownMenu>
          {ddItems}
        </DropdownMenu>
      );
    };
    return(
      <UncontrolledDropdown>
        <DropdownToggle
          color={this.props.color}
          className="btn-round btn-block"
          // caret={this.props.caret}
        >
          {this.props.name}
        </DropdownToggle>
        <DropDownItems/>
      </UncontrolledDropdown>
    )
  }
}


export default withLocalize(DropDownButton);

