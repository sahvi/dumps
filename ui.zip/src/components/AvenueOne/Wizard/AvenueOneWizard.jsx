import ReactWizard from "react-bootstrap-wizard";
import React from "react";
import connect from "react-redux/es/connect/connect";
import { withLocalize } from "react-localize-redux";

class AvenueOneWizard extends ReactWizard {

  constructor(props) {
    super(props);
  }

  nextButtonClick() {
    if(this.validate()) {
      this.saveAndFinishLater();
      super.nextButtonClick();
    }
  }

  validate() {
    if(this.refs[
      this.props.steps[this.state.currentStep].stepName
      ].getWrappedInstance().isValid !== undefined) {
      return this.refs[
        this.props.steps[this.state.currentStep].stepName
        ].getWrappedInstance().isValid();
    } else {
      return true;
    }
  }

  saveAndFinishLater() {
    if(this.refs[
      this.props.steps[this.state.currentStep].stepName
      ].getWrappedInstance().saveAndFinishLater !== undefined) {
      this.refs[
        this.props.steps[this.state.currentStep].stepName
        ].getWrappedInstance().saveAndFinishLater();
    }
  }

  render () {
    return(
      super.render()
    )
  }
}
const mapStateToProps = state => ({

});

export default connect(mapStateToProps, null, null, {withRef: true})(withLocalize(AvenueOneWizard));

