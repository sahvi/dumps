import React, { Component } from "react";
import { NavItem, NavLink } from "reactstrap";
import { Translate, withLocalize } from "react-localize-redux";
import { withRouter } from "react-router-dom";
import connect from "react-redux/es/connect/connect";
import { fetchInstrumentTypes } from "../../_actions/sysconfig.action";
import PropTypes from 'prop-types';

class InstrumentTypeButtonList extends Component {

    constructor(props) {
        super(props);
    }

    render() {

        if (this.props.instrumentTypes && Array.isArray(this.props.instrumentTypes)) {

            return this.props.instrumentTypes.map(ins => (
                    <NavItem key={ins.id}>
                        <NavLink name={ins.name}
                            className={this.props.currentTab === ins.name ? "active" : ""}
                            onClick={e => this.props.tabClick(e)}
                        >
                            {ins.name}
                        </NavLink>
                    </NavItem>

                )
            );
        } else {
            return (<div><Translate id="err.noInstrumentTypes"/></div>);
        }

    }


}
function mapStateToProps(state) {
    return {
        instrumentTypes: state.sysConfig.instrumentTypes
    };
}

export default withRouter(connect(mapStateToProps, {
    fetchInstrumentTypes
})(withLocalize(InstrumentTypeButtonList)));

InstrumentTypeButtonList.propTypes = {
    tabClick: PropTypes.func.isRequired,
    currentTab: PropTypes.string.required
};
