const local = {
    auth: "http://localhost:8400",
    planningSvc: "http://ec2-13-58-160-220.us-east-2.compute.amazonaws.com:9080/api",
    namingSvc: "http://localhost:8083/api",
    designSvc: "http://localhost:8087/api",
    attributeSvc: "http://localhost:8100/api",
    targetSvc: "http://ec2-13-58-160-220.us-east-2.compute.amazonaws.com:8090/api",

};

const prod = {
  auth: "http://localhost:8400",
  planningSvc: "/avo/planning/api",
  namingSvc: "http://localhost:8083/api",
  designSvc: "http://localhost:8087/api",
  attributeSvc: "http://localhost:8100/api",
  targetSvc: "/avo/target/api",

};

const config = process.env.ENVIRONMENT === 'local'
  ? local
  : local;

export default {
  ...config
};
