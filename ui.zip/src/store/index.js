import { applyMiddleware, compose, createStore } from "redux";
import thunkMiddleware from "redux-thunk";
import { createLogger } from "redux-logger";
import rootReducer from "../_reducers/RootReducer";

const loggerMiddleware = createLogger();
const initialState = {};

const middleware = [thunkMiddleware, loggerMiddleware];
const __PROD__ = false;
// const composeEnhancers = !__PROD__
//   ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose
//   : compose;

// ... is the spread operator - basically zero or more items expanded from input

const composeEnhancers =
    typeof window === "object" &&
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ?
        window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({
            // Specify extension’s options like name, actionsBlacklist, actionsCreators, serialize...
        }) : compose;

const enhancer = composeEnhancers(
    applyMiddleware(...middleware)
    // other store enhancers if any
);

const store = createStore(
    rootReducer,
    initialState,
    enhancer
);

export default store;
