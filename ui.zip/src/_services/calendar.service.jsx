import config from "../config/config";
import axios from "axios";

const baseURL = config.planningSvc;

export const calendarService = {
  getCalendars,
  deleteCalendar,
  getInstrumentTypes,
  getDeadlineTypes,
  getCampaignTemplates,
  getPageTypes
};

function getCalendars() {
  // axios.defaults.headers.post['Access-Control-Allow-Origin'] = '*';
  // axios.defaults.headers.post['Content-Type'] = 'application/json;charset=utf-8';
  return axios
    .get(`${baseURL}/calendars`, {
      page: 1,
      size: 50
    })
    .then(res => {
      console.log("Calendar data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      alert("Error " + error);
      console.log(error);
    });

  // const requestOptions = {
  //     method: 'GET',
  //     headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin':'*' }
  // };
  // let cals = fetch(`${baseURL} / calendars`, requestOptions)
  //     .then(handleResponse);
  // return cals;
}

function getInstrumentTypes() {
  return axios
    .get(`${baseURL}/getInstrumentsTypes`)
    .then(res => {
      console.log("Instrument Types data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      alert("Error " + error);
      console.log(error);
    });
}

function getPageTypes() {
  return axios
    .get(`${baseURL}/getPageTypesWithDetail`)
    .then(res => {
      console.log("Page Types data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      alert("Error " + error);
      console.log(error);
    });
}

function getCampaignTemplates() {
  return axios
    .get(`${baseURL}/campaigns/getCampaignTemplates`)
    .then(res => {
      console.log("Campaign templates Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      alert("Error " + error);
      console.log(error);
    });
}

function deleteCalendar(calID) {
  return axios.delete(`${baseURL}/calendars/` + calID);
}

function getDeadlineTypes() {
  console.log("AXIOS HEADERS %o", axios.defaults.headers.get);
  return axios
    .get(`${baseURL}/getDeadlineTypes`)
    .then(res => {
      console.log("Deadline Types data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      alert("Error " + error);
      console.log(error);
    });
}

function handleResponse(response) {
  return response.text().then(text => {
    var data = {
      status: "success"
    };
    if (!response.ok) {
      data = {
        status: "failure"
      };
    } else {
      data = text && JSON.parse(text);
      data.status = "success";
    }

    return data;
  });
}
