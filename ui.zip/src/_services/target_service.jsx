import config from "../config/config";
import axios from "axios";

const baseURL = config.targetSvc;

export const targetService = {
  getTargets,
  getStores,
  getStoreGroupsByInstruments
};

function getTargets(instrumentType) {
    let config = {
        headers: {
            'Access-Control-Expose-Headers': 'X-Total-Count',
        }
    };

    return axios
    .get(`${baseURL}/targetsByInstrumentType/` + instrumentType, config)
    .then(res => {
      console.log("Target headers %o data response %o",res.headers, res);
      return res.data;
    })
    .catch(function(error) {
      console.error(error);
    });
}

function getStoreGroupsByInstruments(instrumentType) {
  let group = 'STOREGROUP';
  if(instrumentType.toUpperCase() === "EMAIL") {
    group = 'EMAIL';
  }
  return axios
    .get(`${baseURL}/targets/type/${group}/instrument/` + instrumentType)
    .then(res => {
      console.log("Target data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      console.error(error);
    });
}

function getStores() {
  return axios
    .get(`${baseURL}/targetsByType/STORE`)
    .then(res => {
      console.log("Target data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      alert("Error " + error);
      console.log(error);
    });
}
