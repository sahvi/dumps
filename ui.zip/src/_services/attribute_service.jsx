import config from "../config/config";
import axios from "axios";

const baseURL = config.attributeSvc;

export const attributeService = {
  getAttributesByEntity
};

function getAttributesByEntity(type) {
  return axios.get(`${baseURL}/attributesByEntity/` + type);
}
