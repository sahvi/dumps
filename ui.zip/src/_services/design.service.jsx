import config from "../config/config";
import axios from "axios";


export const designService = {
    createDesign,
    getDesigns,
    getDesign,
    addDesignContainer,
    getDesignsByInstrumentType,
    deleteDesign
};

const baseURL = config.designSvc;

function addDesignContainer(container) {
    alert("Adding");
    return axios({
        method: 'post',
        url: `${baseURL}/containers`,
        data: JSON.stringify(container),
        config: { headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }}
    });
}

function createDesign(design) {
    axios.defaults.headers.post['Content-Type'] = 'application/json';
    return axios({
        method: 'post',
        url: `${baseURL}/designs`,
        data: JSON.stringify(design),
        config: { headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }}
    })
}

function deleteDesign(id) {
    return axios.delete(`${baseURL}/designs/` + id);
}

function getDesign(id) {
    return axios.get(`${baseURL}/designs/` + id);
}

function getDesignsByInstrumentType(type) {
    return axios.get(`${baseURL}/designs/instrumentType/` + type);
}

function getDesigns() {
    return axios.get(`${baseURL}/designs`);
}
