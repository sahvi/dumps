import config from "../config/config";
import axios from "axios";
import moment from "moment";

const baseURL = config.planningSvc;
const dateFormat = "YYYY-MM-DDTHH:mm:ss.000";

export const campaignService = {
  saveCampaign,
  getCampaigns,
  getCampaign,
  getRollingCampaignChart
};

function getRollingCampaignChart() {
  return axios.get(`${baseURL}/metrics/rollingCampaignCountByInstrumentType`);
}

function saveCampaign(campaign) {
  console.log("Saving campaign %o", campaign);
  axios.defaults.headers.post["Content-Type"] = "application/json";
  campaign.calendar = { name: campaign.calendar.name };
  campaign.startDate = moment(campaign.startDate).format(dateFormat);
  campaign.endDate = moment(campaign.endDate).format(dateFormat);

  //TODO: PLEASE FIX ME...
  let deadlines = campaign.deadlines;
  if(deadlines.length > 0 ) {
    deadlines.map(deadline =>
      {
        deadline.deadlineLineDue = moment(deadline.deadlineLineDue).format(dateFormat);
      }
    )
  }
  campaign.deadlines = deadlines;

  if (campaign.id) {
    return axios.put(`${baseURL}/campaigns`, JSON.stringify(campaign), {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    });
  } else {
    return axios({
      method: "post",
      url: `${baseURL}/campaigns`,
      data: JSON.stringify(campaign),
      config: {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json"
        }
      }
    });
  }
}

function getCampaigns() {
  console.log("AXIOS HEADERS %o", axios.defaults.headers.get);
  return axios
    .get(`${baseURL}/campaigns`)
    .then(res => {
      console.log("Campaigns Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      alert("Error " + error);
      console.log(error);
    });
}

function getCampaign(id) {
  console.log("AXIOS HEADERS %o", axios.defaults.headers.get);
  return axios
    .get(`${baseURL}/campaigns/${id}`)
    .then(res => {
      console.log("Campaigns Data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      alert("Error " + error);
      console.log(error);
    });
}

function handleResponse(response) {
  return response.text().then(text => {
    var data = {
      status: "success"
    };
    if (!response.ok) {
      data = {
        status: "failure"
      };
    } else {
      data = text && JSON.parse(text);
      data.status = "success";
    }

    return data;
  });
}
