import config from "../config/config";

export const eventService = {
  getEvents,
  addEvent
};

const baseURL = config.planningSvc;

function getEvents() {
    const requestOptions = {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
    };
    let events = fetch(`${baseURL}/event/list`, requestOptions)
        .then(handleResponse)
    return events;
}

function addEvent(event) {
  const requestOptions = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(event)
  };

  let message = fetch(`${baseURL}/event`, requestOptions)
    .then(handleResponse)
  return message;
}


function handleResponse(response) {
    return response.text().then(text => {
      var data = {
        status: "success"
      };
        if (!response.ok) {
          data = {
            status: "failure"
          };
        } else {
          data = text && JSON.parse(text);
          data.status = "success"
        }

        return data;
    });
}
