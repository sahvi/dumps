import config from "../config/config";
import axios from "axios";

export const userService = {
    login,
    logout,
    getUserInfo
};

const baseURL = config.auth;


function getUserInfo(username) {
    return {
        'name':'test',
        'email':'sommeone@here.com'
    }
}

function login(username, password) {
    const data = {
      username: username,
      password: password
    };
   //

    // return axios.post(`${baseURL}/auth/user`, data).then((value) => {
    //     console.log("Login response %o", value);
    //     // todo - authenticate properly
    //     let res = Promise.resolve({
    //             authentication: true,
    //             jwt: 'some random key',
    //             username: 'lee',
    //             fullName: 'Lee Wright',
    //             email: 'leejwright@outlook.com'
    //           });
    //
    //     return res;
    // });


  if(username === "admin" && password === "admin") {
      return Promise.resolve({
        authentication: true,
        jwt: 'some random key',
        username: 'lee',
        fullName: 'Lee Wright',
        email: 'leejwright@outlook.com'
      })
  } else {
    return Promise.resolve({
      authentication: false
    })
  }
}

function logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('user');
    return "{}";
}

function handleResponse(response) {
    return response.text().then(text => {
        const data = text && JSON.parse(text);
        if (!response.ok) {
            if (response.status === 401) {
                // auto logout if 401 response returned from api
                logout();
                // location.reload(true);
            }

            const error = (data && data.message) || response.statusText;
            return Promise.reject(error);
        }

        return data;
    });
}
