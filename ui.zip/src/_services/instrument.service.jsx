import config from "../config/config";
import axios from "axios";

export const instrumentService = {
  getInstrumentTypes
};

const baseURL = config.planningSvc;

function getInstrumentTypes() {
  return axios
    .get(`${baseURL}/getInstrumentsTypesWithDetail`)
    .then(res => {
      console.log("Instrument Types data %o", res.data);
      return res.data;
    })
    .catch(function(error) {
      alert("Error " + error);
      console.log(error);
    });
}
