import React from "react";
import ReactDOM from "react-dom";
import { createBrowserHistory, createHashHistory } from "history";
import { Route, Router, Switch } from "react-router-dom";

import "bootstrap/dist/css/bootstrap.css";
import "assets/scss/now-ui-dashboard.css?v=1.2.0";
import "assets/css/demo.css";

import indexRoutes from "routes/index.jsx";
import { LocalizeProvider } from "react-localize-redux";
import { Provider } from "react-redux";
import store from "./store";
import { PrivateRoute } from "./routes/PrivateRoute";
import LoginPage from "./views/Pages/LoginPage";

const hist = createBrowserHistory();

const hashHist = createHashHistory();

ReactDOM.render(
  <LocalizeProvider>
    {/* React redux glue - store is the root store with root reducer. Other reducers will be combined with the root reducer
            Entire application should be wrapped with the provider for redux
        */}
    <Provider store={store}>
      <Router history={hashHist}>
        <Switch>
          <Route exact path="/login" name="Login Page" component={LoginPage}/>
          {indexRoutes.map((prop, key) => {
            return (
              <PrivateRoute
                path={prop.path}
                key={key}
                component={prop.component}
              />
            );
          })}
        </Switch>
      </Router>
    </Provider>
  </LocalizeProvider>,
  document.getElementById("root")
);
