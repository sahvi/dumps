import EditDesign from "../views/Design/EditDesign";
import React from "react";

const designRoutes = [
    {
        path: "/designs/edit/:id",
        component: EditDesign
    }
];

export default designRoutes;
