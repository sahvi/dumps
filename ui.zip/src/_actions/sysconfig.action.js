import { instrumentService } from "../_services";
import { systemConfigConstants } from "../_constants/sysconfig.constants";

export const fetchInstrumentTypes = sysConfig => dispatch =>  {
    instrumentService.getInstrumentTypes().then(res => {
        dispatch({
            type: systemConfigConstants.FETCH_INSTRUMENT_TYPES,
            payload: res
        })
    });


};
