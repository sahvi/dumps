import { userService } from "../_services";
import { userConstants } from "../_constants/user.constants";
import { campaignConstants } from "../_constants/campaign.constants";

export const storeUser = user => dispatch => {
    dispatch({
        type: userConstants.STORE_USER,
        payload: user
    })
};

export const fetchUserInfo = user => dispatch =>  {
    user.getUserInfo().then(res => {
        dispatch({
            type: userConstants.FETCH_USER})
    });


};
