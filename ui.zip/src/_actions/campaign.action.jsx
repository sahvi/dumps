import campaign from "../_reducers/CampaignReducer";
import { campaignConstants } from "../_constants/campaign.constants";
import store from "../store";

const initialCampaign = {
  name: "",
  description: "",
  calendar: "",
  recurring: null,
  startDate: new Date(),
  endDate: new Date(),
  sourceTemplate: null,
  instruments: [],
  deadlines: [],
  campaignType: "",
  numberOfPages: 0,
  pages: {
    templateId: ""
  }
};

// this is basically the same as a nested dispatch function within a storeCampaign function
export const storeCampaign = campaign => dispatch => {
  dispatch({
    type: campaignConstants.STORE,
    campaign: campaign
  });
};

export const fetchCampaign = () => dispatch => {
  dispatch({ type: campaignConstants.FETCH });
};
