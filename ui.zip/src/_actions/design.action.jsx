import { designConstants } from "../_constants/design.constants";

export const storeDesign = design => dispatch => {
    dispatch({type: designConstants.STORE_DESIGN, design: design})
}

export const changeInstrumentType = instrumentType => dispatch => {
    dispatch({type: designConstants.CHANGE_INSTRUMENT, instrumentType: instrumentType})
}

export const fetchDesign = () => dispatch => {
    dispatch({type: designConstants.FETCH_DESIGN})
}
