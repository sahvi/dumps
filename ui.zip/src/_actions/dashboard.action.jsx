import { dashboardConstants } from "../_constants/dashboard.constants";

export const storeAlertState = alertState => dispatch => {
    console.log("Store alert state");

    dispatch({
        type: dashboardConstants.STORE_ALERT_STATE,
        payload: alertState
    });
};


export const fetchAlertState = () => dispatch => {
    console.log("Fetch alert state");
    dispatch({ type: dashboardConstants.FETCH_ALERT_STATE });
};

