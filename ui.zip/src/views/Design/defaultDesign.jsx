
export default {
    name: "",
    modalOpen: false,
    width: 8.5,
    height: 11,
    marginT: 0.3,
    marginL: 0.1,
    marginB: 0.3,
    marginR: 0.1,
    rows: 10,
    columns: 6,
    grid: 0.1,
    background: '',
    theme: '',
    instrumentType: "",
    unitOfMeasure: "INCH",
    containers: []
};
