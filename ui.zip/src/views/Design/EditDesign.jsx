import React from "react";
import PanelHeader from "../../components/PanelHeader/PanelHeader";
import { Translate, withLocalize } from "react-localize-redux";
import { designService} from "../../_services";
import { Col, Row, Card, Container, CardBody, CardTitle, FormGroup, CardHeader, Input } from "reactstrap";
import Design from "./Design";
import DesignTools from "./DesignTools";
import frenchTranslations from "../../i18n/fr/design";
import englishTranslations from "../../i18n/en/design";
import defaultDesign from "./defaultDesign";
import { Button } from "../../components";


class EditDesign extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            alert: null,
            zoom: 100,
            design: defaultDesign
        };
        this.props.addTranslationForLanguage(frenchTranslations, "fr");
        this.props.addTranslationForLanguage(englishTranslations, "en");
    }

    updateZoom(zoom) {
        this.setState({ zoom: zoom })
    }

    addContainer() {
        alert("Adding container");
        let container = {
            width: 2,
            height: 5,
            unitOfMeasure: "INCH",
            xPos: 100,
            yPos: 100
        }

        designService.addDesignContainer(container).then( () => {
            alert("Added!!!");
        });
    }

    componentDidMount() {
        console.log("Edit Design props %s", this.props.match.params.id);
        designService.getDesign(this.props.match.params.id).then( (d) => {
            console.log("Got design %o",d.data);
            this.setState({design: d.data});
        }).catch(error => {
            alert("Error!");
        });
    }

    render() {
        return (
            <div>
                <PanelHeader size="sm"/>
                <div className="content">

                <Row>

                    <Col md={12}>
                        <Card>

                            <CardBody>

                                <DesignTools addContainer={this.addContainer.bind(this)} setZoom={this.updateZoom.bind(this)} design={this.state.design}/>


                            </CardBody>
                        </Card>
                    </Col>
                </Row>
                    <Row>
                    <Col md={12}>
                        <Card>

                            <CardBody>

                                <Design zoom={this.state.zoom} design={this.state.design}/>

                            </CardBody>
                        </Card>
                    </Col>
                </Row>

                </div>
            </div>
        );
    }
}

export default withLocalize(EditDesign);
