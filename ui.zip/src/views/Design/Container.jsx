import React from "react";

class Container extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            width: 50,
            height: 50,
            layerIdx: 1,
            xPos: 100,
            yPos: 100
        }

    }

    render() {

        return (
            <div class="a1-container">
                New Container

            </div>
        )
    }
}

export default Container;
