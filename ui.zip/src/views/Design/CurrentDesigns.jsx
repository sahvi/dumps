import React from "react";
import ReactTable from "react-table";
import { designService } from "../../_services";
import { UncontrolledAlert } from "reactstrap";
import { Translate, withLocalize } from "react-localize-redux";
import englishTranslations from "../../i18n/en/design.json";
import frenchTranslations from "../../i18n/fr/design.json";
import connect from "react-redux/es/connect/connect";
import {
  changeInstrumentType,
  fetchDesign,
  storeDesign
} from "../../_actions/design.action";
import { Button } from "../../components";
import { withRouter } from "react-router-dom";
import SweetAlert from "react-bootstrap-sweetalert";
import { fetchInstrumentTypes } from "../../_actions/sysconfig.action";

class CurrentDesigns extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      alert: null,
      instrumentType: "flyer"
    };

    this.props.addTranslationForLanguage(frenchTranslations, "fr");
    this.props.addTranslationForLanguage(englishTranslations, "en");
  }

  // static getDerivedStateFromProps(nextProps, prevState){
  //     if(nextProps.design!==prevState.design){
  //         return { design: nextProps.design};
  //     }
  //     else return null;
  // }

  componentDidUpdate(prevProps, prevState) {
    console.log("Updated %o %o", prevProps, prevState);
    //Perform some operation here
    //  this.setState({someState: someValue});
    // this.classMethod();
    // this.updateTable(this.state.instrumentType);
  }

  updateTable(type) {
    if (!type) {
      return;
    }
    console.log("Update Table %o %o", this.props, this.state);
    designService
      .getDesignsByInstrumentType(type)
      .then(res => {
        this.setState({
          data: res.data
        });
      })
      .catch(err => {
        this.setState({
          alert: (
            <UncontrolledAlert color="primary">
              <Translate id="err.get" data={{ error: err }} />
            </UncontrolledAlert>
          )
        });
      });
  }

  componentWillReceiveProps(nextProps, nextContext) {
    console.log("Got props %o", nextProps);
    if (this.state.instrumentType !== nextProps.currentTab) {
      this.setState({ instrumentType: nextProps.currentTab });
      this.updateTable(this.state.instrumentType);
    }
  }

  componentDidMount() {
    // this.updateTable(this.state.instrumentType);
  }

  editDesign(idx) {
    let rowID = this.state.data[idx].id;
    this.props.history.push("/designs/edit/" + rowID);
  }

  hideAlert() {
    this.setState({
      alert: null
    });
  }

  submitDelete(design) {
    console.log("submitDelete(${design}", design);
    let id = design.id;
    designService
      .deleteDesign(design.id)
      .then(res => {
        this.setState({
          alert: (
            <SweetAlert
              success
              style={{ display: "block", marginTop: "-100px" }}
              title="Deleted!"
              onConfirm={() => this.hideAlert()}
              onCancel={() => this.hideAlert()}
              confirmBtnBsStyle="info"
            >
              Design has been deleted.
            </SweetAlert>
          )
        });
        this.updateTable(this.state.instrumentType);
      })
      .catch(error => {
        alert("Error " + error);
      });
  }

  deleteDesign(idx) {
    console.log("Delete request for %s", idx);
    let selectedDesign = this.state.data[idx];
    let name = selectedDesign.name;

    this.setState({
      alert: (
        <SweetAlert
          warning
          style={{ display: "block", marginTop: "-100px" }}
          title="Are you sure?"
          onConfirm={() => this.submitDelete(selectedDesign)}
          onCancel={() => this.hideAlert()}
          confirmBtnBsStyle="info"
          cancelBtnBsStyle="danger"
          confirmBtnText="Yes, delete it!"
          cancelBtnText="Cancel"
          showCancel
        >
          <Translate id="delete.prompt" data={{ name: name }} />
        </SweetAlert>
      )
    });
  }

  render() {
    return (
      <div>
        {this.state.alert}

        <ReactTable
          data={this.state.data.map((row, idx) => {
            return {
              id: row["id"],
              name: row["name"],
              description: row["description"],
              size: row["size"],
              rows: row["rows"],
              columns: row["columns"],
              containers: row["containers"],
              actions: (
                // we've added some custom button actions
                <div className="actions-right">
                  {/* use this button to add a edit kind of action */}
                  <Button
                    onClick={() => this.editDesign(idx)}
                    color="warning"
                    size="sm"
                    round
                    icon
                  >
                    <i className="fa fa-edit" />
                  </Button>{" "}
                  {/* use this button to remove the data row */}
                  <Button
                    onClick={() => this.deleteDesign(idx)}
                    color="danger"
                    size="sm"
                    round
                    icon
                  >
                    <i className="fa fa-times" />
                  </Button>{" "}
                  {/* use this button to add a like kind of action */}
                  <Button
                    onClick={() =>
                      alert(
                        "You've pressed the duplicate button on row id: " + idx
                      )
                    }
                    color="info"
                    size="sm"
                    round
                    icon
                  >
                    <i className="fa fa-copy" />
                  </Button>{" "}
                </div>
              )
            };
          })}
          filterable
          columns={[
            {
              Header: "Name",
              accessor: "name"
            },
            {
              Header: "Description",
              accessor: "description"
            },
            {
              Header: "Size",
              accessor: "size"
            },
            {
              Header: "Rows",
              accessor: "rows"
            },
            {
              Header: "Columns",
              accessor: "columns"
            },
            {
              Header: "Container #",
              accessor: "containers.length"
            },
            {
              Header: "Actions",
              accessor: "actions",
              sortable: false,
              filterable: false
            }
          ]}
          defaultPageSize={10}
          showPaginationTop
          showPaginationBottom={false}
          className="-striped -highlight"
        />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  design: state.design.design,
  instrumentType: state.instrumentType
});

export default withRouter(
  connect(
    mapStateToProps,
    {
      fetchDesign,
      storeDesign,
      changeInstrumentType,
      fetchInstrumentTypes
    }
  )(withLocalize(CurrentDesigns))
);
