import React from "react";
import { withLocalize } from "react-localize-redux";
import Slider from "nouislider";
import { CardTitle, Col, Label, Row,CardBody, FormGroup, Input } from "reactstrap";
import Switch from "react-switch";
import {Button} from "../../components";
import englishTranslations from "../../i18n/en/design.json";
import frenchTranslations from "../../i18n/fr/design.json";
import { Translate } from "react-localize-redux";
import SweetAlert from "react-bootstrap-sweetalert";

class DesignTools extends React.Component {

    constructor(props) {
        super(props);
        this.zoomRef= React.createRef();
        this.state = {
            showGrid: true,
            alert: null
        }
        this.props.addTranslationForLanguage(frenchTranslations, "fr");
        this.props.addTranslationForLanguage(englishTranslations, "en");
    }

 toggleGrid() {
        this.setState({
            showGrid: !this.state.showGrid
        })
 }

    componentWillReceiveProps(newProps) {
        console.log("New props %o", newProps);
    }


    componentDidMount() {

        console.log("Tools mounted %o", this.props);
        console.log("Ref %o", this.zoomRef);
        Slider.create(this.zoomRef.current, {
            start: [100],
            step: 1,
            connect: true,
            tooltips: true,
            change: this.props.updateZoom,
            range: { min: 0, max: 150 }
        });

        this.zoomRef.current.noUiSlider.on('set', this.props.setZoom);


    }
    hideAlert() {
        this.setState({
            alert: null
        });
    }
    
    onSave() {
        this.setState({
            alert: (

                <SweetAlert
                    success
                    style={{ display: "block", marginTop: "-100px" }}
                    title="Saved"
                    onConfirm={() => this.hideAlert()}
                    onCancel={() => this.hideAlert()}
                    confirmBtnBsStyle="info"
                >
                    <Translate id="saved"/>
                </SweetAlert>
            )
        });
    }


    render() {

        return (
            <div>
                Size {this.props.design.size}
                <Row>

                    <Col md={4}>
                        <FormGroup>
                            <Input type="text" value={this.props.design.name} />
                        </FormGroup>

                    </Col>
                </Row>
                <Row>
                    <Col xs={12} md={4}>
                        <Label>Zoom {this.props.zoom}</Label>
                        <div className="slider slider-primary" ref={this.zoomRef}/>

                    </Col>
                </Row>

                <Row>
                    <Col xs={12} md={4}>
                        <Button
                            round
                            size="medium"
                            color="primary"
                            onClick={this.props.addContainer}>
                            <Translate id="add.container"/>
                        </Button>

                        <Button round
                                onClick={() => this.onSave()}
                                size="medium"
                                color="primary">
                            <Translate id="save"/>
                        </Button>
                    </Col>
                </Row>
                {this.state.alert}


            </div>
        )
    }
}

export default withLocalize(DesignTools);
