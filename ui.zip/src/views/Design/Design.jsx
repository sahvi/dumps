import React from "react";
import { withLocalize } from "react-localize-redux";
import frenchTranslations from "../../i18n/fr/design";
import englishTranslations from "../../i18n/en/design";
import RGL, { WidthProvider } from "react-grid-layout";
import _ from "lodash";
import { Input } from "reactstrap";
import SweetAlert from "react-bootstrap-sweetalert";

const ReactGridLayout = WidthProvider(RGL);

class Design extends React.Component {

    static defaultProps = {
        className: "layout",
        onLayoutChange: function() {
            console.log("layout change");
        },
        // cols: 5,
        // rows: 5,
        items: 3
    };

    constructor(props) {
        super(props);
        this.pageRef = React.createRef();
        this.state = {};
        this.setState({
            refresh: true,
            alert: null,
            pageHeightPixels: 0
        });
        const layout = this.generateLayout();
        this.setState({ layout });
        console.log("Layout %o", layout);
        console.log("New design page %o", props);


        this.props.addTranslationForLanguage(frenchTranslations, "fr");
        this.props.addTranslationForLanguage(englishTranslations, "en");

        this.setPageDimensions = this.setPageDimensions.bind(this);
    }

    onLayoutChange(layout) {
        this.props.onLayoutChange(layout);
    }

    generateLayout() {
        const p = this.props;
        return _.map(new Array(p.items), function(item, i) {
            const y = _.result(p, "y") || Math.ceil(Math.random() * 4) + 1;
            return {
                x: (i * 2) % 12,
                y: Math.floor(i / 6) * y,
                w: 2,
                h: y,
                i: i.toString()
            };
        });
    }

    generateDOM() {
        return _.map(_.range(this.props.items), function(i) {
            return (
                <div key={i}>

                    <span className="text">{i}</span>
                    <Input type="textarea" placeHolder={"info"}/>
                </div>
            );
        });
    }

    componentDidMount() {
        console.log("Mounted page area...%o", this.props.design);


        window.addEventListener("resize", evt => {
            this.setPageDimensions(this.props);
        });
        // var ps = new PerfectScrollbar('.design-page');

    }

    shouldComponentUpdate(nextProps, nextState, nextContext) {
        console.log("Should update %o %o", this.state, nextState);
        return true;
    }

    setPageDimensions(nextProps) {

        let design = nextProps.design;
        let uom = design.unitOfMeasure;
        let pageWidth = design.width;
        let pageHeight = design.height;
        let zoomScale = nextProps.zoom / 100;

        if ( this.pageRef && this.pageRef.current ) {

            let divWidth = this.pageRef.current.offsetWidth;

            switch (uom) {
                case "INCH": {


                    let oneInch = (divWidth / pageWidth) * zoomScale;
                    console.log("Size in inches.. Page width %f - divWidth %d One Inch=%f", pageWidth, divWidth, oneInch);

                    console.log("Div width %f [%f]", divWidth, oneInch);
                    let requiredHeight = pageHeight * oneInch;
                    let requiredWidth = pageWidth * oneInch;

                    console.log("Required height %f", requiredHeight);

                    this.setState({
                        pageHeightPixels: requiredHeight,
                        pageWidthPixels: requiredWidth
                    });
                }
            }
        }

    }

    componentWillReceiveProps(nextProps, nextContext) {
        console.log("Got new props %o", nextProps);

        if (nextProps.design.id) {

            console.log("Setting dimensions...");
            this.setPageDimensions(nextProps);
        }

    }


    componentDidUpdate(prevProps, prevState, snapshot) {
        if (this.props.design.id) {
            console.log("Updating page area...%o", this.props.design);
            // get the unit of measure
        }
    }

    render() {
        const pageOutlineStyle = {
            height: this.state.pageHeightPixels + "px",
            width: this.state.pageWidthPixels + "px"
        };

        return (

                <div className="a1-page ps-child design-page" ref={this.pageRef} style={pageOutlineStyle}>

                    <ReactGridLayout
                        cols={this.props.design.columns}
                        rows={this.props.design.rows}
                        layout={this.state.layout}
                        margin={[3,3]}
                        autoSize={true}
                        onLayoutChange={this.onLayoutChange}
                        {...this.props}
                    >
                        {this.generateDOM()}
                    </ReactGridLayout>
                        {this.state.alert}

                </div>


        );

    }

}

export default withLocalize(Design);
