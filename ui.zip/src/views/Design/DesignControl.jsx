import React from "react";
import PanelHeader from "../../components/PanelHeader/PanelHeader";
import { connect } from "react-redux";
import { Translate, withLocalize } from "react-localize-redux";
import {
  Card,
  CardBody,
  CardHeader,
  Col,
  Nav,
  NavItem,
  NavLink,
  Row,
  TabContent,
  TabPane
} from "reactstrap";

import { Button } from "../../components";
import englishTranslations from "../../i18n/en/design.json";
import frenchTranslations from "../../i18n/fr/design.json";
import CurrentDesigns from "./CurrentDesigns";
import { deadlineService, instrumentService } from "../../_services";
import { fetchInstrumentTypes } from "../../_actions/sysconfig.action";
import AddDesign from "./AddDesign";
import {
  changeInstrumentType,
  fetchDesign,
  storeDesign
} from "../../_actions/design.action";
import defaultDesign from "./defaultDesign";
import { withRouter } from "react-router-dom";
import InstrumentTypeButtonList from "../../components/InstrumentTypes/InstrumentTypeButtonList";

class DesignControl extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      alert: null,
      instrumentTypes: [],
      design: this.props.design ? this.props.design : defaultDesign,
      currentTab: ""
    };

    this.props.addTranslationForLanguage(frenchTranslations, "fr");
    this.props.addTranslationForLanguage(englishTranslations, "en");

    this.renderInstrumentTabs = this.renderInstrumentTabs.bind(this);
    this.handleAddClick = this.handleAddClick.bind(this);
    this.handleTabClick = this.handleTabClick.bind(this);

    // instrumentService.getInstrumentTypes().then(function(data) {
    //     console.log("Types %o", data);
    //
    //     let design = this.state.design;
    //     design.instrumentType = data[0].name;
    //     this.setState({ instrumentTypes: data, design: design });
    //     console.log("State %o", this.state);
    //
    // }.bind(this));
  }

  handleAddClick() {
    let design = this.state.design;
    design.modalOpen = true;
    this.setState({ design: design });
    console.log("Design state %o", design);
    this.props.storeDesign(this.state.design);
  }

  handleTabClick(e) {
    console.log("Click %o", e.target.name);
    let design = this.state.design;
    design.instrumentType = e.target.name;
    this.setState({ design: design, currentTab: e.target.name });
    this.props.storeDesign(design);
    // console.log("Design state change %o", this.state.design);
  }

  UNSAFE_componentWillReceiveProps(nextProps, nextContext) {
    console.log("Props updated");
    if (this.state.currentTab === "" && nextProps.instrumentTypes.length > 0) {
      this.setState({ currentTab: nextProps.instrumentTypes[0].name });
    }
  }

  renderInstrumentTabs() {
    if (
      this.props.instrumentTypes &&
      Array.isArray(this.props.instrumentTypes)
    ) {
      let i = 1;
      return this.props.instrumentTypes.map(ins => (
        <TabPane key={ins.name} tabId={ins.name}>
          <CurrentDesigns name={ins.name} currentTab={this.state.currentTab} />
        </TabPane>
      ));
    }
  }

  componentDidMount() {
    this.props.fetchInstrumentTypes();
  }

  render() {
    return (
      <div>
        <AddDesign modalOpen={this.state.design.modalOpen} />
        <PanelHeader size="sm" />
        <div className="content align-content-center">
          <Row>
            <Col xs={12} md={1}>
              <Card>
                <CardHeader>
                  <Button
                    round
                    size="lg"
                    onClick={this.handleAddClick}
                    color="primary"
                  >
                    <b className="fa fa-plus" />
                  </Button>
                </CardHeader>
              </Card>
            </Col>
            <Col xs={12} md={11}>
              <Card>
                <CardBody>
                  <Nav pills className="nav-pills-primary">
                    <InstrumentTypeButtonList
                      currentTab={this.state.currentTab}
                      tabClick={this.handleTabClick}
                    />
                  </Nav>
                  <TabContent
                    activeTab={this.state.design.instrumentType}
                    className="tab-space"
                  >
                    {this.renderInstrumentTabs()}
                  </TabContent>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    design: state.design.design,
    instrumentTypes: state.sysConfig.instrumentTypes
  };
}

export default withRouter(
  connect(
    mapStateToProps,
    {
      fetchDesign,
      storeDesign,
      changeInstrumentType,
      fetchInstrumentTypes
    }
  )(withLocalize(DesignControl))
);
