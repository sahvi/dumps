import React from "react";
import {
    Alert,
    Button,
    Card,
    CardBody,
    Col,
    FormGroup,
    Input,
    Label,
    Modal,
    ModalBody,
    ModalFooter,
    ModalHeader,
    Row
} from "reactstrap";
import { Translate, withLocalize } from "react-localize-redux";
import connect from "react-redux/es/connect/connect";
import { fetchDesign, storeDesign } from "../../_actions/design.action";
import { designService } from "../../_services/design.service";
import defaultDesign from "./defaultDesign";
import englishTranslations from "../../i18n/en/design.json";
import frenchTranslations from "../../i18n/fr/design.json";
import SweetAlert from "react-bootstrap-sweetalert";


class AddDesign extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            alert: null,
            design: this.props.design ? this.props.design : defaultDesign
        };

        this.props.addTranslationForLanguage(frenchTranslations, "fr");
        this.props.addTranslationForLanguage(englishTranslations, "en");
        this.toggleModal = this.toggleModal.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.createDesign = this.createDesign.bind(this);
    }

    componentWillMount() {
        this.props.fetchDesign();
    }

    hideAlert() {
        let design = this.state.design;
        design.modalOpen = !design.modalOpen;
        this.setState({ design: design });
        this.setState({ alert: null });
        this.props.storeDesign(this.state.design.design);

    }


    createDesign() {
        let postData = this.state.design;
        // postData["name"] = this.state.design.name;

        console.log("Creating design %o", postData);
        designService.createDesign(postData).then(res => {
            this.setState({
                alert: (

                    <SweetAlert
                        success
                        style={{ display: "block", marginTop: "-100px" }}
                        title={postData.name}
                        onConfirm={() => this.hideAlert()}
                        onCancel={() => this.hideAlert()}
                        confirmBtnBsStyle="info"
                    >
                        <Translate id="created"/>
                    </SweetAlert>
                )
            });
        }).catch(err => {
            this.setState({
                alert: (
                    <Alert color="primary">
                        <Translate id="err.create" data={{ error: err }}></Translate>
                    </Alert>
                )
            });
        });

    }


    toggleModal() {
        let design = this.state.design;
        design.modalOpen = !design.modalOpen;
        this.setState({
            design: design,
            alert: null
        });
        this.props.storeDesign(this.state.design.design);
    }


    handleChange(e) {

        let design = this.state.design;

        const { name, value } = e.target;
        design[name] = value;

        this.setState({
            design: design
        });
        this.props.storeDesign(this.state.design);


    }


    render() {

        return (
            <Modal toggle={this.toggleModal}
                   isOpen={this.state.design.modalOpen}

            >
                <ModalHeader className="justify-content-center" tag="div" toggle={this.toggleModal}>
                    <div className="header header-primary text-center">
                        <Translate id="create"/>
                        <h2>{this.state.design.instrumentType}</h2>
                    </div>
                </ModalHeader>
                <ModalBody>
                    <Card>

                        <CardBody>
                            <Row>
                                <Col xs={12} md={12}>
                                    <FormGroup>
                                        <Input type="text" name="name" placeholder="Name" onChange={this.handleChange}/>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row>
                                <Col xs={12} md={12}>
                                    <FormGroup>
                                        <Input type="text" name="description" placeholder="Description"
                                               onChange={this.handleChange}/>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row>
                                <Label><Translate id="pageSize"/></Label>
                            </Row>
                            <Row>
                                <Col xs={12} md={6}>
                                    <FormGroup>
                                        <Input name="width" type="number" step="0.1" min={0.1} placeholder="Width"
                                               value={this.state.design.width} onChange={this.handleChange}/>
                                    </FormGroup>
                                </Col>
                                <Col xs={12} md={6}>
                                    <FormGroup>
                                        <Input name="height" type="number" step="0.1" min={0.1} placeholder="Height"
                                               value={this.state.design.height} onChange={this.handleChange}/>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row>
                                <Label><Translate id="rowsAndColumns"/></Label>
                            </Row>
                            <Row>

                            <Col xs={12} md={3}>
                                <FormGroup>
                                    <Input name="rows" type="number" step="1" min={1} placeholder="Rows"
                                           value={this.state.design.rows} onChange={this.handleChange}/>
                                </FormGroup>
                            </Col>
                            <Col xs={12} md={3}>
                                <FormGroup>
                                    <Input name="columns" type="number" step="1" min={1} placeholder="Cols"
                                           value={this.state.design.columns} onChange={this.handleChange}/>
                                </FormGroup>
                            </Col>
                            </Row>
                            <Row>
                                <Label><Translate id="margins"/></Label>
                            </Row>
                            <Row>

                                <Col xs={12} md={3}>
                                    <FormGroup>
                                        <Input name="marginT" type="number" step="0.1" min={0} placeholder="Top"
                                               value={this.state.design.marginT} onChange={this.handleChange}/>
                                    </FormGroup>
                                </Col>
                                <Col xs={12} md={3}>
                                    <FormGroup>
                                        <Input name="marginL" type="number" step="0.1" min={0} placeholder="Left"
                                               value={this.state.design.marginL} onChange={this.handleChange}/>
                                    </FormGroup>
                                </Col>

                                <Col xs={12} md={3}>
                                    <FormGroup>
                                        <Input name="marginB" type="number" step="0.1" min={0} placeholder="Bottom"
                                               value={this.state.design.marginB} onChange={this.handleChange}/>
                                    </FormGroup>
                                </Col>
                                <Col xs={12} md={3}>
                                    <FormGroup>
                                        <Input name="marginR" type="number" step="0.1" min={0} placeholder="Right"
                                               value={this.state.design.marginR} onChange={this.handleChange}/>
                                    </FormGroup>
                                </Col>
                            </Row>
                        </CardBody>
                    </Card>
                </ModalBody>
                <ModalFooter>
                    <Button color="secondary" onClick={this.toggleModal}>
                        <Translate id="cancel"/>
                    </Button>
                    <Button color="primary" onClick={this.createDesign}>
                        <Translate id="submit"/>
                    </Button>
                </ModalFooter>
                {this.state.alert}
            </Modal>
        );
    }
}

const mapStateToProps = state => ({
    design: state.design.design
});
export default connect(mapStateToProps, { fetchDesign, storeDesign })(withLocalize(AddDesign));
