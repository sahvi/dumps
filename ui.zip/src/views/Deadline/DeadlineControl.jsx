import React, { Component } from "react";
import { Translate, withLocalize } from "react-localize-redux";
import { Card, CardBody, CardTitle, Col, Row } from "reactstrap";
import PanelHeader from "../../components/PanelHeader/PanelHeader";

class DeadlineControl extends Component {
  render() {
    return (
      <div>
        <PanelHeader size="sm" />
        <div className="content align-content-center">
          <Row>
            <Col xs={12} md={1}>
              <Card>
                <CardBody>Deadlines</CardBody>
              </Card>
            </Col>
            <Col xs={12} md={11}>
              <Card>
                <CardTitle tag="h3">
                  <Translate id="manage" />
                </CardTitle>
              </Card>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default withLocalize(DeadlineControl);
