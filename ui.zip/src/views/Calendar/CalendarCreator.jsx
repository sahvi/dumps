import React from "react";
import { Translate, withLocalize } from "react-localize-redux";

import { BlockPicker } from "react-color";
import {
  Col,
  Container,
  Form,
  FormGroup,
  Input,
  Label,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Row
} from "reactstrap";
import { Button } from "../../components";
import englishTranslations from "../../i18n/en/calendar.json";
import frenchTranslations from "../../i18n/fr/calendar.json";
import Datetime from "react-datetime";
import SimpleCheckbox from "../../components/CustomCheckbox/SimpleCheckbox";
import Moment from "moment";
import IconSelector from "../../components/IconSelector/IconSelector";
import SweetAlert from "react-bootstrap-sweetalert";
import { attributeService } from "../../_services/attribute_service";
import AttributeSelector from "../../components/Attributes/AttributeSelector";

const startdate = Moment().subtract(1, "days");
const endDate = Moment().add(15, "days");

const defaultCalendarValues = {
  name: "",
  description: ""
};

class CalendarCreator extends React.Component {
  events = [];

  constructor(props) {
    super(props);
    this.state = {
      selected: "calendar",
      isTimed: true,
      color: "#000000",
      creatorOpen: false,
      selectedCalendar: null,
      active: false,
      name: "",
      alert: null,
      attributes: [],
      timed: {
        startDate: startdate,
        endDate: endDate
      },
      validate: {
        nameState: "has-danger"
      }
    };

    this.props.addTranslationForLanguage(frenchTranslations, "fr");
    this.props.addTranslationForLanguage(englishTranslations, "en");
    this.handleChange = this.handleChange.bind(this);
    this.handleClose = this.handleClose.bind(this);

    this.validEnd = this.validEnd.bind(this);
    this.validStart = this.validStart.bind(this);
    this.setStartDate = this.setStartDate.bind(this);
    this.setEndDate = this.setEndDate.bind(this);
  }

  static handleChange({ target }) {
    if (target.checked) {
      target.removeAttribute("checked");
      target.parentNode.style.textDecoration = "";
    } else {
      target.setAttribute("checked", true);
      target.parentNode.style.textDecoration = "line-through";
    }
  }

  validEnd(moment) {
    return moment.isAfter(this.state.timed.startDate);
  }

  validStart(moment) {
    return moment.isAfter(startdate);
  }

  componentDidMount() {
    attributeService.getAttributesByEntity("Calendar").then(res => {
      console.log("Attributes!!!...%o", res);
    });
  }

  componentWillReceiveProps(newProps) {
    console.log("Calendar Creator got props! %o", newProps);
    this.setState({
      creatorOpen: newProps.creatorOpen
    });
    if (newProps.selectedCalendar && newProps.selectedCalendar.id) {
      this.setState({
        selectedCalendar: newProps.selectedCalendar,
        name: newProps.selectedCalendar.name,
        colour: newProps.selectedCalendar.colour,
        active: newProps.selectedCalendar.active,
        icon: newProps.selectedCalendar.icon
      });
    } else {
      this.setState({
        defaultCalendarValues
      });
      console.log("New state %o", this.state);
    }
  }

  setStartDate(val) {
    this.setState({
      timed: {
        startDate: val
      }
    });
  }

  setEndDate(val) {
    this.setState({
      timed: {
        endDate: val
      }
    });
  }

  handleChangeComplete = color => {
    this.setState({ colour: color.hex });
  };

  handleModelClose = () => {
    console.log("Closing model?");
  };

  handleClose = () => {
    this.setState({
      creatorOpen: false
    });
  };

  updateCalendar = () => {
    console.log("Updating calendar %o", this.state);
  };

  hideAlert() {
    this.setState({
      alert: null
    });
  }

  handleEditOrCreate = () => {
    if (this.state.selectedCalendar) {
      this.setState({
        alert: (
          <SweetAlert
            warning
            showCancel
            confirmBtnText="Yes, delete it!"
            confirmBtnBsStyle="danger"
            cancelBtnBsStyle="default"
            title="Are you sure?"
            onConfirm={this.updateCalendar()}
            onCancel={this.hideAlert()}
          >
            You will not be able to recover this imaginary file!
          </SweetAlert>
        )
      });
    } else {
      this.setState({
        alert: (
          <SweetAlert
            warning
            style={{ display: "block", marginTop: "-150px" }}
            title="Creation done"
            onConfirm={() => this.hideAlert()}
            confirmBtnBsStyle="info"
            confirmBtnText="Yes, update!"
          />
        )
      });
    }
  };

  toggleTimed = () => {
    this.setState({
      isTimed: !this.state.isTimed
    });
  };

  toggleActive = () => {
    this.setState({
      active: !this.state.active
    });
  };

  handleChange(e) {
    this.setState({ name: e.target.value });
    if (e.target.value.length >= 3) {
      this.state.validate.nameState = "has-success";
    } else {
      this.state.validate.nameState = "has-danger";
    }
  }

  render() {
    const { classes, onClose, variant, ...other } = this.props;
    return (
      <Modal isOpen={this.state.creatorOpen}>
        <ModalHeader className="justify-content-center" tag="div">
          <div className="header header-primary text-center">
            {this.state.selectedCalendar && this.state.selectedCalendar.id ? (
              <Translate id="calendar.edit.text" />
            ) : (
              <Translate id="calendar.create.text" />
            )}
          </div>
        </ModalHeader>

        <ModalBody>
          <Form>
            <Container>
              <Row>
                <Col>
                  <Row>
                    <Col md={6}>
                      <FormGroup className={"form-control-lg"}>
                        <Input
                          type="text"
                          onChange={this.handleChange}
                          valid={
                            this.state.validate.nameState === "has-success"
                          }
                          invalid={
                            this.state.validate.nameState === "has-danger"
                          }
                          defaultValue={this.state.name}
                        />
                      </FormGroup>
                    </Col>
                    <Col md={6}>
                      <SimpleCheckbox
                        label={<Translate id="active" />}
                        name="active"
                        inputProps={{
                          checked: this.state.active,
                          onChange: cal => this.toggleActive(cal)
                        }}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col md>
                      <Label>
                        <Translate id="color" />
                      </Label>
                      <BlockPicker
                        color={this.state.colour}
                        onChangeComplete={this.handleChangeComplete}
                        value={this.state.colour}
                      />
                    </Col>
                    <Col md>
                      <Label>
                        <Translate id="icon" />
                      </Label>
                      <IconSelector
                        selected={this.state.icon}
                        colour={this.state.colour}
                      />
                    </Col>
                  </Row>

                  <Row>
                    <Col>
                      <SimpleCheckbox
                        label={<Translate id="timed" />}
                        name="timed"
                        inputProps={{
                          onChange: event => this.toggleTimed(event)
                        }}
                        checked={this.state.isTimed}
                      />
                    </Col>
                  </Row>
                  <p />
                </Col>
              </Row>
              {!this.state.isTimed && (
                <FormGroup>
                  <Row>
                    <Col>
                      <Datetime
                        timeFormat={false}
                        onChange={this.setStartDate}
                        isValidDate={this.validStart}
                        value={this.state.timed.startDate}
                        inputProps={{
                          placeholder: <Translate id="startDate" />
                        }}
                      />
                    </Col>
                    <Col>
                      <Datetime
                        timeFormat={false}
                        onChange={this.setEndDate}
                        isValidDate={this.validEnd}
                        value={this.state.timed.endDate}
                        inputProps={{ placeholder: <Translate id="endDate" /> }}
                      />
                    </Col>
                  </Row>
                </FormGroup>
              )}
              <AttributeSelector
                changeHandler={e => this.attributeChange(e)}
                entityType="calendar"
              />
            </Container>
          </Form>
        </ModalBody>

        <ModalFooter>
          <Button onClick={this.handleClose} color="primary">
            <Translate id="cancel" />
          </Button>
          <Button onClick={this.handleEditOrCreate} color="primary" autoFocus>
            <Translate id="submit" />
          </Button>
        </ModalFooter>
        {this.state.alert}
      </Modal>
    );
  }

  attributeChange(attr) {
    let attributes = this.state.attributes;
    if (attr.hasOwnProperty("id")) {
      attributes.push({
        id: attr.id,
        key: attr.value
      });
    } else if (attr.hasOwnProperty("target")) {
      attributes.push({
        id: attr.target.name,
        key: attr.target.value
      });
    } else {
      console.warn("Not sure how to handle attribute %o", attr);
    }

    this.setState({ attributes });
  }
}

export default withLocalize(CalendarCreator);
