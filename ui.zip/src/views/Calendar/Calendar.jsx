import React from "react";
// import BigCalendar from 'react-big-calendar'
import withDragAndDrop from "react-big-calendar/lib/addons/dragAndDrop";
import PropTypes from "prop-types";
import withStyles from "@material-ui/core/styles/withStyles";
import { eventService } from "../../_services";
import { connect } from "react-redux";

import green from "@material-ui/core/colors/green";
import amber from "@material-ui/core/colors/amber";
import IconButton from "@material-ui/core/IconButton";
import Snackbar from "@material-ui/core/Snackbar";
import SnackbarContent from "@material-ui/core/SnackbarContent";
import { Card } from "reactstrap";
import classNames from "classnames";
// import "assets/css/calendar.css"
// import EventWorkflow from "./workflow/EventWorkflow";
import { Translate, withLocalize } from "react-localize-redux";
import Calendars from "./Calendars";
import CalendarCreator from "./CalendarCreator";
import { Button, Col, Row } from "reactstrap";

// import 'react-big-calendar-like-google/lib/addons/dragAndDrop/styles.less';
//
// import 'react-big-calendar/lib/less/styles.less'

// import 'react-big-calendar-like-google/lib/addons/dragAndDrop/styles.less';
//
// import 'react-big-calendar/lib/less/styles.less'

// BigCalendar.setLocalizer(
//   BigCalendar.momentLocalizer(moment)
// );

const styles = theme => ({
  button: {
    marginLeft: "46%",
    backgroundColor: "#3f51b5",
    color: "white"
  },
  input: {
    display: "none"
  },
  root: {
    flexGrow: 1
  },
  grow: {
    flexGrow: 1,
    marginLeft: "5%"
  },
  menuButton: {
    marginLeft: "40%"
  },
  textField: {
    marginLeft: "40%",
    width: "20%"
  }
});

const messageStyles = theme => ({
  success: {
    backgroundColor: green[600]
  },
  error: {
    backgroundColor: theme.palette.error.dark
  },
  info: {
    backgroundColor: theme.palette.primary.light
  },
  warning: {
    backgroundColor: amber[700]
  },
  icon: {
    fontSize: 20
  },
  iconVariant: {
    opacity: 0.9,
    marginRight: theme.spacing.unit
  },
  message: {
    display: "flex",
    alignItems: "center"
  }
});

// const DragAndDropCalendar = withDragAndDrop(BigCalendar);

function MessageContent(props) {
  const { classes, className, message, onClose, variant, ...other } = props;
  // const Icon = variantIcon[variant];

  return (
    <SnackbarContent
      className={classNames(classes[variant], className)}
      aria-describedby="client-snackbar"
      message={
        <span id="client-snackbar" className={classes.message}>
          {/*<Icon className={classNames(classes.icon, classes.iconVariant)}/>*/}
          {/*{message}*/}
        </span>
      }
      action={[
        <IconButton
          key="close"
          aria-label="Close"
          color="inherit"
          className={classes.close}
          onClick={onClose}
        >
          {/*<CloseIcon className={classes.icon}/>*/}
        </IconButton>
      ]}
      {...other}
    />
  );
}

MessageContent.propTypes = {
  classes: PropTypes.object.isRequired,
  className: PropTypes.string,
  message: PropTypes.node,
  onClose: PropTypes.func,
  variant: PropTypes.oneOf(["success", "warning", "error", "info"]).isRequired
};

const MySnackbarContentWrapper = withStyles(messageStyles)(MessageContent);

class Calendar extends React.Component {
  constructor(props) {
    super(props);
    this.moveEvent = this.moveEvent.bind(this);
    this.resizeEvent = this.resizeEvent.bind(this);

    this.handleModelClickOpen = this.handleModelClickOpen.bind(this);
    this.handleModelClose = this.handleModelClose.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleMessageClose = this.handleMessageClose.bind(this);
    this.handleNewEventDrag = this.handleNewEventDrag.bind(this);
    this.updateModalState = this.updateModalState.bind(this);

    this.state = {
      events: [],
      saveError: false,
      modelOpen: false,
      openMessage: false,
      showSaveChanges: false,
      selectedEvent: {
        id: "",
        name: "",
        startDate: new Date(),
        endDate: new Date(),
        runDate: new Date(),
        color: "#000",
        selected: false,
        eventType: "",
        eventCreationType: "",
        templateId: "",
        finalPage: false
      }
    };
  }

  handleMessageClose = event => {
    this.setState({ openMessage: false });
  };

  componentDidMount() {
    eventService.getEvents().then(events => {
      var newList = events.map(function(event) {
        let newEvent = {
          title: event.name,
          backgroundColor: event.color,
          start: new Date([event.startDate]),
          end: new Date([event.endDate]),
          id: event.id
        };
        return newEvent;
      });
      this.setState({ events: newList });
    });
  }

  eventStyleGetter(event, start, end, isSelected) {
    var style = {
      backgroundColor: event.backgroundColor
    };
    return {
      style: style
    };
  }

  moveEvent({ event, start, end, isAllDay: droppedOnAllDaySlot }) {
    const { events } = this.state;

    const idx = events.indexOf(event);
    let allDay = event.allDay;

    if (!event.allDay && droppedOnAllDaySlot) {
      allDay = true;
    } else if (event.allDay && !droppedOnAllDaySlot) {
      allDay = false;
    }

    const updatedEvent = { ...event, start, end, allDay };

    const nextEvents = [...events];
    nextEvents.splice(idx, 1, updatedEvent);

    this.setState({
      events: nextEvents,
      showSaveChanges: true
    });

    // alert(`${event.title} was dropped onto ${updatedEvent.start}`)
  }

  resizeEvent = ({ event, start, end }) => {
    const { events } = this.state;

    const nextEvents = events.map(existingEvent => {
      return existingEvent.id == event.id
        ? { ...existingEvent, start, end }
        : existingEvent;
    });

    this.setState({
      events: nextEvents,
      showSaveChanges: true
    });
  };

  handleNewEventDrag = event => {
    const selectedEvent = {
      name: "",
      startDate: event.start,
      endDate: event.end,
      runDate: new Date(),
      color: "#000",
      selected: true,
      eventType: "",
      eventCreationType: "",
      templateId: "",
      showPage: "page1",
      finalPage: false
    };
    this.setState({ modelOpen: true, selectedEvent: selectedEvent });
  };

  handleCalendarClickOpen = () => {
    this.setState({ calendarModalOpen: true });
  };

  handleModelClickOpen = () => {
    this.setState({
      modelOpen: true,
      selectedEvent: {
        name: "",
        color: "#000"
      }
    });
    const selectedEvent = {
      name: "",
      startDate: new Date(),
      endDate: new Date(),
      runDate: new Date(),
      color: "#000",
      selected: true,
      eventType: "",
      eventCreationType: "",
      templateId: "",
      showPage: "page1",
      finalPage: false
    };
    this.setState({ modelOpen: true, selectedEvent: selectedEvent });
  };

  handleModelClose = () => {
    console.log("Closing model?");
    this.setState({ modelOpen: false });
  };

  handleChange = name => event => {
    this.setState({
      [name]: event.target.value
    });
  };
  formatDate = date => {
    if (date) {
      let d = new Date(date),
        month = "" + (d.getMonth() + 1),
        day = "" + d.getDate(),
        year = d.getFullYear();

      if (month.length < 2) month = "0" + month;
      if (day.length < 2) day = "0" + day;

      return [year, month, day].join("-");
    } else {
      return new Date();
    }
  };

  updateModalState = newState => {
    var newList = this.state.events;
    let newEvent = {
      title: newState.newEvent.name,
      backgroundColor: newState.newEvent.color,
      start: new Date([newState.newEvent.startDate]),
      end: new Date([newState.newEvent.endDate]),
      id: newState.newEvent.id
    };

    if (newState.save) {
      var newList = this.state.events;
      let newEvent = {
        title: newState.newEvent.name,
        backgroundColor: newState.newEvent.color,
        start: new Date([newState.newEvent.startDate]),
        end: new Date([newState.newEvent.endDate]),
        id: newState.newEvent.id
      };
      newList.push(newEvent);
      this.setState({
        modelOpen: newState.modelOpen,
        openMessage: newState.openMessage,
        events: newList
      });
    } else {
      this.setState({
        modelOpen: newState.modelOpen,
        openMessage: newState.openMessage,
        events: this.state.events
      });
    }
  };

  render() {
    const { classes, onClose, variant, ...other } = this.props;
    // const Icon = variantIcon[variant];
    const addButtonStyle = {
      margin: 2,
      marginBottom: 5,
      backgroundColor: "#3f51b5",
      color: "white",
      width: "15%"
    };
    const saveButtonStyle = {
      margin: 2,
      marginBottom: 5,
      backgroundColor: "#09b581",
      color: "white",
      width: "15%"
    };
    const redFont = {
      color: "red"
    };
    return (
      <div className="content">
        <Row>
          <Col md={2} xs={2}>
            <Card>
              <Button
                round
                size="medium"
                color="primary"
                onClick={this.handleModelClickOpen}
              >
                <Translate id="calendar.add.campaign" />
              </Button>
              <Button
                round
                size="medium"
                color="primary"
                onClick={this.handleCalendarClickOpen}
              >
                <Translate id="calendar.add.calendar" />
              </Button>
              <div className={classNames(classes.section, classes.boxShadow)}>
                <Calendars />
              </div>
            </Card>
          </Col>

          <Col xs={10} className={classes.calendarContainer}>
            {this.state.showSaveChanges ? (
              <Button
                size="large"
                style={saveButtonStyle}
                primary={true}
                onClick={this.handleModelClickOpen}
              >
                Save Changes
              </Button>
            ) : null}

            <Snackbar
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left"
              }}
              open={this.state.openMessage}
              autoHideDuration={6000}
              onClose={this.handleMessageClose}
            >
              <MySnackbarContentWrapper
                onClose={this.handleMessageClose}
                variant="success"
                message="Event saved successfully"
              />
            </Snackbar>
          </Col>
        </Row>
      </div>
    );
  }
}

Calendar.propTypes = {
  classes: PropTypes.object.isRequired,
  onClose: PropTypes.func,
  variant: PropTypes.oneOf(["success", "warning", "error", "info"]).isRequired
};
export default withLocalize(Calendar);
