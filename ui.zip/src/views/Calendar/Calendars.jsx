import React from "react";
import PropTypes from "prop-types";

import { calendarService } from "../../_services/calendar.service";

import Switch from "react-switch";
import { Form } from "reactstrap";
import { withLocalize } from "react-localize-redux";

class Calendars extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      calendars: [],
      isLoading: true
    };
    this.calSwitch = this.calSwitch.bind(this);
  }

  renderCalendarControls() {
    if (this.state.calendars && Array.isArray(this.state.calendars)) {
      return this.state.calendars.map(cal => (
        <tr key={cal.id}>
          <td>{cal.id}</td>
        </tr>
      ));
    } else {
      return <td>No calendars</td>;
    }
  }

  componentDidMount() {
    console.log("Loading calendars...");

    calendarService.getCalendars().then(d => {
      console.log("Got calendars %o", d);
      d.map(c => {
        c.checked = true;
      });
      this.setState({
        calendars: d,
        isLoading: false
      });
      console.log("State %o", this.state);
    });
  }

  componentWillReceiveProps(nextProps, nextContext) {}

  render() {
    const { isLoading, calendars } = this.props;

    return (
      <div>
        <Form row>
          {!this.state.isLoading ? (
            this.state.calendars.map((calendar, i) => {
              const { id, name, colour, icon } = calendar;
              return (
                <div key={calendar.id} style={{ width: "90%", display: "inline-flex" }}>
                  <label
                    style={{
                      width: "90%",
                      display: "inline-flex",
                      alignItems: "center"
                    }}
                  >
                    <Switch
                      onChange={this.calSwitch}
                      checked={calendar.checked}
                      handleDiameter={30}
                      id={i}
                      boxShadow="0px 1px 5px rgba(0,0,0,0.6)"
                      uncheckedIcon={false}
                      onColor={calendar.colour}
                    />
                    <span style={{ paddingLeft: "10px" }}>{calendar.name}</span>
                  </label>
                </div>
              );
            })
          ) : (
            // If there is a delay in data, let's let the user know it's loading
            <h2>Loading...</h2>
          )}
        </Form>
      </div>
    );
  }

  calSwitch = (checked, proto, id) => {
    let cals = this.state.calendars;
    console.log("Changing %o %o", cals, id);
    cals[id].checked = checked;

    this.setState({ cals });
  };
}

Calendars.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withLocalize(Calendars);
