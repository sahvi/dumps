import PanelHeader from "../../components/PanelHeader/PanelHeader";
import React from "react";
import { Translate, withLocalize } from "react-localize-redux";
import {
  Card,
  CardBody,
  CardTitle,
  Col,
  Row,
  UncontrolledAlert
} from "reactstrap";
import CalendarCreator from "./CalendarCreator";
import { Button } from "../../components";
import englishTranslations from "../../i18n/en/calendar.json";
import frenchTranslations from "../../i18n/fr/calendar.json";
import { calendarService } from "../../_services/calendar.service";
import ReactTable from "react-table";
import SimpleCheckbox from "../../components/CustomCheckbox/SimpleCheckbox";
import SweetAlert from "react-bootstrap-sweetalert";

class CalendarControl extends React.Component {
  dataTable = [];

  constructor(props) {
    super(props);
    this.state = {
      calendarModalOpen: false,
      dataTable: [],
      alert: null,
      selectedCalendar: null
    };

    this.props.addTranslationForLanguage(frenchTranslations, "fr");
    this.props.addTranslationForLanguage(englishTranslations, "en");
  }

  handleAddClick() {
    this.setState({ calendarModalOpen: true, selectedCalendar: null });
  }

  componentDidMount() {
    calendarService
      .getCalendars()
      .then(res => {
        console.log("Got data %o", res);
        this.setState({
          dataTable: res
        });
      })
      .catch(error => {});
  }

  updateTable() {
    calendarService
      .getCalendars()
      .then(res => {
        this.setState({
          dataTable: res
        });
      })
      .catch(err => {
        this.setState({
          alert: (
            <UncontrolledAlert color="primary">
              <Translate id="err.get" data={{ error: err }} />
            </UncontrolledAlert>
          )
        });
      });
  }

  hideAlert() {
    this.setState({
      alert: null
    });
  }

  submitDelete(calId) {
    calendarService.deleteCalendar(calId).then(res => {
      this.setState({
        alert: (
          <SweetAlert
            success
            style={{ display: "block", marginTop: "-100px" }}
            title="Deleted!"
            onConfirm={() => this.hideAlert()}
            onCancel={() => this.hideAlert()}
            confirmBtnBsStyle="info"
          >
            Calendar has been deleted.
          </SweetAlert>
        )
      });

      this.updateTable();
    });
  }

  editCalendar = idx => {
    this.setState({
      calendarModalOpen: true,
      selectedCalendar: this.state.dataTable[idx]
    });
  };

  componentWillReceiveProps(nextProps, nextContext) {
    console.log("Calendar control got new props...%o", nextProps);
  }

  handleDelete = idx => {
    let calId = this.state.dataTable[idx].id;
    let name = this.state.dataTable[idx].name;
    this.setState({
      calendarModalOpen: false,
      selectedCalendar: this.state.dataTable[idx]
    });
    this.setState({
      alert: (
        <SweetAlert
          warning
          style={{ display: "block", marginTop: "-150px" }}
          title="Are you sure?"
          onConfirm={() => this.submitDelete(calId)}
          onCancel={() => this.hideAlert()}
          confirmBtnBsStyle="info"
          cancelBtnBsStyle="danger"
          confirmBtnText="Yes, delete it!"
          cancelBtnText="Cancel"
          showCancel
        >
          <Translate id="delete.prompt" data={{ name: name }} />
        </SweetAlert>
      )
    });
  };

  handleCalendarClickOpen = () => {
    this.setState({ calendarModalOpen: true });
  };

  render() {
    let columns = [];

    return (
      <div>
        <PanelHeader size="sm" />
        <div className="content align-content-center">
          <Row>
            <Col xs={12} md={1}>
              <Card>
                <CardBody>
                  <Button
                    round
                    size="md"
                    onClick={() => {
                      this.handleAddClick();
                    }}
                    color="primary"
                  >
                    <b className="fa fa-plus" />
                  </Button>
                </CardBody>
              </Card>
            </Col>

            <Col xs={12} md={11}>
              <Card>
                <CardBody>
                  <ReactTable
                    data={this.state.dataTable.map((prop, key) => {
                      return {
                        id: key,
                        name: prop["name"],
                        active: prop["active"],
                        colour: prop["colour"],
                        icon: prop["icon"],
                        startDate: prop["startDate"],
                        endDate: prop["endDate"],
                        actions: (
                          // we've added some custom button actions
                          <div className="actions-right">
                            {/* use this button to add a edit kind of action */}
                            <Button
                              onClick={() => this.editCalendar(key)}
                              color="warning"
                              size="sm"
                              round
                              icon
                            >
                              <i className="fa fa-edit" />
                            </Button>{" "}
                            {/* use this button to remove the data row */}
                            <Button
                              onClick={() => this.handleDelete(key)}
                              color="danger"
                              size="sm"
                              round
                              icon
                            >
                              <i className="fa fa-times" />
                            </Button>{" "}
                          </div>
                        )
                      };
                    })}
                    columns={[
                      {
                        Header: "Name",
                        accessor: "name"
                      },
                      {
                        Header: "Colour",
                        accessor: "colour",
                        Cell: row => (
                          <div
                            className="circle"
                            style={{
                              backgroundColor: row.value,
                              transition: "all .2s ease-out"
                            }}
                          />
                        )
                      },
                      {
                        Header: "Icon",
                        accessor: "icon",
                        Cell: row => (
                          <div>
                            <i className={"icon-lg " + row.value} />
                          </div>
                        )
                      },
                      {
                        Header: "Active",
                        accessor: "active",
                        Cell: row => (
                          <SimpleCheckbox
                            label="&nbsp;"
                            name="active"
                            inputProps={{ checked: row.value, disabled: true }}
                          />
                        )
                      },
                      {
                        Header: "Start Date",
                        accessor: "startDate"
                      },
                      {
                        Header: "End Date",
                        accessor: "endDate"
                      },
                      {
                        Header: "Actions",
                        accessor: "actions",
                        sortable: false,
                        filterable: false
                      }
                    ]}
                  />
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
        {this.state.alert}
        <CalendarCreator
          selectedCalendar={this.state.selectedCalendar}
          creatorOpen={this.state.calendarModalOpen}
        />
      </div>
    );
  }
}

export default withLocalize(CalendarControl);
