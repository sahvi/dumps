import React, {Component} from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";

import Button from "../../components/CustomButton/CustomButton.jsx";

const dataTable = [
    ["Offer A", "Summer Special", "Produce", 104],
    ["Offer B", "Summer Special", "Dairy", 122],
    ["Offer C", "Summer Special", "Salad", 532],
    ["Offer D","Summer Special", "Snacks", 465],
    ["Offer E", "Summer Special", "Milk", 432]
];

class ToDoTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: dataTable.map((prop, key) => {
                return {
                    id: key,
                    name: prop[0],
                    position: prop[1],
                    office: prop[2],
                    age: prop[3],
                    actions: (
                        // we've added some custom button actions
                        <div className="actions-right">
                            {/* use this button to add a like kind of action */}
                            <Button
                                onClick={() => {
                                    let obj = this.state.data.find(o => o.id === key);
                                    alert(
                                        "You've clicked LIKE button on \n{ \nName: " +
                                        obj.name +
                                        ", \nposition: " +
                                        obj.position +
                                        ", \noffice: " +
                                        obj.office +
                                        ", \nage: " +
                                        obj.age +
                                        "\n}."
                                    );
                                }}
                                color="info"
                                size="sm"
                                round
                                icon
                            >
                                <i className="fa fa-heart"/>
                            </Button>{" "}
                            {/* use this button to add a edit kind of action */}
                            <Button
                                onClick={() => {
                                    let obj = this.state.data.find(o => o.id === key);
                                    alert(
                                        "You've clicked EDIT button on \n{ \nName: " +
                                        obj.name +
                                        ", \nposition: " +
                                        obj.position +
                                        ", \noffice: " +
                                        obj.office +
                                        ", \nage: " +
                                        obj.age +
                                        "\n}."
                                    );
                                }}
                                color="warning"
                                size="sm"
                                round
                                icon
                            >
                                <i className="fa fa-edit"/>
                            </Button>{" "}
                            {/* use this button to remove the data row */}
                            <Button
                                onClick={() => {
                                    var data = this.state.data;
                                    data.find((o, i) => {
                                        if (o.id === key) {
                                            // here you should add some custom code so you can delete the data
                                            // from this component and from your server as well
                                            data.splice(i, 1);
                                            console.log(data);
                                            return true;
                                        }
                                        return false;
                                    });
                                    this.setState({data: data});
                                }}
                                color="danger"
                                size="sm"
                                round
                                icon
                            >
                                <i className="fa fa-times"/>
                            </Button>{" "}
                        </div>
                    )
                };
            })
        };
    }

    render() {
        return (


            <ReactTable
                data={this.state.data}
                filterable
                columns={[
                    {
                        Header: "Name",
                        accessor: "name"
                    },
                    {
                        Header: "Campaign",
                        accessor: "position"
                    },
                    {
                        Header: "Description",
                        accessor: "office"
                    },
                    {
                        Header: "POT",
                        accessor: "age"
                    },
                    {
                        Header: "Actions",
                        accessor: "actions",
                        sortable: false,
                        filterable: false
                    }
                ]}
                defaultPageSize={5}
                showPaginationTop
                showPaginationBottom={false}
                className="-striped -highlight"
            />


        );
    }
}

export default ToDoTable;
