import React, { Component } from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";
import { connect } from "react-redux";
import { fetchAlertState } from "../../_actions/dashboard.action";
import { withLocalize } from "react-localize-redux";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const dataTable = [
    ["Winter Campaign", "danger", "Space Allocation","1/22/2019", "campaign:21434545"],
    ["Winter Campaign/Page 1/Container A", "warn", "Offer Required","1/27/2019", "container:21434545"],
    ["Winter Campaign/Page 1/Container B", "warn", "Offer Required","1/27/2019", "container:21434546"],
    ["Winter Campaign/Page 1/Container C", "warn", "Offer Required","1/27/2019", "container:21434547"],
    ["Spring Campaign", "info", "Campaign setup","4/27/2019", "campaign:214399546"],
];

const onRowClick = (state, rowInfo, column, instance) => {
    return {
        onClick: e => {
            toast.info('Clicked ' + rowInfo.row.name);
            console.log('A Td Element was clicked!');
            console.log('it produced this event:', e);
            console.log('It was in this column:', column);
            console.log('It was in this row:', rowInfo);
            console.log('It was in this table instance:', instance)
        }
    }
};

class AlertTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: dataTable.map((prop, key) => {
                return {
                    id: key,
                    name: prop[0],
                    state: prop[1],
                    deadline: prop[2],
                    due: prop[3],
                    locator: prop[4]
                };
            })
        };
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log("Got new props...%o", this.props);
        if ( this.props.alertState !== prevProps.alertState) {
            this.setState({
                alertState: this.props.alertState
            })
        }
    }



    render() {
        return (
            <div>
                <ToastContainer/>
                <ReactTable
                    getTrProps={onRowClick}
                    data={this.state.data}
                    filterable
                    columns={[
                        {
                            Header: "Name",
                            accessor: "name",
                            width: 500
                        },
                        {
                            Header: "State",
                            accessor: "state",
                            width: 100
                        },
                        {
                            Header: "Deadline Type",
                            accessor: "deadline"
                        },
                        {
                            Header: "Due Date",
                            accessor: "due"
                        }
                    ]}
                    defaultPageSize={5}
                    showPaginationTop={false}
                    showPaginationBottom={true}
                    className="-striped -highlight"
                />
            </div>



        );
    }
}

const mapStateToProps = state => ({
    alertState: state.dashboard.alertState
});

export default connect(
    mapStateToProps,
    { fetchAlertState }, null, { withRef: true }
)(withLocalize(AlertTable));
