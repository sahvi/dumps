import React from "react";
import PanelHeader from "../../components/PanelHeader/PanelHeader";
import { withLocalize } from "react-localize-redux";
import { Card, CardBody, Col, Row } from "reactstrap";
import IconCheckbox from "../../components/CustomCheckbox/IconCheckbox";

class AdminControl extends React.Component {

    constructor(props) {
        super(props);
        this.state= {
            manageInstrumentTypes:false
        }
    }

    handleChange(checkboxState) {
        alert("Click");
    }

    render() {
        return (
            <div>
                <PanelHeader size="sm">
                </PanelHeader>
                <div className="content align-content-center">

                    <Row>
                        <Col md={12}>
                        <Card>
                            <CardBody>
                                <IconCheckbox
                                    name="instrumentTypes"
                                    value="instrumentTypes"
                                    icon="now-ui-icons shopping_tag-content"
                                    title="instrumentTypes"
                                    onClick={() => {this.handleChange()}}
                                    checked={this.state.manageInstrumentTypes?this.state.manageInstrumentTypes:""}
                                />

                            </CardBody>
                        </Card>
                        </Col>
                    </Row>
                </div>
            </div>
        )
    }
}

export default withLocalize(AdminControl);
