import React from "react";
import {
  Alert,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText
} from "reactstrap";
import { connect } from "react-redux";

import { Button } from "components";

import a1Logo from "assets/img/a1Logo.png";

import bgImage from "assets/img/motorway.jpg";
import { userService } from "../../_services";
import { fetchUserInfo, storeUser } from "../../_actions/user.action";
import { Translate, withLocalize } from "react-localize-redux";
import englishTranslations from "../../i18n/en/global.json";
import frenchTranslations from "../../i18n/fr/global.json";
import ForgotPass from "./Forgot/ForgotPass";
import { renderToStaticMarkup } from "react-dom/server";

class LoginPage extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      alert: null,
      username: "",
      password: "",
      loginError: "false",
      showForgot: false
    };

    this.props.initialize({
      languages: [
        { name: "English", code: "en" },
        { name: "French", code: "fr" }
      ],
      options: { renderToStaticMarkup }
    });

    this.handleChange = this.handleChange.bind(this);
    this.authenticate = this.authenticate.bind(this);

    this.props.addTranslationForLanguage(frenchTranslations, "fr");
    this.props.addTranslationForLanguage(englishTranslations, "en");
  }

  handleChange(e) {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  }

  authenticate(e) {
    e.preventDefault();
    const { username, password, loginError } = this.state;
    if (username && password) {
      userService
        .login(username, password)
        .then(user => {
          localStorage.setItem("user", JSON.stringify(user));

          if (user.authentication) {
            this.props.storeUser(user);
            this.props.history.push("/dashboard");
          } else {
            this.setState({ loginError: "true" });
          }
        })
        .catch(error => {
          if (error.response) {
            // The request was made and the server responded with a status code
            // that falls out of the range of 2xx
            // console.log(error.response.data);
            console.log(error.response.status);

            // console.log(error.response.headers);
          } else if (error.request) {
            // The request was made but no response was received
            // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
            // http.ClientRequest in node.js
            console.log("No response - service not responding");
            this.setState({
              alert: (
                <Alert color="warning">
                  Unable to authenticate - service not available
                </Alert>
              )
            });

            console.log(error.request);
          } else {
            // Something happened in setting up the request that triggered an Error
            console.log("Error", error.message);
            this.setState({
              alert: <Alert color="warning">{error.message}</Alert>
            });
          }
          this.setState({ loginError: "true" });

          console.log(error.config);
        });
    }
  }

  hideModal = () => {
    this.setState({ showForgot: false });
  };

  render() {
    return (
      <div
        className="section-full-screen"
        style={{ backgroundImage: "url(" + bgImage + ")" }}
      >
        <div className="login-page">
          <Container>
            <Col xs={12} md={8} lg={4} className="ml-auto mr-auto">
              <Form>
                <Card className="card-login card-plain">
                  <CardHeader>
                    <div className="logo-container">
                      <img src={a1Logo} alt="now-logo" />
                    </div>
                  </CardHeader>
                  <CardBody>
                    {this.state.alert}
                    {this.state.loginError === "true" ? (
                      <p style={{ color: "white" }}>
                        <Translate id="login.invalid" />
                      </p>
                    ) : null}
                    <InputGroup
                      className={
                        "no-border form-control-lg " +
                        (this.state.firstnameFocus ? "input-group-focus" : "")
                      }
                    >
                      <InputGroupAddon addonType="prepend">
                        <InputGroupText>
                          <i className="now-ui-icons users_circle-08" />
                        </InputGroupText>
                      </InputGroupAddon>
                      <Input
                        type="text"
                        size="lg"
                        name="username"
                        placeholder={"login.username"}
                        onFocus={e => this.setState({ firstnameFocus: true })}
                        onBlur={e => this.setState({ firstnameFocus: false })}
                        onChange={this.handleChange}
                      />
                    </InputGroup>
                    <InputGroup
                      className={
                        "no-border form-control-lg " +
                        (this.state.lastnameFocus ? "input-group-focus" : "")
                      }
                    >
                      <InputGroupAddon addonType="prepend">
                        <InputGroupText>
                          <i className="now-ui-icons text_caps-small" />
                        </InputGroupText>
                      </InputGroupAddon>
                      <Input
                        type="password"
                        name="password"
                        size="lg"
                        placeholder="Password..."
                        onFocus={e => this.setState({ lastnameFocus: true })}
                        onBlur={e => this.setState({ lastnameFocus: false })}
                        onChange={this.handleChange}
                      />
                    </InputGroup>
                  </CardBody>
                  <CardFooter>
                    <Button
                      block
                      round
                      color="primary"
                      size="lg"
                      href="#pablo"
                      className="mb-3"
                      onClick={this.authenticate}
                    >
                      Login
                    </Button>

                    <div className="pull-right">
                      <h6>
                        <a
                          href="#"
                          onClick={this.onForgotPass}
                          className="link footer-link"
                        >
                          <Translate id="login.forgot" />
                        </a>
                      </h6>
                    </div>
                  </CardFooter>
                </Card>
              </Form>
            </Col>
            <ForgotPass
              modalOpen={this.state.showForgot}
              handleClose={this.hideModal}
            />
          </Container>
        </div>
      </div>
    );
  }

  onForgotPass = event => {
    this.setState({ showForgot: true });
  };
}

const mapStateToProps = state => ({
  user: state.payload
  // translate: getTranslate(state.locale),
  // currentLanguage: getActiveLanguage(state.locale).code
});

export default connect(
  mapStateToProps,
  { storeUser, fetchUserInfo }
)(withLocalize(LoginPage));
