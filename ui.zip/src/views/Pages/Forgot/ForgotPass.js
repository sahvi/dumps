import React, { Component } from "react";
import {
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Modal,
  ModalBody,
  ModalHeader,
  Row
} from "reactstrap";
import { Button } from "components";

import { Translate, withLocalize } from "react-localize-redux";

class ForgotPass extends Component {
  constructor(props) {
    super(props);

    this.state = {
      modalOpen: false
    };
  }

  UNSAFE_componentWillReceiveProps(nextProps, nextContext) {
    // if (nextProps.modalOpen) {
    //   this.setState({
    //     modalOpen: nextProps.modalOpen
    //   });
    // }
  }

  requestNewPass = event => {
    this.props.handleClose();
  };

  toggleModal = () => {
    this.setState({
      modalOpen: !this.state.modalOpen
    });
  };

  render() {
    return (
      <Modal isOpen={this.props.modalOpen}>
        <ModalHeader>
          <Translate id="login.forgot" />
        </ModalHeader>
        <ModalBody>
          <Form>
            <Container>
              <Translate
                id="login.requestPass"
                options={{ renderInnerHtml: true }}
              />
              <Row className="justify-content-center">
                <Col md={12} className="mt-5">
                  <InputGroup className="input-group-focus">
                    <InputGroupAddon addonType="prepend">
                      <InputGroupText>
                        <i className="now-ui-icons users_circle-08" />
                      </InputGroupText>
                    </InputGroupAddon>
                    <Input
                      type="text"
                      placeholder="username"
                      onFocus={e => this.setState({ firstnameFocus: true })}
                      onBlur={e => this.setState({ firstnameFocus: false })}
                    />
                  </InputGroup>
                </Col>
              </Row>
              <Row className="justify-content-center">
                <Col md={5} className="mt-5">
                  <Button
                    block
                    round
                    color="primary"
                    size="lg"
                    href="#pablo"
                    className="mb-3"
                    onClick={this.requestNewPass}
                  >
                    <Translate id="submit" />
                  </Button>
                </Col>
                <Col md={5} className="mt-5">
                  <Button
                    block
                    round
                    color="primary"
                    size="lg"
                    href="#pablo"
                    className="mb-3"
                    onClick={this.props.handleClose}
                  >
                    <Translate id="cancel" />
                  </Button>
                </Col>
              </Row>
            </Container>
          </Form>
        </ModalBody>
      </Modal>
    );
  }
}

export default withLocalize(ForgotPass);
