import React from "react";
import BigCalendar from "react-big-calendar";
import withDragAndDrop from "react-big-calendar/lib/addons/dragAndDrop";
import PropTypes from "prop-types";
import { campaignService, eventService, targetService } from "../../_services";
import { Button } from "../../components";
// import CloseIcon from '@material-ui/icons/Close';
import green from "@material-ui/core/colors/green";
import amber from "@material-ui/core/colors/amber";
import IconButton from "@material-ui/core/IconButton";
import Snackbar from "@material-ui/core/Snackbar";
import SnackbarContent from "@material-ui/core/SnackbarContent";
import classNames from "classnames";
// import "assets/css/calendar.css"
import { Translate, withLocalize } from "react-localize-redux";
import Calendars from "../Calendar/Calendars";
import { Card, CardBody, Col, Row } from "reactstrap";
import moment from "moment";
import PanelHeader from "../../components/PanelHeader/PanelHeader";
import { withRouter } from "react-router-dom";
import connect from "react-redux/es/connect/connect";
import { fetchCampaign, storeCampaign } from "../../_actions/campaign.action";
import ViewCampaign from "./ViewCampaign";
import withStyles from "@material-ui/core/styles/withStyles";
import CampaignFilter from "./CampaignFilter";

BigCalendar.momentLocalizer(moment);
// import localizer from 'react-big-calendar/lib/localizers/globalize';
// import globalize from 'globalize';
// const globalizeLocalizer = localizer(globalize);
// import 'react-big-calendar-like-google/lib/addons/dragAndDrop/styles.less';
//
// import 'react-big-calendar/lib/less/styles.less'
// import EventWorkflow from "./workflow/EventWorkflow";

// import 'react-big-calendar-like-google/lib/addons/dragAndDrop/styles.less';
//
// import 'react-big-calendar/lib/less/styles.less'

// BigCalendar.setLocalizer(
//   BigCalendar.momentLocalizer(moment)
// );

const styles = theme => ({
  button: {
    marginLeft: "46%",
    backgroundColor: "#3f51b5",
    color: "white"
  },
  input: {
    display: "none"
  },
  root: {
    flexGrow: 1
  },
  grow: {
    flexGrow: 1,
    marginLeft: "5%"
  },
  menuButton: {
    marginLeft: "40%"
  },
  textField: {
    marginLeft: "40%",
    width: "20%"
  }
});
const initialCampaign = {
  name: "",
  description: "",
  calendar: {
    colour: ""
  },
  active: false,
  recurring: null,
  startDate: moment(),
  endDate: moment().add(15, "days"),
  sourceTemplate: null,
  template: false,
  instruments: [],
  deadlines: [],
  deadline: {
    name: "",
    desc: "",
    dates: []
  },
  instrument: {
    name: "",
    pages: [],
    pageOptions: [],
    targets:[]
  },

  campaignType: null,
  useTemplate: false
}
// const variantIcon = {
//   success: CheckCircleIcon,
//   warning: WarningIcon,
//   error: ErrorIcon,
//   info: InfoIcon,
// };

const messageStyles = theme => ({
  success: {
    backgroundColor: green[600]
  },
  error: {
    backgroundColor: theme.palette.error.dark
  },
  info: {
    backgroundColor: theme.palette.primary.light
  },
  warning: {
    backgroundColor: amber[700]
  },
  icon: {
    fontSize: 20
  },
  iconVariant: {
    opacity: 0.9,
    marginRight: theme.spacing.unit
  },
  message: {
    display: "flex",
    alignItems: "center"
  }
});

const DragAndDropCalendar = withDragAndDrop(BigCalendar);

function MessageContent(props) {
  const { classes, className, message, onClose, variant, ...other } = props;
  // const Icon = variantIcon[variant];

  return (
    <SnackbarContent
      className={classNames(classes[variant], className)}
      aria-describedby="client-snackbar"
      message={
        <span id="client-snackbar" className={classes.message}>
          {/*<Icon className={classNames(classes.icon, classes.iconVariant)}/>*/}
          {message}
        </span>
      }
      action={[
        <IconButton
          key="close"
          aria-label="Close"
          color="inherit"
          className={classes.close}
          onClick={onClose}
        >
          {/*// <CloseIcon className={classes.icon}/>*/}
        </IconButton>
      ]}
      {...other}
    />
  );
}

MessageContent.propTypes = {
  classes: PropTypes.object.isRequired,
  className: PropTypes.string,
  message: PropTypes.node,
  onClose: PropTypes.func,
  variant: PropTypes.oneOf(["success", "warning", "error", "info"]).isRequired
};

const MySnackbarContentWrapper = withStyles(messageStyles)(MessageContent);

class CampaignView extends React.Component {
  constructor(props) {
    super(props);
    this.routeChange = this.routeChange.bind(this);

    this.moveEvent = this.moveEvent.bind(this);
    this.resizeEvent = this.resizeEvent.bind(this);

    this.handleWizardClickOpen = this.handleWizardClickOpen.bind(this);
    this.handleModelClose = this.handleModelClose.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleMessageClose = this.handleMessageClose.bind(this);
    this.handleNewEventDrag = this.handleNewEventDrag.bind(this);
    this.updateModalState = this.updateModalState.bind(this);
    this.formatDate = this.formatDate.bind(this);
    this.viewCampaign = this.viewCampaign.bind(this);
    this.addNewCampaign = this.addNewCampaign.bind(this);
    this.state = {
      events: [],
      originalEvents: [],
      saveError: false,
      modelOpen: false,
      openCampaignSavedMessage: new URLSearchParams(
        this.props.location.search
      ).get("campaign-saved")
        ? true
        : false,
      showSaveChanges: false,
      selectedEvent: {
        id: "",
        name: "",
        startDate: new Date(),
        endDate: new Date(),
        runDate: new Date(),
        color: "#000",
        selected: false,
        eventType: "",
        eventCreationType: "",
        templateId: "",
        finalPage: false
      },
      showViewCampaign: false,
      showSelect: false
    };
  }

  addNewCampaign() {
    this.props.storeCampaign(initialCampaign);
    this.routeChange();
  }
  routeChange() {
    let path = "/campaigns/wizard";
    this.props.history.push(path);
  }

  handleMessageClose = event => {
    this.setState({ openCampaignSavedMessage: false });
  };

  componentDidMount() {
    campaignService.getCampaigns().then(campaigns => {
      console.log("Got Campaigns %o", campaigns);
      if (campaigns.length) {
        var newList = campaigns.map(function(campaign) {
          return {
            title: campaign.name,
            color: campaign.calendar.colour,
            calendarName: campaign.calendar.name,
            start: moment(campaign.startDate),
            end: moment(campaign.endDate),
            id: campaign.id,
            allday: true
          };
        });
        this.setState({ events: newList, originalEvents: newList });
      }
      console.log("State %o", this.state);
    });
  }

  eventStyleGetter(event, start, end, isSelected) {
    var style = {
      backgroundColor: event.color,
      width: "100%"
    };
    return {
      style: style
    };
  }

  moveEvent({ event, start, end, isAllDay: droppedOnAllDaySlot }) {
    const { events } = this.state;

    const idx = events.indexOf(event);
    let allDay = event.allDay;

    if (!event.allDay && droppedOnAllDaySlot) {
      allDay = true;
    } else if (event.allDay && !droppedOnAllDaySlot) {
      allDay = false;
    }

    const updatedEvent = { ...event, start, end, allDay };

    const nextEvents = [...events];
    nextEvents.splice(idx, 1, updatedEvent);

    this.setState({
      events: nextEvents,
      showSaveChanges: true
    });

    // alert(`${event.title} was dropped onto ${updatedEvent.start}`)
  }

  resizeEvent = ({ event, start, end }) => {
    const { events } = this.state;

    const nextEvents = events.map(existingEvent => {
      return existingEvent.id === event.id
        ? { ...existingEvent, start, end }
        : existingEvent;
    });

    this.setState({
      events: nextEvents,
      showSaveChanges: true
    });
  };

  handleNewEventDrag = event => {
    let campaign = initialCampaign;
    campaign.startDate = moment(event.start);
    campaign.endDate = moment(event.end);
    campaign.name = "";
    if (this.areDatesValid(campaign.startDate, campaign.endDate)) {
      this.props.storeCampaign(campaign);
      this.routeChange();
    } else {
      alert("Invalid dates! Please check and select valid dates.");
    }
  };

  areDatesValid(start, end) {
    return (
      !start.isBefore(moment(), "days") &&
      !end.isBefore(moment(), "days") &&
      !end.isBefore(start, "days")
    );
  }

  handleWizardClickOpen = () => {
    this.setState({
      wizardOpen: true,
      selectedEvent: {
        name: "",
        color: "#000"
      }
    });
    const selectedEvent = {
      name: "",
      startDate: new Date(),
      endDate: new Date(),
      runDate: new Date(),
      color: "#000",
      selected: true,
      eventType: "",
      eventCreationType: "",
      templateId: "",
      showPage: "page1",
      finalPage: false
    };
    this.setState({ wizardOpen: true, selectedEvent: selectedEvent });
  };

  handleModelClose = () => {
    this.setState({ modelOpen: false });
  };

  handleChange = name => event => {
    this.setState({
      [name]: event.target.value
    });
  };

  formatDate = date => {
    if (date) {
      let d = new Date(date),
        month = "" + (d.getMonth() + 1),
        day = "" + d.getDate(),
        year = d.getFullYear();

      if (month.length < 2) month = "0" + month;
      if (day.length < 2) day = "0" + day;

      return [year, month, day].join("-");
    } else {
      return new Date();
    }
  };

  updateModalState = newState => {
    var newList = this.state.events;
    let newEvent = {
      title: newState.newEvent.name,
      backgroundColor: newState.newEvent.color,
      start: new Date([newState.newEvent.startDate]),
      end: new Date([newState.newEvent.endDate]),
      id: newState.newEvent.id
    };

    if (newState.save) {
      var newList = this.state.events;
      let newEvent = {
        title: newState.newEvent.name,
        backgroundColor: newState.newEvent.color,
        start: new Date([newState.newEvent.startDate]),
        end: new Date([newState.newEvent.endDate]),
        id: newState.newEvent.id
      };
      newList.push(newEvent);
      this.setState({
        modelOpen: newState.modelOpen,
        openCampaignSavedMessage: newState.openMessage,
        events: newList,
        originalEvents: newList
      });
    } else {
      this.setState({
        modelOpen: newState.modelOpen,
        openCampaignSavedMessage: newState.openMessage,
        events: this.state.events
      });
    }
  };

  viewCampaign = event => {
    //fetch campaign and set to store
    campaignService.getCampaign(event.id).then(res => {
      console.log("Got clicked campaign: %o", res);
      if (res) {
        if (res.calendar && !res.calendar.label) {
          res.calendar.label = res.calendar.name;
        }
        res.instrument = res.instruments.length > 0? res.instruments[0]:null;
        this.props.storeCampaign(res);
        this.setState({
          showViewCampaign: true
        });
      }
    });
  };

  filterCampaigns = filters => {
    let campaigns = this.state.originalEvents;
    if (filters.calendar.length == 0 && filters.status.length == 0) {
      this.setState({ events: this.state.originalEvents });
    } else if (filters.status.length == 0) {
      let filteredCampaigns = campaigns.filter(campaign =>
        filters.calendar.includes(campaign.calendarName)
      );
      this.setState({ events: filteredCampaigns });
    } else if (filters.calendar.length == 0) {
      console.log("Implementation on filter by status is still pending");
      // let filteredCampaigns = campaigns.filter(campaign => filters.status.includes(campaign.status));
      // this.setState({events: filteredCampaigns});
    } else {
      console.log("Implementation on filter by status is still pending");
      let filteredCampaigns = campaigns.filter(campaign =>
        filters.calendar.includes(campaign.calendarName)
      );
      this.setState({ events: filteredCampaigns });
    }
  };

  render() {
    const { onClose, variant, ...other } = this.props;
    const localizer = BigCalendar.momentLocalizer(moment);
    //  const Icon = variantIcon[variant];
    const addButtonStyle = {
      margin: 2,
      marginBottom: 5,
      backgroundColor: "#3f51b5",
      color: "white",
      width: "15%"
    };
    const saveButtonStyle = {
      margin: 2,
      marginBottom: 5,
      backgroundColor: "#09b581",
      color: "white",
      width: "15%"
    };
    const redFont = {
      color: "red"
    };
    return (
      <div>
        <PanelHeader size="sm" />
        <div className="content">
          <Row>
            <Col xs={12} md={3}>
              <Card>
                <CardBody>
                  <Button
                    round
                    size="lg"
                    color="primary"
                    onClick={this.addNewCampaign}
                  >
                    <b className="fa fa-plus" /> Add Campaign
                  </Button>
                  {/*<Button*/}
                    {/*round*/}
                    {/*size="lg"*/}
                    {/*color="primary"*/}
                    {/*onClick={event =>*/}
                      {/*this.setState({ showSelect: !this.state.showSelect })*/}
                    {/*}*/}
                  {/*>*/}
                    {/*Toggle*/}
                  {/*</Button>*/}

                  <div>
                    {/*<Calendars />*/}
                    <CampaignFilter
                      showSelect={this.state.showSelect}
                      filterCampaigns={this.filterCampaigns}
                    />
                  </div>
                </CardBody>
              </Card>
            </Col>
            <Col xs={10} md={9}>
              <Card>
                <CardBody>
                  {this.state.showSaveChanges ? (
                    <Button
                      size="large"
                      style={saveButtonStyle}
                      primary={true}
                      onClick={this.handleModelClickOpen}
                    >
                      Save Changes
                    </Button>
                  ) : null}

                  {/*<EventWorkflow modelOpen={this.state.modelOpen} selectedEvent={this.state.selectedEvent}*/}
                  {/*updateWorkflowModalState={this.updateModalState}/>*/}

                  <DragAndDropCalendar
                    selectable
                    localizer={localizer}
                    events={this.state.events}
                    onEventDrop={this.moveEvent}
                    resizable
                    onEventResize={this.resizeEvent}
                    onSelectEvent={this.viewCampaign}
                    onSelectSlot={this.handleNewEventDrag}
                    defaultView={BigCalendar.Views.MONTH}
                    defaultDate={new Date()}
                    eventPropGetter={this.eventStyleGetter}
                  />

                  <Snackbar
                    anchorOrigin={{
                      vertical: "top",
                      horizontal: "center"
                    }}
                    open={this.state.openCampaignSavedMessage}
                    autoHideDuration={5000}
                    onClose={this.handleMessageClose}
                  >
                    <MySnackbarContentWrapper
                      onClose={this.handleMessageClose}
                      variant="success"
                      message="Campaign saved successfully"
                    />
                  </Snackbar>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
        {this.state.alert}
        <ViewCampaign
          isOpen={this.state.showViewCampaign}
          onModify={e => {
            this.setState({ showViewCampaign: false });
            this.props.history.push("/campaigns/wizard");
          }}
          onClose={e => this.setState({ showViewCampaign: false })}
        />
      </div>
    );
  }
}

CampaignView.propTypes = {
  classes: PropTypes.object.isRequired,
  onClose: PropTypes.func,
  variant: PropTypes.oneOf(["success", "warning", "error", "info"]).isRequired
};

const mapStateToProps = state => ({
  campaign: state.campaignWizard.campaign
});

// export default withRouter(withLocalize(connect(mapStateToProps)(CampaignView)));
export default connect(
  mapStateToProps,
  { storeCampaign, fetchCampaign }
)(withRouter(withLocalize(CampaignView)));
