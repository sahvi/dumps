import React from "react";
import connect from "react-redux/es/connect/connect";
import { fetchCampaign, storeCampaign } from "../../_actions/campaign.action";
import { Translate, withLocalize } from "react-localize-redux";
import Button from "../../components/CustomButton/CustomButton";
import PropTypes from "prop-types";
import SweetAlert from "react-bootstrap-sweetalert";

import {
  Card,
  CardBody,
  CardTitle,
  CardHeader,
  Collapse,
  Col,
  Row,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader
} from "reactstrap";

import "antd/dist/antd.css";
import TargetsModal from "./Wizard/design/TargetsTree";

class ViewCampaign extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      expandedItems: ["Details"],
      alert: null
    };
  }

  componentDidMount() {
    this.props.fetchCampaign();
  }

  componentWillReceiveProps(newProps) {
    this.props.fetchCampaign();
  }

  showTargets(instrument) {
    let campaign = this.props.campaign;
    campaign.instrument = instrument;
    this.props.storeCampaign(campaign);

    this.setState({
      alert: (
        <SweetAlert
          style={{ display: "block"}}
          title="Targets"
          onConfirm={() => this.hideAlert()}
          confirmBtnBsStyle="info"
          confirmBtnText="Cancel"
        >

          <TargetsModal
            view={true}
            instrument={instrument.instrumentType}
          />

        </SweetAlert>
      )
    });
  }

  hideAlert() {
    this.setState({
      alert: null
    });
  }

  openCollapse(item) {
    let expandedItems = this.state.expandedItems;
    if (expandedItems.includes(item)) {
      expandedItems = expandedItems.filter(e => e !== item);
    } else {
      expandedItems.push(item);
    }
    this.setState({expandedItems: expandedItems});
  }
  render() {
    let InstrumentPages = (props) => {
      let pages = [];
      props.instrument.pages.map(page => {
        pages.push(
          <Row>
            <Col sm={4}>Page:</Col>
            <Col sm={8}>{page.pageType.name}</Col>
          </Row>
        )
      });

      return(
        <div>
          {pages}
        </div>
      )
    };

    let Instruments = () => {
      let instruments = [];
      this.props.campaign.instruments.map(instrument => {
        instruments.push(
          <Row>
            <Card>
              <CardBody>
                <Row>
                  <Col sm={3}>Name:</Col>
                  <Col sm={5}>{instrument.instrumentType.name}</Col>
                  <Col sm={4}>
                    <a
                      onClick={() => this.showTargets(instrument)}
                      style={{color: "blue"}}
                    >
                      View Targets
                    </a>
                  </Col>
                </Row>
                <InstrumentPages instrument={instrument}/>

              </CardBody>
            </Card>
          </Row>
        )
      });

      return(
        <div>
          {instruments}
        </div>
      )
    };

    let Deadlines = () => {
      let deadlines = [];
      this.props.campaign.deadlines.map(deadline => {
        deadlines.push(
          <Row>
            <Card>
              <CardBody>
                <Row>
                  <Col sm={4}>Name:</Col>
                  <Col sm={8}>{deadline.type.name}</Col>
                </Row>
                <Row>
                  <Col sm={4}>Due date:</Col>
                  <Col sm={8}>{deadline.deadlineLineDue}</Col>
                </Row>
                <Row>
                  <Col sm={4}>Type:</Col>
                  <Col sm={8}>{deadline.type.type}</Col>
                </Row>
              </CardBody>
            </Card>
          </Row>
        )
      });

      return(
        <div>
          {deadlines}
        </div>
      )
    };


    return (
      <Modal isOpen={this.props.isOpen}>
        <ModalHeader className="justify-content-center" tag="div">
          Name: {this.props.campaign ? this.props.campaign.name : "None selected"}
        </ModalHeader>
        <ModalBody>
          <Card>
            <CardHeader>
              <Row>
                <Col sm={10} >
                  <h6>Details</h6>
                </Col>
                <Col sm={2} >
                  <a
                    onClick={() => this.openCollapse("Details")}
                  >
                    <i
                      className={this.state.expandedItems.includes("Details") ? "fa fa-angle-double-up" : "fa fa-angle-double-down"}
                    />
                  </a>
                </Col>
              </Row>
            </CardHeader>
            <Collapse isOpen={this.state.expandedItems.includes("Details")}>
              <CardBody>
                {this.state.alert}
                <Row>
                  <Col sm={4}>Name:</Col>
                  <Col sm={8}>{this.props.campaign.name}</Col>
                </Row>
                <Row>
                  <Col sm={4}>Is Active?</Col>
                  <Col sm={8}>{this.props.campaign.active ? "Yes" : "No"}</Col>
                </Row>
                <Row>
                  <Col sm={4}>Start Date:</Col>
                  <Col sm={8}>{this.props.campaign.startDate}</Col>
                </Row>
                <Row>
                  <Col sm={4}>End Date:</Col>
                  <Col sm={8}>{this.props.campaign.endDate}</Col>
                </Row>
                <Row>
                  <Col sm={4}>Calendar:</Col>
                  <Col sm={8}>{this.props.campaign.calendar.name}</Col>
                </Row>
                <Row>
                  <Col sm={4}>Source Template:</Col>
                  <Col sm={8}>
                    {this.props.campaign.sourceTemplate
                      ? this.props.campaign.sourceTemplate
                      : "Not Applicable"}
                  </Col>
                </Row>
              </CardBody>
            </Collapse>
          </Card>
          <Card>
            <CardHeader>
              <Row>
                <Col sm={10} >
                  <h6>Instruments</h6>
                </Col>
                <Col sm={2} >
                  <a
                    onClick={() => this.openCollapse("Instruments")}
                  >
                    <i
                      className={this.state.expandedItems.includes("Instruments") ? "fa fa-angle-double-up" : "fa fa-angle-double-down"}
                    />
                  </a>
                </Col>
              </Row>
            </CardHeader>
            <Collapse isOpen={this.state.expandedItems.includes("Instruments")}>
              <CardBody>
                {
                  <Instruments/>
                }

              </CardBody>
            </Collapse>

          </Card>

          <Card>
            <CardHeader>
              <Row>
                <Col sm={10} >
                  <h6>Deadlines</h6>
                </Col>
                <Col sm={2} >
                  <a
                    onClick={() => this.openCollapse("Deadlines")}
                  >
                    <i
                      className={this.state.expandedItems.includes("Deadlines") ? "fa fa-angle-double-up" : "fa fa-angle-double-down"}
                    />
                  </a>
                </Col>
              </Row>
            </CardHeader>
            <Collapse isOpen={this.state.expandedItems.includes("Deadlines")}>
              <CardBody>
                {
                  <Deadlines/>
                }

              </CardBody>
            </Collapse>

          </Card>

        </ModalBody>

        <ModalFooter>
          <Button onClick={this.props.onClose} color="primary">
            <Translate id="cancel" />
          </Button>
          <Button onClick={this.props.onModify} color="primary" autoFocus>
            <Translate id="modify" />
          </Button>
        </ModalFooter>
      </Modal>
    );
  }
}

const mapStateToProps = state => ({
  campaign: state.campaignWizard.campaign
});
export default connect(
  mapStateToProps,
  { storeCampaign, fetchCampaign },
  null,
  { withRef: true }
)(withLocalize(ViewCampaign));
