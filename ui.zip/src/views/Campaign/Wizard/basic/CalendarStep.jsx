import React from "react";
import { CardBody, Col, FormGroup, Input, Row, Label } from "reactstrap";

import { PictureUpload } from "components";
import { getActiveLanguage, Translate } from "react-localize-redux";
import { calendarService } from "../../../../_services/index";
import Select from "react-select";
import Datetime from "react-datetime";
import { fetchCampaign, storeCampaign } from "../../../../_actions/campaign.action";
import { connect } from "react-redux";
import Switch from "react-switch";
import moment from "moment";

class CalendarStep extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
          calendars: [],
          campaignTemplates: [],
          campaignTemplateFlag: false,
          campaign: props.campaign,
          register: {
            emailState: "",
            passwordState: "",
            confirmState: "",
            fullNameState: "",
            email: "",
            password: "",
            confirm: "",
            fullName: ""
          },
        };

        console.log("Wizard state %o", this.state);
        this.handleChange = this.handleChange.bind(this);
        this.useTemplateToggle = this.useTemplateToggle.bind(this);
        this.onTemplateSelection = this.onTemplateSelection.bind(this);
    }

    renderCalIcon() {
        return (this.props.campaign && this.props.campaign.calendar) ?
            <span style={{color:this.props.campaign.calendar.colour}}><i className={this.props.campaign.calendar.icon}></i></span> :
        <i>Select Cal</i>;
    }

    componentWillReceiveProps(nextProps, nextContext) {
        console.log("New props %o", nextProps);
        if(nextProps.campaign) {
          this.setState({campaign: nextProps.campaign})
        }

    }

    componentDidMount() {
        calendarService.getCalendars().then(d => {
            console.log("Got calendars %o", d);
            if (d.length) {
                d.map((c) => {
                    c.label = c.name;
                    c.checked = true;
                });
            }
            this.setState({
                calendars: d,
                //isLoading: false
            });
            //console.log("State %o", this.state);
        });

        // Get Campaign Templates

      calendarService.getCampaignTemplates().then(d => {
        console.log("Got Campaign Templates %o", d);
        if (d.length) {
          d.map((c) => {
            c.label = c.name;
            c.checked = true;
          });
        }
        this.setState({
          campaignTemplates: d,
          isLoading: false
        });
        console.log("State %o", this.state);
      });


    }

    handleChange(name, value) {
      let campaign = this.props.campaign;
        campaign[name] = value;
        this.setState({campaign: campaign});
        this.props.storeCampaign(campaign);
        console.log("Changed %o", campaign);
    };


  assignTemplate(name, value) {

    let campaign = this.props.campaign;
    campaign[name] = value;
    console.log(value);
    campaign.instruments = value.instruments;

    // Assign the Template values to Campaign

    //campaign = value;

    this.props.storeCampaign(campaign);
    console.log(value);
  };
  useTemplateToggle(checked, proto,id) {
      let campaign = this.props.campaign;
      campaign.useTemplate = checked;
      this.setState({campaignTemplateFlag: checked});
  }

  onTemplateSelection(value) {
      //FIXME: this is initial implementation to check how it works. Needs proper implementation\
    let selectedTemplateIdx = this.findIndex(this.state.campaignTemplates, "value", value.value);
    if (selectedTemplateIdx > -1) {
      let campaign = this.props.campaign;
      campaign.instruments = this.state.campaignTemplates[selectedTemplateIdx].instruments;
      //this.setState({campaign: campaign});
      this.props.storeCampaign(campaign);
    }
  }

  findIndex(array, property, value) {
    for(var i = 0; i < array.length; i += 1) {
      if(array[i][property] === value) {
        return i;
      }
    }
    return -1;
  }


  isValid() {
    if(this.isNameValid() & this.isCalendarValid() & this.isStartDateValid() & this.isEndDateValid()) {
      return true;
    } else {
      return false;
    }
  }

  isNameValid() {
    if (
      this.props.campaign.name == undefined ||
      this.props.campaign.name == ''
    ) {
      this.setState({
        nameState: " has-danger",
      });
      return false;
    }
    return true;
  }

  isCalendarValid() {
    if (
      this.props.campaign.calendar == undefined ||
      this.props.campaign.calendar == '' ||
      this.props.campaign.calendar.id == undefined ||
      this.props.campaign.calendar.id == ''
    ) {
      this.setState({
        calendarState: " has-danger",
      });
      return false;
    }
    return true;
  }

  isStartDateValid() {
    if (
      this.props.campaign.startDate == undefined ||
      this.props.campaign.startDate == '' ||
      ( moment(this.props.campaign.startDate).isBefore(moment(), 'days') )
    ) {
      this.setState({
        startDateState: " has-danger",
      });
      return false;
    }
    return true;
  }

  isEndDateValid() {
    if (
      this.props.campaign.endDate == undefined ||
      this.props.campaign.endDate == '' ||
      ( moment(this.props.campaign.endDate).isBefore(moment(), 'days') )
      ||
      ( moment(this.props.campaign.endDate).isBefore(moment(this.props.campaign.startDate), 'days') )
  ) {
      this.setState({
        endDateState: " has-danger",
      });
      return false;
    }
    return true;
  }

  saveAndFinishLater() {
    alert('Saving the step!')
  }

  render() {
      return (
          <div>

              <Row>
                  <Col xs={12} sm={12} md={4}>
                      <Row className="justify-content-center">
                          <div className="icon-circle">

                          {this.renderCalIcon()}
                          </div>
                      </Row>
                  </Col>
                  <Col xs={12} sm={10} md={6}>
                    <CardBody>
                      <FormGroup className={
                        "has-label " +
                        (this.state.nameState ? this.state.nameState : "") +
                        (this.state.nameFocus ? " input-group-focus" : "")
                      }>

                        <Label>Name *</Label>
                        <Input
                          type="text"
                          onFocus={e => this.setState({ nameFocus: true })}
                          onBlur={e => {
                            if (this.state.nameState == " has-danger") {
                              this.setState({ nameState: " has-success", nameFocus: false })
                            } else {
                              this.setState({ nameFocus: false })
                            }
                          }
                          }
                          value={this.state.campaign.name}
                          onChange={e => this.handleChange("name", e.target.value)}
                        />

                      </FormGroup>

                      <FormGroup className={
                        "has-label " +
                        (this.state.calendarState ? this.state.calendarState : "") +
                        (this.state.calendarFocus ? " input-group-focus" : "")
                      }>
                        <Label>Calendar *</Label>
                        <Select
                          className="primary react-select"
                          classNamePrefix="react-select"
                          placeholder="Select"
                          name="calendar"
                          onChange={option => this.handleChange("calendar", option)}
                          onBlur={e => {
                            if (this.state.calendarState == " has-danger") {
                              this.setState({ calendarState: " has-success", calendarFocus: false })
                            } else {
                              this.setState({ calendarFocus: false })
                            }
                          }
                          }
                          onFocus={e => this.setState({ calendarFocus: true })}
                          options={this.state.calendars}
                          value={this.state.campaign.calendar.label?this.state.campaign.calendar:""}
                        />
                      </FormGroup>
                      <FormGroup
                        className={
                          "has-label " +
                          (this.state.startDateState ? this.state.startDateState : "") +
                          (this.state.startDateFocus ? " input-group-focus" : "")
                        }
                      >
                        <Label>Start Date *</Label>
                        <Datetime
                          value={this.props.campaign.startDate}
                          timeFormat={false}
                          dateFormat="YYYY-MM-DD"
                          onChange={value => this.handleChange("startDate", value)}
                          inputProps={{ placeholder: "Start date of campaign" }}
                          onFocus={e => this.setState({ startDateFocus: true })}
                          onBlur={e => {
                            if (this.state.startDateState == " has-danger") {
                              this.setState({ startDateState: " has-success", startDateFocus: false })
                            } else {
                              this.setState({ startDateFocus: false })
                            }
                          }
                          }
                        />
                      </FormGroup>
                      <FormGroup
                        className={
                          "has-label " + (this.state.endDateState ? this.state.endDateState : "") +
                          (this.state.endDateFocus ? " input-group-focus" : "")
                        }
                      >
                        <Label>End Date *</Label>
                        <Datetime
                          value={this.props.campaign.endDate}
                          timeFormat={false}
                          dateFormat="YYYY-MM-DD"
                          onChange={value => this.handleChange("endDate", value)}
                          inputProps={{ placeholder: "End date of campaign" }}
                          onFocus={e => this.setState({ endDateFocus: true })}
                          onBlur={e => {
                            if (this.state.endDateState == " has-danger") {
                              this.setState({ endDateState: " has-success", endDateFocus: false })
                            } else {
                              this.setState({ endDateFocus: false })
                            }
                          }
                          }
                        />
                      </FormGroup>
                      <FormGroup>
                        <div style={{width: '90%', display : 'inline-flex'}}>
                          <label style={{width: '90%', display : 'inline-flex',  alignItems: 'center'}}>

                            <Switch
                              onChange={this.useTemplateToggle}
                              checked={this.state.campaignTemplateFlag}
                              handleDiameter={30}
                              id="1"
                              boxShadow="0px 1px 5px rgba(0,0,0,0.6)"
                              uncheckedIcon={false}
                              onColor="#2E8B57"/>
                            <span style={{paddingLeft: '10px'}}>Use Template?</span>
                          </label>
                        </div>

                      </FormGroup>
                      <FormGroup>
                        {
                          this.props.campaign.useTemplate ?
                            <div>
                              <Label>Template *</Label>
                              <Select
                                className="primary react-select"
                                classNamePrefix="react-select"
                                placeholder={<Translate id="select"/>}
                                name="calendar"
                                onChange={option => this.onTemplateSelection(option)}
                                options={this.state.campaignTemplates}

                              />
                            </div>

                            :
                            null
                        }

                      </FormGroup>


                      <div className="category form-category">
                        * Required fields
                      </div>
                    </CardBody>

                  </Col>
              </Row>


          </div>
      );
  }
}

const mapStateToProps = state => ({
  campaign: state.campaignWizard.campaign
});

export default connect(mapStateToProps, { storeCampaign, fetchCampaign, getActiveLanguage }, null, {withRef: true})(CalendarStep);
