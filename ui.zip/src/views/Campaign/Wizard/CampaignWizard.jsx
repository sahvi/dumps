import React, { Component } from "react";
import { Row, Col } from "reactstrap";
// react plugin used to create a form with multiple steps

import { PanelHeader } from "components";

import CalendarStep from "./basic/CalendarStep.jsx";
import DesignStep from "./design/DesignStep.jsx";

import englishTranslations from "../../../i18n/en/campaignWizard.json";
import frenchTranslations from "../../../i18n/fr/campaignWizard.json";
import { Translate, withLocalize } from "react-localize-redux";
import DeadlineStep from "./deadline/DeadlineStep";
import connect from "react-redux/es/connect/connect";
import { fetchCampaign, storeCampaign } from "../../../_actions/campaign.action";

import { campaignService } from "../../../_services";

import AvenueOneWizard from "../../../components/AvenueOne/Wizard/AvenueOneWizard";
import SweetAlert from "react-bootstrap-sweetalert";
import Button from "../../../components/CustomButton/CustomButton";

var steps = [

    {
      stepName: "Calendar",
      stepIcon: "now-ui-icons users_circle-08",
      component: CalendarStep
    },
    {
        stepName: "Instruments",
        stepIcon: "now-ui-icons ui-1_settings-gear-63",
        component: DesignStep
    },
    // {
    //     stepName: "Options",
    //     stepIcon: "now-ui-icons ui-1_email-85",
    //     component: Options
    // },
  {
    stepName: "Deadlines",
    stepIcon: "a1-ui-icons deadline",
    component: DeadlineStep
  }
];

class CampaignWizard extends Component {

    constructor(props) {
        super(props);


        this.state = {
            events: [],
            alert: null,
            selectedEvent: this.props.selectedEvent,
            wizardOpen: false,
        };

        this.props.addTranslationForLanguage(frenchTranslations, "fr");
        this.props.addTranslationForLanguage(englishTranslations, "en");

        this.handleModelClose = this.handleModelClose.bind(this);
        this.saveCampaign = this.saveCampaign.bind(this);
    }

    componentWillReceiveProps(newProps) {
        let selectedEvent = newProps.selectedEvent;
        this.setState({
            saveError: false,
            wizardOpen: newProps.wizardOpen,
            selectedEvent: selectedEvent
        });
    };
    handleModelClose = () => {
        this.setState({ wizardOpen: false });
    };

    hideAlert() {
        this.setState({
            alert: null
        });
    }

  validateStep = (stepName) => {
      let campaign = this.props.campaign;
      if(!campaign) {
        return false;
      } else {
        if(stepName === "Details") {
          return campaign.name && campaign.startDate && campaign.endDate;
        }
        if(stepName === "Instruments") {
          return campaign.instruments && campaign.instruments.length > 0 ;
        }
        if(stepName === "Deadlines") {
          return campaign.deadlines && campaign.deadlines.length > 0;
        }
      }
      return false;

  };

  finish = (params) => {
    let ValidationStatus = (props) => {
      let status = null;
      if(this.validateStep(props.step)) {
        status = <Button
          color="success"
          size="sm"
          round
          icon
        >
          <i className="fa fa-check" />
        </Button>
      } else {
        status = <Button
          color="danger"
          size="sm"
          round
          icon
        >
          <i className="fa fa-exclamation" />
        </Button>
      }
      return (
        <Col sm={2}  style={{marginTop: "-2%"}}>
          {status}
        </Col>
      )
    };
    this.setState({
      alert: (
        <SweetAlert
          style={{ display: "block", marginTop: "-100px" }}
          title=""
          onConfirm={() => this.hideAlert()}
          onCancel={() => this.saveCampaign()}
          confirmBtnBsStyle="info"
          confirmBtnText="Cancel"
          cancelBtnBsStyle="primary"
          cancelBtnText="Submit"
          showCancel={this.validateStep("Details") && this.validateStep("Instruments") && this.validateStep("Deadlines")}
        >
          <Row>
            <Col sm={6}>
              <h7>Basic details</h7>
            </Col>
            <Col sm={2} style={{marginTop: "-2%"}}>
              <ValidationStatus step={"Details"}/>
            </Col>
          </Row>

          <Row>
            <Col sm={6}>
              <h7>Instruments</h7>
            </Col>
            <Col sm={2}  style={{marginTop: "-2%"}}>
              <ValidationStatus step={"Instruments"}/>
            </Col>
          </Row>

          <Row>
            <Col sm={6}>
              <h7>Deadlines</h7>
            </Col>
            <Col sm={2}  style={{marginTop: "-2%"}}>
              <ValidationStatus step={"Deadlines"}/>
            </Col>
          </Row>
          {
            this.validateStep("Details") && this.validateStep("Instruments") && this.validateStep("Deadlines")
            ?
              null
            :
              <h7 style={{color: "red"}}> Please provide all required information before submitting...</h7>
          }



        </SweetAlert>
      )
    });
  }

    saveCampaign = () => {
      campaignService.saveCampaign(this.props.campaign).then( res => {
        this.props.history.push("/campaigns?campaign-saved=true");
        this.hideAlert();
      });
    };

    render() {
        return (

            <div>
                <PanelHeader size="sm" />
                <div className="content">

                        <Col xs={12} md={10} className="mr-auto ml-auto">

                            <AvenueOneWizard steps={steps}
                                 navSteps
                                 validate
                                 title={<Translate id="title"/>}
                                 description={<Translate id="description"/>}
                                 headerTextCenter
                                 color="blue"
                                 finishButtonClasses="btn-success"
                                 nextButtonClasses="btn-wd"
                                 cancelButtonClasses="btn-wd"
                                 previousButtonClasses="btn-wd"
                                 finishButtonClick={this.finish}
                                 nextButtonText="Next"
                            />
                        </Col>
                    </div>
                {this.state.alert}
            </div>
        );
    }
}

const mapStateToProps = state => ({
  campaign: state.campaignWizard.campaign,
});

export default connect(mapStateToProps, { storeCampaign, fetchCampaign }, null, {withRef: true})(withLocalize(CampaignWizard));

