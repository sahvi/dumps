import React from "react";
import connect from "react-redux/es/connect/connect";
import {
  fetchCampaign,
  storeCampaign
} from "../../../../_actions/campaign.action";
import { Translate, withLocalize } from "react-localize-redux";
// import { Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
// import Button from "../../../../components/CustomButton/CustomButton";

import { Tree } from "antd";
import "antd/dist/antd.css";
import { targetService } from "../../../../_services";
import Search from "antd/es/input/Search";

// import targets from '../DemoData/targets';

const { TreeNode } = Tree;

// let targets = [];
let flatListOfTargets = [];


class TargetsTree extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      targetsWindowOpen: false,
      expandedKeys: [],
      autoExpandParent: true,
      checkedKeys: [],
      selectedKeys: [],
      filteredTargets: [],
      view:props.view
    };
  }

  componentDidMount() {
    this.props.fetchCampaign();
    if(this.props.instrument) {
      this.getTargets(this.props.instrument.name);
    }
  }

  transformToTreeObject(target) {
    flatListOfTargets.push({ title: target.name, key: target.id });
    return {
      title: target.name,
      value: target.id,
      key: target.id,
      children: target.children.map(child => this.transformToTreeObject(child))
    };
  }

  componentWillReceiveProps(newProps) {
    if(newProps.campaign.instrument != undefined) {
      this.getTargets(newProps.instrument.name, newProps.expandedKeys, newProps.checkedKeys);
    }
  }

  getTargets = (instrumentName, expandedKeys, checkedKeys) => {
    let targets = [];
    targetService.getStoreGroupsByInstruments(instrumentName.toUpperCase()).then(res => {
      console.log("Loading available store groups..%o", res);
      if (res) {
        if (res.length) {
          res.map(target => {
            targets.push(this.transformToTreeObject(target));
          });
        }
        console.log("Got stores groups in Target Modal... %o", targets);
        console.log("checkedKeys", this.props.campaign.instrument?this.props.campaign.instrument.targets:"undefinded...");
        this.setState({filteredTargets: targets, expandedKeys: expandedKeys?expandedKeys:[], checkedKeys: this.props.campaign.instrument?this.props.campaign.instrument.targets:[]});
      }
    });
  };

  saveTargetsSelection = () => {
    this.props.onSave(this.getCheckedKeyIds());
  };

  getCheckedKeyIds() {
    return flatListOfTargets
      .filter(target =>
        this.state.checkedKeys.some(item => item === target.key)
      )
      .map(target => target.key);
  }

  onChange = e => {
    const value = e.target.value;
    let expandedKeys = [];
    flatListOfTargets.map(item => {
      if (item.title.indexOf(value) > -1) {
        let parentKey = this.getParentKey(item.key, this.state.filteredTargets);
        expandedKeys.push(parentKey);
      }
    });
    this.setState({ expandedKeys: expandedKeys });
  };

  getParentKey = (key, tree) => {
    let parentKey;
    for (let i = 0; i < tree.length; i++) {
      const node = tree[i];
      if (node.children) {
        if (node.children.some(item => item.key === key)) {
          parentKey = node.key;
        } else if (this.getParentKey(key, node.children)) {
          parentKey = this.getParentKey(key, node.children);
        }
      }
    }
    return parentKey;
  };

  onExpand = expandedKeys => {
    console.log("onExpand", expandedKeys);
    this.setState({
      expandedKeys,
      autoExpandParent: false
    });
  };

  onCheck = (checkedKeys, info) => {
    console.log("onCheck", info);

    this.setState({ checkedKeys });
    console.log("checkedKeys", checkedKeys);
;    this.props.onSave(checkedKeys);
  };

  // onSelect = (selectedKeys, info) => {
  //   console.log('onSelect', info);
  //   this.setState({ selectedKeys });
  // };

  renderTreeNodes = data => data.map(item => {
      if (item && item.children) {
        // console.log("item {} ", JSON.stringify(item))
        return (
          <TreeNode title={item.title} key={item.key} dataRef={item}>
            {this.renderTreeNodes(item.children)}
          </TreeNode>
        );
      }
      return <TreeNode {...item} />;
    });

  render() {
    return (

        <div>
          {
            !this.state.view ?
              <Search
                style={{ marginBottom: 8 }}
                placeholder="Search"
                onChange={this.onChange}
              />
            :
            null
          }

          <div style={{height: "350px", overflowY: "scroll"}}>
            <Tree
              disabled={this.state.view}
              checkable
              onExpand={this.onExpand}
              expandedKeys={this.state.expandedKeys}
              autoExpandParent={this.state.autoExpandParent}
              onCheck={this.onCheck}
              checkedKeys={this.state.checkedKeys}
              // onSelect={this.onSelect}
              selectedKeys={this.state.selectedKeys}
            >
              {this.renderTreeNodes(this.state.filteredTargets)}
            </Tree>
          </div>
        </div>
    );
  }
}

const mapStateToProps = state => ({
  campaign: state.campaignWizard.campaign
});
export default connect(
  mapStateToProps,
  { storeCampaign, fetchCampaign },
  null,
  { withRef: true }
)(withLocalize(TargetsTree));
