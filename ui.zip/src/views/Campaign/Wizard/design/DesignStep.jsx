import React from "react";
import {
  Card,
  CardBody,
  CardTitle,
  CardHeader,
  Col,
  FormGroup,
  Nav,
  NavItem,
  NavLink,
  Row,
  TabContent,
  TabPane,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem
} from "reactstrap";
// react plugin used to create DropdownMenu for selecting items
import Select from "react-select";
import connect from "react-redux/es/connect/connect";
import {
  fetchCampaign,
  storeCampaign
} from "../../../../_actions/campaign.action";
import { Translate, withLocalize } from "react-localize-redux";

import Button from "../../../../components/CustomButton/CustomButton";
import { calendarService, instrumentService } from "../../../../_services/index";

import pageImg from "assets/img/pages/page1.png";
import TargetsModal from "./TargetsTree";
import Search from "antd/es/input/Search";
import { Tree } from "antd";
import uuidv5 from "uuid/v5";
import { Input } from "reactstrap";
import DropDownButton from "../../../../components/AvenueOne/DropDownButton";
import SweetAlert from "react-bootstrap-sweetalert";

let templates = [];

class DesignStep extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      calendars: [],
      //campaign: this.props.campaign ? this.props.campaign : defaultCampaign,
      vTabs: "0",
      hTabs: "0",
      selectedTab: "",
      instrument: {
        // this will hold => name: name & array of pageNo: templateId
        name: "",
        pages: [],
        pageOptions: [],
        targets: []
      },
      selectedInstTypes:[],
      instrumentTypes: [],
      targetsWindowOpen: false,
      expandedKeys: ["0-0-0", "0-0-1"],
      autoExpandParent: true,
      checkedKeys: ["0-0-0"],
      selectedKeys: [],
      alert:null
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleInstrumentChange = this.handleInstrumentChange.bind(this);
    this.deleteInstrument = this.deleteInstrument.bind(this);
    this.saveTargetsSelection = this.saveTargetsSelection.bind(this);
    calendarService.getPageTypes().then(pages => {
      let pagesList = [];
      if (pages.length) {
        pages.map(page => {
          pagesList.push({
            label: page.name,
            value: page.type,
            id:page.id
          });
        });
      }
      templates = pagesList;
    });
  }

  componentWillMount() {
    this.props.fetchCampaign();
  }

  componentWillReceiveProps(newProps) {
    if (newProps.campaign) {
      let selectedType = newProps.campaign.instrument && newProps.campaign.instrument.instrumentType?this.findIndex(this.state.instrumentTypes,'label', newProps.campaign.instrument.instrumentType.name):-1;
      let instrumentTypes = this.state.instrumentTypes;
      if(selectedType != -1) {
        instrumentTypes.splice(selectedType, 1);
      }
      this.setState({
        //campaign: newProps.campaign,
        selectedTab:
          newProps.campaign.instruments.length > 0
            ? newProps.campaign.instruments[0].name
            : "",
        instrument:
          newProps.campaign.instruments.length > 0
            ? newProps.campaign.instruments[0]
            : {
                name: "",
                pages: [],
                pageOptions: [],
                targets: []
              },
        instrumentTypes: instrumentTypes
      });
    } else {
      this.props.fetchCampaign();
    }
  }

  handleInstrumentChange(option) {
    let instruments = this.props.campaign.instruments;
    let instrumentType = { name: option.label, id: option.value };
    let instrumentTypes = this.state.instrumentTypes;
    let selectedInstTypes = this.state.selectedInstTypes;
    let selectedType = this.findIndex(instrumentTypes,'label', option.label);
    let instrument = {
      instrumentType: instrumentType,
      pages: [],
      pageOptions: []
    };
    instruments.push(instrument);
    selectedInstTypes = selectedInstTypes.concat(instrumentTypes.splice(selectedType, 1));
    this.setState({
      instruments: instruments,
      instrumentTypes: instrumentTypes,
      selectedInstTypes: selectedInstTypes
    });

    this.instrumentSelected(instrument, instruments.length - 1 );
  }

  deleteInstrument(option) {
    let instruments = this.props.campaign.instruments;
    let instrumentType = { name: option.label, id: option.value };
    let instrumentTypes = this.state.instrumentTypes;
    let selectedInstTypes = this.state.selectedInstTypes;
    let selectedType = this.findIndex(selectedInstTypes,'label', option.label);
    let selectedInstType = this.findIndexByInstrumentType(instruments, instrumentType.name);
    selectedInstTypes.splice(selectedType, 1);
    instrumentTypes.push(option);
    instruments.splice(selectedInstType, 1);
    this.setState({
      instruments: instruments,
      instrumentTypes: instrumentTypes,
      selectedInstTypes: selectedInstTypes,
      hTabs: instruments.length > 0 ? "".concat(instruments.length - 1 ):"", //FIXME: this is to fix an type cast error..
      selectedTab: instruments.length > 0 ? this.props.campaign.instruments[instruments.length - 1 ].name:"",
      instrument: instruments.length > 0 ? instruments[instruments.length - 1]:null
    });
    let campaign = this.props.campaign;
    campaign.instruments = instruments;
    campaign.instrument = instruments.length>0?instruments[0]:null;
    this.props.storeCampaign(campaign);
  }

  handleChange(name, value) {
    let campaign = this.props.campaign;
    campaign[name] = value;
    // this.setState({
    //     campaign: campaign
    // });
    this.props.storeCampaign(campaign);
  }

  onClose(event) {}

  componentDidMount() {
    instrumentService.getInstrumentTypes().then(instruments => {
      let instrumentsList = [];
      if (instruments.length) {
        instruments.map(inst => {
          instrumentsList.push({
            label: inst.name,
            value: inst.id
          });
        });
      }
      this.setState({
        instrumentTypes: instrumentsList
      });

    });
  }

  onPageTemplateSelection(pageNo, template) {
    //set the page template id and select option to state
    let campaign = this.props.campaign;
    let instrument = this.state.instrument;
    if (!instrument.pages) {
      instrument.pages = [];
      instrument.pageOptions = [];
    }
    instrument.pages[pageNo] = {};
    instrument.pages[pageNo].name = "Page "+pageNo;
    instrument.pages[pageNo].pageType = {};
    instrument.pages[pageNo].pageType.id = template.id; //"Page_"+pageNo+"_"+template.value; //uuidv5("Page_"+pageNo+"_"+template.value, "avenueone");
    instrument.pages[pageNo].pageType.type = template.value;
    instrument.pages[pageNo].pageType.name = template.label;
    instrument.pages[pageNo].label = template.label;
    instrument.pages[pageNo].value = template.value;
    instrument.pageOptions[pageNo] = template;

    let selectedTabIdx = campaign.instruments.indexOf({
      name: this.state.selectedTab
    });
    if (selectedTabIdx > -1) {
      campaign.instruments[selectedTabIdx].pages = instrument.pages;
    }
    this.setState({
      // campaign: campaign,
      instrument: instrument
    });
    this.props.storeCampaign(campaign);
  }

  addPage() {
    let instrument = this.state.instrument;
    if (!instrument.pages) {
      instrument.pages = [];
      instrument.pageOptions = [];
    }
    instrument.pages[instrument.pages.length] = {};

    this.setState({
      instrument: instrument
    });

  }

  getPageTypeOption(index) {
    let pageAsTypeOption = this.state.instrument.pages[index]?this.state.instrument.pages[index]:null;
    if(pageAsTypeOption){
      pageAsTypeOption.label = pageAsTypeOption.pageType?pageAsTypeOption.pageType.name:"";
      pageAsTypeOption.value = pageAsTypeOption.pageType?pageAsTypeOption.pageType.type:"";
    }
    return pageAsTypeOption;
  }

  deletePage(index) {
    let instrument = this.state.instrument;
    instrument.pages.splice(index, 1);
    // instrument.pageOptions.splice(index, 1);

    let campaign = this.props.campaign;
    let selectedTabIdx = campaign.instruments.indexOf({
      name: this.state.selectedTab
    });
    if (selectedTabIdx > -1) {
      campaign.instruments[selectedTabIdx].pages = instrument.pages;
    }
    this.setState({
      campaign: campaign,
      instrument: instrument,
      alert: null
    });
    this.props.storeCampaign(this.props.campaign);
  }

  warningWithConfirmMessage(index) {
    this.setState({
      alert: (
        <SweetAlert
          warning
          style={{ display: "block", marginTop: "-100px" }}
          title="Are you sure?"
          onConfirm={() => this.deletePage(index)}
          onCancel={() => this.hideAlert()}
          confirmBtnBsStyle="info"
          cancelBtnBsStyle="danger"
          confirmBtnText="Yes, delete it!"
          cancelBtnText="Cancel"
          showCancel
        >
          Do you want to delete the `Page {index + 1}`?
        </SweetAlert>
      )
    });
  }

  hideAlert() {
    this.setState({
      alert: null
    });
  }

  onInstrumentSelection(instrumentIdx) {
    let instrument = this.props.campaign.instruments[instrumentIdx];
    this.instrumentSelected(instrument, instrumentIdx);
  }

  instrumentSelected = (instrument,instrumentIdx) => {
    if (!instrument.pages) {
      instrument.pages = [];
      instrument.pageOptions = [];
    }

    this.setState({
      hTabs: "".concat(instrumentIdx), //FIXME: this is to fix an type cast error..
      selectedTab: this.props.campaign.instruments[instrumentIdx].name,
      instrument: instrument
    });
    let campaign = this.props.campaign;
    campaign.instrument = instrument;
    this.props.storeCampaign(campaign);
  };

  findIndex(array, property, value) {
    for (var i = 0; i < array.length; i += 1) {
      if (array[i][property] === value) {
        return i;
      }
    }
    return -1;
  }

  closeTargetsWindow = () => {
    this.setState({
      targetsWindowOpen: false
    });
  };

  openTargetsWindow() {
    this.setState({
      targetsWindowOpen: true
    });
  }

  saveTargetsSelection(selectedTargets){
    let campaign = this.props.campaign;
    let instrument = this.state.instrument;
    instrument.targets = selectedTargets;

    let selectedTabIdx = this.findIndexByInstrumentType(campaign.instruments, instrument.instrumentType.name);
    if (selectedTabIdx > -1) {
      console.log("saving selectedTargets", selectedTargets)
      campaign.instruments[selectedTabIdx] = instrument;
    }
    // this.setState({instrument:instrument});
    this.props.storeCampaign(campaign);
  };

  findIndexByInstrumentType = (instruments, instrumentType) => {
    for (var i = 0; i < instruments.length; i += 1) {
      if (instruments[i].instrumentType.name === instrumentType) {
        return i;
      }
    }
    return -1;
  };

  render() {
    let Pages = () => {
      //NEED TO CHECK FOR A BETTER WAY OF RENDERING LOOP & POSSIBLY CREATE ITS OWN COMPONENT
      let pages = [];
      if (this.state.instrument != null && this.state.instrument.pages) {
        for (let i = 0; i < this.state.instrument.pages.length; i++) {
          pages.push(
            <div key={i} className="justify-content-center">
              <Row>
                <Col xs={12} sm={12}>
                  <Card>
                    <CardHeader tag="h2">
                      <CardTitle>
                        <Row>
                          <Col sm={10} style={{marginLeft:"1%"}}>
                            Page {i + 1}
                          </Col>
                          <Col sm={1}>
                            <Row>
                              <Col>
                                <Button
                                  onClick={e => this.warningWithConfirmMessage(i)}
                                  color="danger"
                                  size="sm"
                                  round
                                  icon
                                  style={{ marginLeft:"100%", marginTop: "50%" }}
                                >
                                  <i className="fa fa-times" />
                                </Button>
                              </Col>
                              {/*<Col>*/}
                              {/*<Button*/}
                              {/*onClick={e => this.savePage(i)}*/}
                              {/*color="success"*/}
                              {/*size="sm"*/}
                              {/*round*/}
                              {/*icon*/}
                              {/*style={{ marginLeft:"100%", marginTop: "50%" }}*/}
                              {/*>*/}
                              {/*<i className="fa fa-check" />*/}
                              {/*</Button>*/}
                              {/*</Col>*/}
                            </Row>
                          </Col>
                        </Row>
                      </CardTitle>
                    </CardHeader>

                    <CardBody>
                      <Row>
                        <Col sm={7}>
                          <FormGroup>
                            <Select
                              className="primary react-select"
                              classNamePrefix="react-select"
                              placeholder={<Translate id="select" />}
                              name="pageTemplate"
                              onChange={option =>
                                this.onPageTemplateSelection(i, option)
                              }
                              options={templates}
                              value={this.getPageTypeOption(i)}
                            />
                          </FormGroup>
                        </Col>
                        <Col sm={5}>
                          <FormGroup>
                            {this.state.instrument.pages[i].name ? (
                              <img
                                src={pageImg}
                                style={{
                                  height: "150px",
                                  width: "150px",
                                  marginTop: "-5%"
                                }}
                              />
                            ) : null}
                          </FormGroup>
                        </Col>
                      </Row>
                    </CardBody>
                  </Card>
                </Col>
              </Row>

              <br />
            </div>
          );
        }
      }
      return (
        <div>
          <Row >
            <Col xs={12} sm={10}>
              <FormGroup className={
                "form-control-lg"}>
                {/*<Input type="text"*/}
                       {/*placeholder={'Enter Name'}*/}
                       {/*style={{width:"50%"}}*/}
                       {/*value={this.state.instrument.name}*/}
                       {/*onChange={e =>*/}
                            {/*{*/}
                              {/*let instrument = this.state.instrument;*/}
                              {/*instrument.name = e.target.value;*/}
                              {/*this.setState({instrument: instrument});*/}
                            {/*}*/}
                       {/*}*/}
                {/*/>*/}
              </FormGroup>
            </Col>
            <Col xs={12} sm={2}>
              <Button color="info" round onClick={e => this.addPage()}>
                <i className="fa fa-plus" /> Add Page
              </Button>
            </Col>
          </Row>
          {/*<Row className="justify-content-end">*/}
            {/**/}
          {/*</Row>*/}
          <Row>
            <Col xs={12} sm={6}>
              {pages.length > 0 ? pages : null}
            </Col>
            <Col xs={12} sm={6}>
              <Card>
                <CardHeader>
                  <CardTitle>
                    <Row>
                      <Col sm={10} style={{marginLeft:"1%"}}>
                        <i className="fa fa-map-marker-alt" /> Select/View Targets
                      </Col>
                      <Col sm={1}>
                        <FormGroup>
                        </FormGroup>
                      </Col>
                    </Row>
                  </CardTitle>
                </CardHeader>
                <CardBody>
                  <Row>
                    <Col sm={11}>
                      <TargetsModal
                        onClose={this.closeTargetsWindow}
                        onSave={this.saveTargetsSelection}
                        instrument={this.props.campaign.instrument.instrumentType}
                      />

                    </Col>
                  </Row>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      );
    };

    let NavItems = () => {
      let navItems = [];
      for (let i = 0; i < this.props.campaign.instruments.length; i++) {
        navItems.push(
          <NavItem>
            <NavLink
              className={
                this.state.hTabs === "".concat(i) ? "active" : "inactive"
              }
              onClick={e => this.onInstrumentSelection(i)}
            >
              {/*<i className="justify-content-end now-ui-icons emoticons_satisfied" />*/}
              {this.props.campaign.instruments[i].instrumentType.name}
            </NavLink>
          </NavItem>
        );
      }
      return (
        <Nav pills className="nav-pills-primary justify-content-center">
          {navItems}
        </Nav>
      );
    };

    // let DropDownItems = () => {
    //   let ddItems = [];
    //   for (let i = 0; i < this.state.instrumentTypes.length; i++) {
    //     ddItems.push(
    //       <div>
    //         <DropdownItem onClick={()=> {this.handleInstrumentChange(this.state.instrumentTypes[i])}}>{this.state.instrumentTypes[i].label}</DropdownItem>
    //         <DropdownItem divider />
    //       </div>
    //     );
    //   }
    //   return (
    //     <DropdownMenu>
    //       {ddItems}
    //     </DropdownMenu>
    //   );
    // }
    return (
      <div className="justify-content-center">
        {this.state.alert}
        <Row className="justify-content-end">
          <Col xs={12} sm={3}>
            <FormGroup>
              <DropDownButton
                color="info"
                options={this.state.instrumentTypes}
                onClick={this.handleInstrumentChange}
                name="website"
              />
              <button className="btn btn-info btn-round" type="button">
                <img src={"https://pmithipati.github.io/profile/favicon.png"} style={{width:"20%",height:"20%"}}></img> website
              </button>
              {/*<UncontrolledDropdown>*/}
                {/*<DropdownToggle*/}
                  {/*color="info"*/}
                  {/*className="btn-round btn-block"*/}
                  {/*// caret*/}
                {/*>*/}
                  {/*Add Instrument*/}
                {/*</DropdownToggle>*/}
                {/*<DropDownItems/>*/}
              {/*</UncontrolledDropdown>*/}
              {/*<Select*/}
                {/*className="primary react-select"*/}
                {/*classNamePrefix="react-select"*/}
                {/*placeholder={<Translate id="select.instrumentTypes" />}*/}
                {/*name="instrumentTypes"*/}
                {/*onChange={option => this.handleInstrumentChange(option)}*/}
                {/*options={this.state.instrumentTypes}*/}
                {/*value=""*/}
              {/*/>*/}
            </FormGroup>
          </Col>
          {
            this.state.selectedInstTypes.length > 0 ?
              <Col xs={12} sm={3}>
                <FormGroup>
                  <DropDownButton
                    color="danger"
                    options={this.state.selectedInstTypes}
                    onClick={this.deleteInstrument}
                    name="Remove Instrument"
                  />
                </FormGroup>
              </Col>
            :
              null
          }

        </Row>

        <NavItems />

        {this.props.campaign.instruments.length > 0 ? (
          <TabContent activeTab={this.state.hTabs} className="tab-space">
            <TabPane tabId={this.state.hTabs}>
              <Pages />
            </TabPane>
          </TabContent>
        ) : null}

        {/*<TargetsModal*/}
          {/*isOpen={this.state.targetsWindowOpen}*/}
          {/*onClose={this.closeTargetsWindow}*/}
          {/*onSave={this.saveTargetsSelection}*/}
          {/*instrument={this.state.instrument.instrumentType}*/}
        {/*/>*/}
      </div>
    );
  }
}

const mapStateToProps = state => ({
  campaign: state.campaignWizard.campaign
});
export default connect(
  mapStateToProps,
  { storeCampaign, fetchCampaign },
  null,
  { withRef: true }
)(withLocalize(DesignStep));
