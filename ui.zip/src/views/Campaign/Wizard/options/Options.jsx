import React from "react";
import { Col, FormGroup, Input, Label, Row } from "reactstrap";
// react plugin used to create DropdownMenu for selecting items
import SimpleCheckbox from "../../../../components/CustomCheckbox/SimpleCheckbox";
import connect from "react-redux/es/connect/connect";
import { fetchCampaign, storeCampaign } from "../../../../_actions/campaign.action";
import { Translate, withLocalize } from "react-localize-redux";


class Options extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            calendars: [],
            //campaign: this.props.campaign ? this.props.campaign : defaultCampaign
        };

        console.log("Wizard state %o", this.state);
        this.handleChange = this.handleChange.bind(this);
    }


    render() {
        return (
            <div className="justify-content-center">
                {/*<h5 className="info-text">Dates {JSON.stringify(this.props.campaign.startDate)} - {JSON.stringify(this.props.campaign.endDate)}</h5>*/}


                <Row className="justify-content-center">
                    <Col xs="6" className="justify-content-center">
                        <FormGroup>
                            <SimpleCheckbox label={<Translate id="recurs"/>}/>
                        </FormGroup>
                    </Col>
                </Row>

                <Row className="justify-content-center">
                    <Col xs="2" className="justify-content-center">
                        <Label>Duration</Label>
                        <Input type="text" name="duration" readOnly value={this.getDateInfo(this.props.campaign.endDate).duration}/>
                    </Col>
                </Row>

                <Row className="justify-content-center">
                    <Col xs="4" className="justify-content-center">
                        <FormGroup>
                            <Label>Recurring Options</Label>
                            <SimpleCheckbox name="daily" label="Every Day"/>
                            <SimpleCheckbox name="weekly" label="Every Week"/>
                            <SimpleCheckbox name="monthly" label="Every Month"/>
                            <SimpleCheckbox name="yearly" label="Every Year"/>

                        </FormGroup>
                    </Col>
                    <Col xs="4" className="justify-content-center">
                        <FormGroup>
                            <Label>Start Date Options</Label>
                            <SimpleCheckbox label={this.getDateInfo(this.props.campaign.startDate).dayOfWeek}/>
                            <SimpleCheckbox label={this.getDateInfo(this.props.campaign.startDate).day}/>
                            <SimpleCheckbox label={this.getDateInfo(this.props.campaign.startDate).month}/>

                        </FormGroup>
                    </Col>
                    <Col xs="4" className="justify-content-center">
                        <FormGroup>
                            <Label>End Date Options</Label>
                            <SimpleCheckbox label={this.getDateInfo(this.props.campaign.endDate).dayOfWeek}/>
                            <SimpleCheckbox label={this.getDateInfo(this.props.campaign.endDate).day}/>
                            <SimpleCheckbox label={this.getDateInfo(this.props.campaign.endDate).month}/>

                        </FormGroup>
                    </Col>

                </Row>
            </div>
        );
    }

    getDateInfo(input) {
        let res = {};
        console.log("Handling date %o", input);
        let dow = input.day();
        res.dow = dow;
        res.dayOfWeek = input.format("dddd");
        res.day = input.format("DD");
        res.month = input.format("MMMM");
        console.log("Returning %o", res);
        res.duration = input.diff(this.props.campaign.startDate, "days");

        return res;
    }

    handleChange(name, value) {
        let campaign = this.props.campaign;
        campaign[name] = value;

        // this.setState({
        //     campaign: campaign
        // });
        this.props.storeCampaign(this.props.campaign);
    };

    componentWillReceiveProps(newProps) {
        if (newProps.campaign) {
            //this.setState({ campaign: newProps.campaign });
        }
    }


    componentWillMount() {
        this.props.fetchCampaign();
    }


}


const mapStateToProps = state => ({
    campaign: state.campaignWizard.campaign
});

export default connect(mapStateToProps, { storeCampaign, fetchCampaign }, null, {withRef: true})(withLocalize(Options));
