import React from "react";

import { IconCheckbox } from "components";
import connect from "react-redux/es/connect/connect";
import { fetchCampaign, storeCampaign } from "../../../../_actions/campaign.action";
import { Translate, withLocalize } from "react-localize-redux";

import {
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Label,
  Input,
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  CardText,
  Row,
  Col,
  FormGroup,
  Collapse

} from "reactstrap";


import { Accordion, PanelHeader } from "components";
import Select from "react-select";
import { calendarService } from "../../../../_services/index";
import Datetime from 'react-datetime';
import Switch from "react-switch";
import DropDownButton from "../../../../components/AvenueOne/DropDownButton";
import SweetAlert from "react-bootstrap-sweetalert";




class DeadlineStep extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      deadline:{},
      deadlines: [],
      //campaign: this.props.campaign?this.props.campaign:defaultCampaign,
      deadlineDates: {
        startDate: new Date(),
        endDate: new Date(),
        targetDate: new Date()
      },
      selectedTabIdx: 0,
      hTabs: "0",
      selectedTab: "",
      expandedItems: [],
      alert: null
    };
    this.handleDeadlineChange = this.handleDeadlineChange.bind(this);
    //this.updateDeadlinesState = this.updateDeadlinesState.bind(this);
  }

  componentDidMount() {
    calendarService.getDeadlineTypes().then(deadlines => {
      let deadlineList = [];
      if (deadlines.length) {
        deadlines.map((ddl) => {
          deadlineList.push(
            {
              label: ddl.name,
              value: ddl.name,
              name: ddl.name,
              description: ddl.description,
              id: ddl.id,
              type: ddl.type
            }
          );
        });
      }
      this.setState({
        deadlineTypes: deadlineList
      });

    });
  }

  componentWillReceiveProps(newProps) {
    if(newProps.campaign) {
      this.setState({deadlines: newProps.campaign.deadlines})
      //this.updateDeadlinesState();
    } else {
      //this.props.fetchCampaign();
      //this.updateDeadlinesState();
    }
  }

  // componentWillMount() {
  //   this.props.fetchCampaign();
  // }


  handleDeadlineChange(option) {
    let deadlines = this.props.campaign.deadlines;
    if (deadlines && !deadlines.some( ddl => (ddl.name === option.value))) {
      deadlines.push({ name: option.value, type:option });
      this.setState({
        deadlines: deadlines
      });
      //this.props.storeCampaign(this.props.campaign);
    }

  }

  // onDeadlineSelection(ddlIdx) {
  //
  //   let deadline = this.props.campaign.deadlines[ddlIdx];
  //   this.setState({
  //     hTabs: "".concat(ddlIdx), //FIXME: this is to fix an type cast error..
  //     selectedTab: this.props.campaign.deadlines[ddlIdx].name,
  //     selectedTabIdx: ddlIdx
  //
  //   });
  // }

  handleDateChange(index, value) {
    let deadlines = this.state.deadlines;
    deadlines[index].deadlineLineDue = value;

    this.setState({deadlines: deadlines})
    //
    let campaign = this.props.campaign;
    campaign.deadlines = deadlines;
    // this.setState({campaign: campaign});
    this.props.storeCampaign(campaign);
    // console.log("Changed %o", campaign);
  };

  deleteDeadline(index) {
    let deadlines = this.state.deadlines;
    deadlines.splice(index, 1)
    this.setState({deadlines: deadlines, alert:null})
    //
    let campaign = this.props.campaign;
    campaign.deadlines = deadlines;
    // this.setState({campaign: campaign});
    this.props.storeCampaign(campaign);
    // console.log("Changed %o", campaign);
  };

  warningWithConfirmMessage(index) {
    this.setState({
      alert: (
        <SweetAlert
          warning
          style={{ display: "block", marginTop: "-100px" }}
          title="Are you sure?"
          onConfirm={() => this.deleteDeadline(index)}
          onCancel={() => this.hideAlert()}
          confirmBtnBsStyle="info"
          cancelBtnBsStyle="danger"
          confirmBtnText="Yes, delete it!"
          cancelBtnText="Cancel"
          showCancel
        >
          Do you want to delete `{this.state.deadlines[index].type.name}`?
        </SweetAlert>
      )
    });
  }

  hideAlert() {
    this.setState({
      alert: null
    });
  }

  openCollapse(deadline) {
    let expandedItems = this.state.expandedItems;
    if (expandedItems.includes(deadline)) {
      expandedItems = expandedItems.filter(e => e !== deadline);
    } else {
      expandedItems.push(deadline);
    }
    this.setState({expandedItems: expandedItems});
  }



  render() {

    // let NavItems = () => {
    //   let navItems = [];
    //   for (let i = 0; i < this.props.campaign.deadlines?this.props.campaign.deadlines.length:0; i++) {
    //     navItems.push(
    //       <NavItem>
    //         <NavLink
    //           className={this.state.hTabs === "".concat(i) ? "active" : "inactive"}
    //           onClick={e => this.onDeadlineSelection(i)}
    //         >
    //           <i className="justify-content-end now-ui-icons emoticons_satisfied"></i>{this.props.campaign.deadlines[i].name}
    //         </NavLink>
    //       </NavItem>
    //     );
    //   }
    //   return <Nav pills className="nav-pills-primary justify-content-center">{navItems}</Nav>;
    // };

    let Deadlines = () => {
      let deadlines = [];
      if(this.state.deadlines != null) {
        for (let i = 0; i < this.state.deadlines.length; i++) {
          deadlines.push(
            <div key={i}>
              <Row className="justify-content-center" >
                <Card style={{width:"70%"}} >
                  <CardHeader>
                    <Row>
                      <Col sm={10} >
                        { this.state.deadlines[i].type.name }
                      </Col>
                      <Col sm={1} >
                        <a
                          onClick={() => this.openCollapse(this.state.deadlines[i].type.name)}
                        >
                          <i
                            className={this.state.expandedItems.includes(this.state.deadlines[i].type.name) ? "fa fa-angle-double-up" : "fa fa-angle-double-down"}
                          />
                        </a>
                      </Col>
                      <Col sm={1} >
                        <a
                          onClick={() => this.warningWithConfirmMessage(i)}
                        >
                          <i
                            className={"fa fa-trash-alt"}
                          />
                        </a>
                      </Col>
                    </Row>
                  </CardHeader>
                  <Collapse isOpen={this.state.expandedItems.includes(this.state.deadlines[i].type.name)}>
                    <CardBody style={{width: "65%"}}>
                      <FormGroup
                        className={
                          "has-label "
                        }
                      >
                        <Label>Due date *</Label>
                        <Datetime
                          value={this.state.deadlines[i].deadlineLineDue}
                          timeFormat={false}
                          dateFormat="YYYY-MM-DD"
                          onChange={value => this.handleDateChange(i, value)}
                          inputProps={{ placeholder: "" }}
                        />
                      </FormGroup>
                    </CardBody>
                  </Collapse>
                </Card>
              </Row>
            </div>

          )
        }
      }

      return(
        <div>
          {deadlines}
        </div>
      )
      ;

    }
    return (
      <div>
        {this.state.alert}
        <Row className="justify-content-end">
          <Col xs={12} sm={3}>
            <FormGroup>
              <DropDownButton
                color="info"
                options={this.state.deadlineTypes}
                onClick={this.handleDeadlineChange}
                name="Add Deadline"
              />
            </FormGroup>

          </Col>

        </Row>

        {/*<NavItems/>*/}

        {

          this.state.deadlines.length > 0 ?
            <Deadlines />
          :
          null
        }
      </div>
    );
  }
}

const mapStateToProps = state => ({
  campaign: state.campaignWizard.campaign
});
export default connect(mapStateToProps, { storeCampaign, fetchCampaign }, null, {withRef: true} )(withLocalize(DeadlineStep));
