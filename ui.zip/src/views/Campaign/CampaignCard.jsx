import React from "react";
import { connect } from "react-redux";

import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardTitle,
  Row,
  Col,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Table
} from "reactstrap";
import { Progress } from "../../components";

import { Line } from "react-chartjs-2";
import CardCategory from "../../components/CardElements/CardCategory";
import Stats from "../../components/Stats/Stats";
import { Translate, withLocalize } from "react-localize-redux";

import { dashboardSummerChart } from "../../variables/charts.jsx";

class CampaignCard extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { classes } = this.props;
    return (
      <div>
        <Card className="card-chart">
          <CardHeader>
            <CardCategory>
              <Translate id="campaigns.active" />
            </CardCategory>
            <CardTitle tag="h2">55,300</CardTitle>
            <UncontrolledDropdown>
              <DropdownToggle
                className="btn-round btn-simple btn-icon"
                color="default"
              >
                <i className="now-ui-icons loader_gear" />
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem>Filter</DropdownItem>
                <DropdownItem>Another Action</DropdownItem>
                <DropdownItem>Something else here</DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </CardHeader>
          <CardBody>
            <div className="chart-area">
              <Line
                data={dashboardSummerChart.data}
                options={dashboardSummerChart.options}
              />
            </div>
            <div className="card-progress">
              <Progress badge="Weekly" value="90" />
              <Progress color="success" badge="Summer Special" value="60" />
              <Progress color="info" badge="Email P&G" value="12" />
              <Progress color="primary" badge="Coupon Blast" value="5" />
              <Progress color="danger" badge="Vendor Insert" value="0.11" />
            </div>
          </CardBody>
          <CardFooter>
            <Stats>
              {[
                {
                  i: "now-ui-icons arrows-1_refresh-69",
                  t: "Just Updated"
                }
              ]}
            </Stats>
          </CardFooter>
        </Card>
      </div>
    );
  }
}

export default withLocalize(CampaignCard);
