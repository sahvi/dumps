import React from "react";
import PropTypes from "prop-types";

import { calendarService } from "../../_services/calendar.service";

import { Form } from "reactstrap";
import { withLocalize } from "react-localize-redux";

import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Avatar from "@material-ui/core/Avatar";
import PieChart from "@material-ui/icons/PieChart";
import Divider from "@material-ui/core/Divider";
import CalendarToday from "@material-ui/icons/CalendarToday";
import Button from "../../components/CustomButton/CustomButton";
import Select from "react-select";
import Switch from "react-switch";

const styles = theme => ({
  root: {
    width: "100%",
    maxWidth: "360px",
    backgroundColor: theme.palette.background.paper
  }
});

const statusList = [
  {
    name: "active",
    label: "Active"
  },
  {
    name: "inprogress",
    label: "In Progress"
  },
  {
    name: "completed",
    label: "Completed"
  },
  {
    name: "aborted",
    label: "Aborted"
  },
  {
    name: "onhold",
    label: "On Hold"
  }
];

class CampaignFilter extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      calendars: [],
      isLoading: true,
      filters: {
        calendar: [],
        status: []
      },
      checked: true
    };
    this.calSwitch = this.calSwitch.bind(this);
  }

  renderCalendarControls() {
    if (this.state.calendars && Array.isArray(this.state.calendars)) {
      return this.state.calendars.map(cal => (
        <tr key={cal.id}>
          <td>{cal.id}</td>
        </tr>
      ));
    } else {
      return <td>No calendars</td>;
    }
  }

  componentDidMount() {
    console.log("Loading calendars...");

    calendarService.getCalendars().then(d => {
      console.log("Got calendars %o", d);
      d.map(c => {
        c.checked = true;
        c.label = c.name;
      });
      this.setState({
        calendars: d,
        isLoading: false
      });
      console.log("State %o", this.state);
    });
  }

  componentWillReceiveProps(nextProps, nextContext) {
  }

  filterCampaigns = (type, name) => event => {
    this.filter(type, name);
  };

  filterByCalendar = (type, name) => {
    this.filter(type, name);
  };

  filter = (type, name) => {
    let filters = this.state.filters;
    if (filters[type].indexOf(name) != -1) {
      filters[type].splice(filters[type].indexOf(name), 1);
    } else {
      filters[type].push(name);
    }
    this.setState({ filters: filters });
    this.props.filterCampaigns(filters);
  };

  isFilterEmpty = () => {
    return (
      this.state.filters.calendar.length == 0 &&
      this.state.filters.status.length == 0
    );
  };

  clearFilters = () => {
    const filters = {
      calendar: [],
      status: []
    };
    this.setState({
      filters: filters
    });
    this.props.filterCampaigns(filters);
  };

  render() {
    const { isLoading, calendars } = this.props;

    return (
      <div >
        <Form row>
          <List component="nav" className={styles.root}>
            {!this.isFilterEmpty() ? (
              <div>
                <ListItem>
                  <ListItemText primary="Filter By"/>
                  <span
                    style={{ cursor: "pointer", color: "grey" }}
                    onClick={this.clearFilters}
                  >
                    Clear All
                  </span>
                </ListItem>
                {this.state.filters.calendar.map(calendar => {
                  return (
                    <li>
                      <div
                        key={calendar}
                        style={{ width: "90%", display: "inline-flex" }}
                      >
                        <label
                          style={{
                            width: "40%",
                            display: "inline-flex",
                            alignItems: "center",
                            fontSize: "1em"
                          }}
                        >
                          Calendar:
                        </label>
                        <label
                          style={{
                            width: "40%",
                            display: "inline-flex",
                            alignItems: "center",
                            fontSize: "1em"
                          }}
                        >
                          <span>{calendar}</span>
                        </label>
                        <Button
                          onClick={this.filterCampaigns("calendar", calendar)}
                          size="sm"
                          round
                          icon
                          style={{ marginBottom: "2px", marginTop: "2px", marginLeft: "20%" }}
                        >
                          <i className="fa fa-times"/>
                        </Button>{" "}
                      </div>
                    </li>
                  );
                })}

                {this.state.filters.status.map(status => {
                  return (
                    <li>
                      <div
                        key={status}
                        style={{ width: "90%", display: "inline-flex" }}
                      >
                        <label
                          style={{
                            width: "40%",
                            display: "inline-flex",
                            alignItems: "center",
                            fontSize: "1em"
                          }}
                        >
                          Status:
                        </label>
                        <label
                          style={{
                            width: "40%",
                            display: "inline-flex",
                            alignItems: "center",
                            fontSize: "1em"
                          }}
                        >
                          <span>{status}</span>
                        </label>
                        <Button
                          onClick={this.filterCampaigns("status", status)}
                          size="sm"
                          round
                          icon
                          style={{ marginLeft: "10%", marginBottom: "5%" }}
                        >
                          <i className="fa fa-times"/>
                        </Button>{" "}
                      </div>
                    </li>
                  );
                })}

                <li>
                  <Divider/>
                </li>
              </div>
            ) : null}
            <ListItem>
              <Avatar>
                <CalendarToday/>
              </Avatar>
              <ListItemText primary="Calendars"/>
            </ListItem>
            {this.props.showSelect ? (
              <div>
                <Select
                  className="primary react-select"
                  classNamePrefix="react-select"
                  placeholder="Select calendar to filter"
                  name="calendar"
                  onChange={option =>
                    this.filterByCalendar("calendar", option.label)
                  }
                  options={this.state.calendars}
                  value=""
                />
                <div style={{ marginBottom: "5px" }}/>
              </div>
            ) : (
              <div style={{ height: "250px", overflowY: "scroll" }}>
                {this.state.calendars.map((calendar, i) => {
                  const { id, name, colour, icon } = calendar;
                  return (
                    <div>
                      <div
                        key={calendar.id}
                        style={{ width: "90%", display: "inline-flex", marginLeft: "20px" }}
                      >
                        <Switch
                          onColor={colour}
                          offColor={colour}
                          onHandleColor={colour}
                          handleDiameter={30}
                          uncheckedIcon={false}
                          checkedIcon={false}
                          boxShadow="0px 1px 5px rgba(0, 0, 0, 0.6)"
                          activeBoxShadow="0px 0px 1px 10px rgba(0, 0, 0, 0.2)"
                          height={20}
                          width={50}
                          checked={this.state.filters.calendar.includes(name)}
                          onChange={this.filterCampaigns("calendar", name)}
                        />
                        <label
                          style={{
                            width: "90%",
                            display: "inline-flex",
                            alignItems: "center"
                          }}
                        >
                          <span style={{ marginLeft: "10%" }}>
                            {calendar.name}
                          </span>
                        </label>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <li>
              <Divider/>
            </li>
            <ListItem>
              <Avatar>
                <PieChart/>
              </Avatar>
              <ListItemText primary="Status"/>
            </ListItem>
            {statusList.map((status, i) => {
              const { label, name } = status;
              return (
                <li>
                  <div
                    key={status.name}
                    style={{ width: "90%", display: "inline-flex", marginLeft: "20px" }}
                  >
                    <Switch
                      color={"blue"}
                      handleDiameter={30}
                      uncheckedIcon={false}
                      checkedIcon={false}
                      boxShadow="0px 1px 5px rgba(0, 0, 0, 0.6)"
                      activeBoxShadow="0px 0px 1px 10px rgba(0, 0, 0, 0.2)"
                      height={20}
                      width={50}
                      checked={this.state.filters.status.includes(label)}
                      onClick={this.filterCampaigns("status", label)}
                    />
                    <label
                      style={{
                        width: "90%",
                        display: "inline-flex",
                        alignItems: "center"
                      }}
                    >
                      <span style={{ marginLeft: "10%" }}>{status.label}</span>
                    </label>
                  </div>
                </li>
              );
            })}
            <Divider component="li"/>
          </List>

          {/*{!this.state.isLoading ? (*/}
          {/*this.state.calendars.map((calendar, i) => {*/}
          {/*const { id, name, colour, icon } = calendar;*/}
          {/*return (*/}
          {/*<div key={calendar.id} style={{ width: "90%", display: "inline-flex" }}>*/}
          {/*<label*/}
          {/*style={{*/}
          {/*width: "90%",*/}
          {/*display: "inline-flex",*/}
          {/*alignItems: "center"*/}
          {/*}}*/}
          {/*>*/}
          {/*<Switch*/}
          {/*onChange={this.calSwitch}*/}
          {/*checked={calendar.checked}*/}
          {/*handleDiameter={30}*/}
          {/*id={i}*/}
          {/*boxShadow="0px 1px 5px rgba(0,0,0,0.6)"*/}
          {/*uncheckedIcon={false}*/}
          {/*onColor={calendar.colour}*/}
          {/*/>*/}
          {/*<span style={{ paddingLeft: "10px" }}>{calendar.name}</span>*/}
          {/*</label>*/}
          {/*</div>*/}
          {/*);*/}
          {/*})*/}
          {/*) : (*/}
          {/*// If there is a delay in data, let's let the user know it's loading*/}
          {/*<h2>Loading...</h2>*/}
          {/*)}*/}
        </Form>
      </div>
    );
  }

  calSwitch = (checked, proto, id) => {
    let cals = this.state.calendars;
    console.log("Changing %o %o", cals, id);
    cals[id].checked = checked;

    this.setState({ cals });
  };
}

CampaignFilter.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withLocalize(CampaignFilter);
