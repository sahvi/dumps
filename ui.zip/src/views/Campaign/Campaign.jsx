import BigCalendar from "react-big-calendar";
import React from "react";
import PropTypes from "prop-types";
import Calendar from "../Calendar/Calendar";

class Campaign extends React.Component {
  events = [];

  constructor(props) {
    super(props);
    this.state = { selected: "calendar" };
  }

  render() {
    const { classes } = this.props;
    let allViews = Object.keys(BigCalendar.Views).map(
      k => BigCalendar.Views[k]
    );
    return (
      <div className="content">
        <Calendar class="cal" />
      </div>
    );
  }
}

Campaign.propTypes = {
  classes: PropTypes.object.isRequired
};

export default Campaign;
