import React from "react";
import { Card, CardBody, Col, Row } from "reactstrap";
// react plugin used to create charts
import { Line } from "react-chartjs-2";
// react plugin for creating vector maps
// import { VectorMap } from "react-jvectormap";

import { PanelHeader, Statistics } from "components";

import { dashboardPanelChart } from "./dashboardCharts.jsx";

import { table_data } from "variables/general.jsx";
import { withLocalize } from "react-localize-redux";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import { campaignService } from "../../_services/campaign.service";
import CampaignAlerts from "../../components/Dashboard/CampaignAlerts";
import DeadlineTable from "../../components/Deadlines/DeadlineTable";
import { connect } from "react-redux";
import { fetchAlertState } from "../../_actions/dashboard.action";
import AlertCard from "../ToDo/AlertCard";
import DeadlineCard from "../../components/Deadlines/DeadlineCard";
import HistoryCard from "../../components/History/HistoryCard";

class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            alert: null,
            campaignChartData: {
                data: {}
            }
        };
    }

    componentWillUnmount() {
        console.log("Stop updating dashboard");
    }

    componentDidMount() {
        // load the campaign chart
        campaignService.getRollingCampaignChart().then(res => {
            console.log("Changing state %o", res);
            this.setState({
                campaignChartData: res.data
            });
            toast.success("Success Notification !", {
                position: toast.POSITION.TOP_RIGHT
            });
        });
    }

    createTableData() {
        var tableRows = [];
        for (var i = 0; i < table_data.length; i++) {
            tableRows.push(
                <tr key={i}>
                    <td>
                        <div className="flag">
                            <img src={table_data[i].flag} alt="us_flag"/>
                        </div>
                    </td>
                    <td>{table_data[i].country}</td>
                    <td className="text-right">{table_data[i].count}</td>
                    <td className="text-right">{table_data[i].percentage}</td>
                </tr>
            );
        }
        return tableRows;
    }

    clickCampaignMonth(element) {
        if (element && element.length !== 0 && this.state.campaignChartData) {
            console.log("Clicked %o %o", element, this.state.campaignChartData);
            // chart_config.data.datasets[activeElement[0]._datasetIndex].data[activeElement[0]._index];
            let datasetIdx = element[0]._datasetIndex, itemIdx = element[0]._index;
            console.log("Clicked %o", this.state.campaignChartData.datasets[datasetIdx].data[itemIdx]);
            console.log("Month %o", this.state.campaignChartData.labels[itemIdx]);
            let month = this.state.campaignChartData.labels[itemIdx];
            toast.info("Clicked " + month);
        }
    }

    render() {
        return (
            <div>
                <PanelHeader
                    size="md"
                    content={
                        <Line
                            getElementAtEvent={element => this.clickCampaignMonth(element)}
                            data={this.state.campaignChartData}
                            options={dashboardPanelChart.options}
                        />
                    }
                />
                <div className="content">
                    <ToastContainer/>
                    <Row>
                        <Col xs={12} md={12}>
                            <Card className="card-stats card-raised">
                                <CardBody>
                                    <Row>
                                        <Col xs={12} md={2}>

                                            <CampaignAlerts>
                                            </CampaignAlerts>


                                        </Col>

                                        <Col xs={12} md={3}>
                                            <Statistics
                                                iconState="success"
                                                icon="business_money-coins"
                                                title={
                                                    <span>
                            <small>$</small>3.5M
                          </span>
                                                }
                                                subtitle="Current Offers"
                                            />
                                        </Col>
                                        <Col xs={12} md={3}>
                                            <Statistics
                                                iconState="info"
                                                icon="users_single-02"
                                                title="12"
                                                subtitle="Messages"
                                            />
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>
                        </Col>
                        <Col xs={12} md={3}>
                            <DeadlineCard/>
                        </Col>
                        <Col xs={12} md={9}>
                            <AlertCard/>
                        </Col>

                    </Row>
                    <Row>
                        <Col xs={12} md={12}>
                            <HistoryCard/>
                        </Col>
                    </Row>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => ({
    alertState: state.dashboard.alertState
});

export default connect(
    mapStateToProps,
    { fetchAlertState }, null, { withRef: true }
)(withLocalize(Dashboard));

