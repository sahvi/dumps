import React, { Component } from "react";
import{ Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { Translate, withLocalize } from "react-localize-redux";
import { Button } from "../../components";

import englishTranslations from "../../i18n/en/user.json";
import frenchTranslations from "../../i18n/fr/user.json";

class Profile extends Component {

    constructor(props) {
        super(props);

        this.state = {
            modalOpen: false
        };

        this.props.addTranslationForLanguage(frenchTranslations, "fr");
        this.props.addTranslationForLanguage(englishTranslations, "en");

        let user = localStorage.getItem("user");
        console.log("User is %o", user);
    }



    componentWillReceiveProps(nextProps, nextContext) {
        if ( nextProps && nextProps.modalOpen) {
            this.setState({
                modalOpen: nextProps.modalOpen
            });
        }
    }

    render() {
        return (

            <Modal isOpen={this.props.modalOpen}   >
                <ModalHeader><Translate id={"profile.header"} /></ModalHeader>
                <ModalBody>

                    All about you!
                </ModalBody>
                <ModalFooter>
                    <Button color="secondary" onClick={this.props.closeProfile}>
                        Close
                    </Button>
                    <Button color="primary">
                        Save changes
                    </Button>
                </ModalFooter>
            </Modal>
        );
    }
}

export default withLocalize(Profile);
