import { withLocalize } from "react-localize-redux";

import englishTranslations from "../../i18n/en/targets.json";
import frenchTranslations from "../../i18n/fr/targets.json";
import React from "react";
import PanelHeader from "../../components/PanelHeader/PanelHeader";
import { Card, CardBody, Col, Nav, Row, TabContent, TabPane } from "reactstrap";
import TargetTable from "./TargetTable";
import { Button } from "../../components";
import InstrumentTypeButtonList from "../../components/InstrumentTypes/InstrumentTypeButtonList";
import { withRouter } from "react-router-dom";
import connect from "react-redux/es/connect/connect";
import {
  changeInstrumentType,
  fetchDesign,
  storeDesign
} from "../../_actions/design.action";
import { fetchInstrumentTypes } from "../../_actions/sysconfig.action";

class TargetControl extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      alert: null,
      instrumentType: ""
    };

    this.props.addTranslationForLanguage(frenchTranslations, "fr");
    this.props.addTranslationForLanguage(englishTranslations, "en");

    this.renderTargetTabs = this.renderTargetTabs.bind(this);
    this.handleTabClick = this.handleTabClick.bind(this);
  }

  renderTargetTabs() {
    if (
      this.props.instrumentTypes &&
      Array.isArray(this.props.instrumentTypes)
    ) {
      return this.props.instrumentTypes.map(ins => (
        <TabPane key={ins.name} tabId={ins.name}>
          <TargetTable instrumentType={this.state.instrumentType} />
        </TabPane>
      ));
    }
  }

  componentDidMount() {
    this.props.fetchInstrumentTypes();
  }

  UNSAFE_componentWillReceiveProps(nextProps, nextContext) {
    console.log("Props updated");
    if (
      this.state.instrumentType === "" &&
      nextProps.instrumentTypes.length > 0
    ) {
      this.setState({ instrumentType: nextProps.instrumentTypes[0].name });
    }
  }

  handleTabClick(e) {
    console.log("-> Click %o", e.target.name);
    this.setState({ instrumentType: e.target.name });
  }

  render() {
    const { classes } = this.props;

    return (
      <div>
        <PanelHeader size="sm" />
        <div className="content align-content-center">
          <Row>
            <Col xs={12} md={1}>
              <Card>
                <CardBody>
                  <Button
                    round
                    size="lg"
                    onClick={this.handleAddClick}
                    color="primary"
                  >
                    <b className="fa fa-plus" />
                  </Button>
                </CardBody>
              </Card>
            </Col>

            <Col xs={12} md={11}>
              <Card>
                <CardBody>
                  <Nav pills className="nav-pills-primary">
                    <InstrumentTypeButtonList
                      currentTab={this.state.instrumentType}
                      tabClick={this.handleTabClick}
                    />
                  </Nav>
                  <TabContent
                    activeTab={this.state.instrumentType}
                    className="tab-space"
                  >
                    {this.renderTargetTabs()}
                  </TabContent>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    instrumentTypes: state.sysConfig.instrumentTypes
  };
}

export default withRouter(
  connect(
    mapStateToProps,
    {
      fetchInstrumentTypes
    }
  )(withLocalize(TargetControl))
);
