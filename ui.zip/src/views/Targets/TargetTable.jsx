import React from "react";
import { withLocalize } from "react-localize-redux";
import ReactTable from "react-table";
import { Button } from "../../components";
import { targetService } from "../../_services";

class TargetTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      targets: []
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log("TargetTable GetDerivedState %o %o", nextProps, prevState);
    if (nextProps.instrumentType !== prevState.instrumentType) {
      return { instrumentType: nextProps.instrumentType }; // <- this is setState equivalent
    }
    return null;
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log("Component did update %o %o", prevState, this.state);
    if (prevState.instrumentType !== this.state.instrumentType) {
      targetService.getTargets(this.state.instrumentType).then(res => {
        console.log("Loading available store groups..%o", res);
        if (res) {
          this.setState({
            targets: res.data
          });
          console.log("Got stores...");
        } else {
          // todo show alert
        }
      });
    }
  }

  componentDidMount() {
    console.log("Mounting target table %o", this.props);

    targetService.getTargets(this.state.instrumentType).then(res => {
      console.log("Loading available store groups..%o", res);
      if (res) {
        this.setState({
          targets: res
        });
      } else {
        // todo show alert
      }
    });
  }

  render() {
    return (
      <div>
        <ReactTable
          data={this.state.targets.map((prop, key) => {
            return {
              id: key,
              name: prop["name"],
              type: prop["targetType"],
              childCount: prop["children"].length,

              description: prop["description"],
              active: prop["active"],
              actions: (
                // we've added some custom button actions
                <div className="actions-right">
                  {/* use this button to add a like kind of action */}
                  <Button
                    onClick={() =>
                      alert(
                        "You've pressed the like button on colmun id: " + key
                      )
                    }
                    color="info"
                    size="sm"
                    round
                    icon
                  >
                    <i className="fa fa-heart" />
                  </Button>{" "}
                  {/* use this button to add a edit kind of action */}
                  <Button
                    onClick={() =>
                      alert(
                        "You've pressed the edit button on colmun id: " + key
                      )
                    }
                    color="warning"
                    size="sm"
                    round
                    icon
                  >
                    <i className="fa fa-edit" />
                  </Button>{" "}
                  {/* use this button to remove the data row */}
                  <Button
                    onClick={() =>
                      alert(
                        "You've pressed the delete button on colmun id: " + key
                      )
                    }
                    color="danger"
                    size="sm"
                    round
                    icon
                  >
                    <i className="fa fa-times" />
                  </Button>{" "}
                </div>
              )
            };
          })}
          filterable
          columns={[
            {
              Header: "Name",
              accessor: "name"
            },
            {
              Header: "Description",
              accessor: "description"
            },
            {
              Header: "Type",
              accessor: "type"
            },
            {
              Header: "Child Count",
              accessor: "childCount"
            },
            {
              Header: "Active",
              accessor: "active"
            },
            {
              Header: "Actions",
              accessor: "actions",
              sortable: false,
              filterable: false
            }
          ]}
          defaultPageSize={50}
          showPaginationTop
          showPaginationBottom={false}
          className="-striped -highlight"
        />
      </div>
    );
  }
}

export default withLocalize(TargetTable);
