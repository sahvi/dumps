# UI
This UI for avo

## Dependencies
This service depends on back-end services

## Development

To start your application local:

```
npm install
npm start
```


## Create Docker

To build docker image run:


```
./build.sh
 ```

This will create a docker image with repository as `registry.avenueone.com/avo/ui` and `$VERSION` as tag.


## Run using Docker Compose
coming soon..

## Run standalone docker

To run the docker image locally:

```docker run -p 8500:8080 --env-file avo-ui.env -d registry.avenueone.com/avo/ui:1.0.0 ```

The application will be  started on port 8500. Change the port if 8500 is already in use

## Testing

Coming soon..

### Code quality

Coming soon..

## Continuous Integration (optional)

Coming soon..

## Production

Coming soon..
