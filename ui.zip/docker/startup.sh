cp /tmp/httpd.conf /usr/local/apache2/conf/httpd.conf
cp /tmp/server-configs.conf /usr/local/apache2/conf/server-configs.conf
mkdir -p /avo/app/logs/ui/${HOSTNAME}_logs
ln -sfn /avo/app/logs/ui/${HOSTNAME}_logs /usr/local/apache2/logs
httpd -DFOREGROUND
