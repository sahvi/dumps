# Run all docker services locally
This document explains running all the docker services locally

## Dependencies
The docker images of `targetSvc`, `planningSvc` and `ui` should be built before this.

Links for building them:

Planning Svc:
https://github.com/avenueone/planningSvc/blob/master/README.md

Target Svc:
https://github.com/avenueone/targetSvc/blob/master/README.md

UI:
https://github.com/avenueone/UI/blob/master/README.md

## Run all

To start UI with all dependent services and Mongo:

```
docker-compose -f docker/all-in-one-docker-compose.yml  up -d
```
This will start mongodb, targetSvc, planningSvc and UI.

The UI can be accessed using http://localhost:3000

## Whats Next?

Running services on multiple machines